const Schema = artifacts.require("./EthereumDIDRegistry.sol");

contract("EthereumDIDRegistry", accounts => {
    it("Delegate identityOwner", async() => {
        const Delegate = await EthereumDIDRegistry.deployed();
        const result = Delegate.identityOwner('0x74f1aad5f21b272f16a6c701632f92b901960eb8');
    })
    it("Delegate addDelegate", async() => {
        const Delegate = await EthereumDIDRegistry.deployed();
        const result = Delegate.addDelegate('0x8e8d8f5aa2d073fe76569ac5af0bcd73fef55ac9', web3.utils.asciiToHex('ABCDEFGHIJKLMNOPQRSTUVWXYZ'), '0x74f1aad5f21b272f16a6c701632f92b901960eb1', 1000);
    })
    it("Delegate revokeDelegate", async() => {
        const Delegate = await EthereumDIDRegistry.deployed();
        const result = Delegate.revokeDelegate('0x8e8d8f5aa2d073fe76569ac5af0bcd73fef55ac9', web3.utils.asciiToHex('ABCDEFGHIJKLMNOPQRSTUVWXYZ'), '0x74f1aad5f21b272f16a6c701632f92b901960eb1');
    })
    it("Delegate validDelegate", async() => {
        const Delegate = await EthereumDIDRegistry.deployed();
        const result = Delegate.validDelegate('0x8e8d8f5aa2d073fe76569ac5af0bcd73fef55ac9', web3.utils.asciiToHex('ABCDEFGHIJKLMNOPQRSTUVWXYZ'), '0x74f1aad5f21b272f16a6c701632f92b901960eb1');
    })
})