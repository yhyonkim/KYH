const Schema = artifacts.require("./Schema.sol");

contract("Schema", accounts => {
    it("Schema getter/setter", async() => {
        const schema = await Schema.deployed();
        
        await schema.set('0xfc8f598e7f77cbc13666a52c79bfbd662ba611e5', '{"type":"object","properties":{"id-bod":{"type":"object","properties":{"year":{"type":"string","pattern":"^[0-9]{4}$"},"month":{"type":"string","pattern":"^[0-9]{2}$"},"day":{"type":"string","pattern":"^[0-9]{2}$"}}}}}', '0xfc8f598e7f77cbc13666a52c79bfbd662ba611e5', 'Example');
        let schemaT = await schema._schemas.call('0xfc8f598e7f77cbc13666a52c79bfbd662ba611e5');
        assert.equal(schemaT, '{"type":"object","properties":{"id-bod":{"type":"object","properties":{"year":{"type":"string","pattern":"^[0-9]{4}$"},"month":{"type":"string","pattern":"^[0-9]{2}$"},"day":{"type":"string","pattern":"^[0-9]{2}$"}}}}}', 'Schema not set');
    
        // await schema.set('0xfc8f598e7f77cbc13666a52c79bfbd662ba611e5', 'Overwrite Test', '0xfc8f598e7f77cbc13666a52c79bfbd662ba611e5');
        // schemaT = await schema._schemas.call('0xfc8f598e7f77cbc13666a52c79bfbd662ba611e5');
        // assert.equal(schemaT, '{"type":"object","properties":{"id-bod":{"type":"object","properties":{"year":{"type":"string","pattern":"^[0-9]{4}$"},"month":{"type":"string","pattern":"^[0-9]{2}$"},"day":{"type":"string","pattern":"^[0-9]{2}$"}}}}}', 'Schema overwritten');

    })
    it("Schema owner test", async() => {
        const schema = await Schema.deployed();
    })
    it("Schema list test", async() => {
        const schema = await Schema.deployed();
    })
})