import React, { Component } from 'react';
import { connect } from 'react-redux';
const bls = require('@chainsafe/bls');
const sha256 = require('js-sha256');

class BlsTest extends Component {
    state = {do:false, result:null}

    constructor(props) {
        super(props);
        this.blstest = this.blstest.bind(this);
    }

    blstest() {
        const domain = Buffer.alloc(8,0);

        const ms = bls.default.generateKeyPair();
        const issuer = bls.default.generateKeyPair();
        
        // make random string
        // holder(Wallet) create nonce
        const testStruct = {name: "lalala", birthDate: "1111-11-1", addres: "Science park"};
        const msghash = Buffer.from(sha256.arrayBuffer(JSON.stringify(testStruct)));
        //const msghash = Buffer.from(sha256.arrayBuffer("test sig"));
        console.log("msghash: ", msghash);

        // holder(Wallet)
        const signature1 = bls.default.sign(ms.privateKey.toBytes(), msghash, domain);

        // Issuer(Government)
        const signature2 = bls.default.sign(issuer.privateKey.toBytes(), msghash, domain);

        // Issuer(Government)
        const aggregatesig = bls.default.aggregateSignatures([signature1, signature2]);
        
        // verifier(Petshop) - aggregate public keys
        const aggregatepk = bls.default.aggregatePubkeys([ms.publicKey.toBytesCompressed(), issuer.publicKey.toBytesCompressed()]);

        // verifier(Petshop)
        const result = bls.default.verifyMultiple([aggregatepk],[msghash],aggregatesig,domain);
        console.log(result)
        this.setState({result})
    }

    render () {
        let contents = null;
        if (this.state.do) {
            contents = (<p>{this.state.result}</p>);
        } else {
            contents = (
                <button type="button" className="btn btn-default btn-adopt" onClick={this.blstest}>
                test
                </button>);
        }

        return (
            <div>
                <div> {contents} </div>
                <br/>
                <div> {this.state.result !== null ? ''+this.state.result : ''} </div>
            </div>
        )
    }
}

export default connect(
    (state, props) => {
        return {
        }
    },
    (dispatch) => ({
    })
  )(BlsTest)
