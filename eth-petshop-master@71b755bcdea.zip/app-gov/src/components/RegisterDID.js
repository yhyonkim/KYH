import React from 'react';
import { connect } from 'react-redux';

class RegisterDID extends React.Component {
    componentDidMount = async () => {
        const { keyPair, registerDID } = this.props;

        const privateKey = process.env.REACT_APP_GOV_PRIVATE_KEY;
        const publicKey = '0x' + keyPair.publicKey.toString('hex');
        const didAddrPair = process.env.REACT_APP_GOV_DID_ADDR_PAIR.split(',');
        
        registerDID(didAddrPair, privateKey, publicKey);
    }

    render() {
        return (
           null
        )
    }
}
export default connect(
    (state) => ({
        uport: state.appReducer.uport,
        contracts: state.contracts,
        user: state.appReducer.user,
        keyPair: state.appReducer.keyPair,
        state,
    }),
    (dispatch) => ({
        registerDID: (didAddrPair, privateKey, publicKey) => dispatch({ type: 'REGISTER_DID', didAddrPair, privateKey, publicKey }),
    })
)(RegisterDID)
