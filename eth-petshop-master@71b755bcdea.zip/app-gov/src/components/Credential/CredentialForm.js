import React, { Component } from 'react'
import { connect } from 'react-redux'
import AccumulatorSelect from '../Accumulator/AccumulatorSelect'
import IssueCredential from './IssueCredential';

import { Row, Col, Popover, Icon } from 'antd';

class CredentialForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: {},
            validity: {},
            dataKey: null,
        }
    }

    componentDidMount = () => {
        const { drizzle, schemaID, value, validity } = this.props;
        const id = schemaID;
        const contract = drizzle.contracts.Schema;
        const dataKey = contract.methods["get"].cacheCall(id);
        this.props.addSchemaKey(id, dataKey);
        this.setState({ dataKey, value, validity });
    }

    handleChange = (e) => {
        const key = e.target.getAttribute('id');
        const val = e.target.value;
        const regex = e.target.getAttribute('placeholder');
        const validity = { ...this.state.validity };
        validity[key] = this.checkString(val, regex);
        const value = { ...this.state.value, orig: this.props.origUserInfo };
        value[key] = val;
        this.setState({ value, validity })
        this.props.setInputValue(value, validity);
    }

    checkString = (target, regex) => {
        const r = RegExp(regex);
        return r.test(target);
    }

    checkForm = (length) => {
        if (this.state.validity && Object.values(this.state.validity).length < length) return false;
        return this.props.selectedAcc && Object.values(this.state.validity).every(x => x);
    }

    renderInput = (properties, key) => {
        const regex = properties[key].pattern
        const validity = this.props.validity;
        const valid = validity[key];
        return (
                <div className="input-group" key={key} style={{ margin: '15px' }}>
                    <span className="input-group-addon">{key}</span>
                    <input className="form-control" id={key} defaultValue={this.state.value[key]} type="text" placeholder={regex} />
                    <span className="input-group-addon">
                        {valid ? <Icon type="check-circle" theme="twoTone" twoToneColor="#52c41a" /> : <Icon type="close-circle" theme="twoTone" twoToneColor="#eb2f96" />}
                    </span>
                </div>
        )
    }

    render() {
        const { schemaID, contracts } = this.props;
        const dataKey = this.state.dataKey;
        let title = null;
        let properties = null;
        let keys = [];
        if (!contracts) return null;
        const schema = contracts.Schema.get[dataKey] && JSON.parse(contracts.Schema.get[dataKey].value);

        if (schema && schema.properties) {
            title = Object.keys(schema.properties)[0];
            properties = schema.properties[title].properties;
            keys = Object.keys(properties);
        }
        return (
            <div>
                <form onSubmit={this.handleSubmit} onChange={this.handleChange}>
                    <div className="wrap">
                        <div className="content padding">
                            <Row>
                                <Col span={12}>
                                    <div style={{marginBottom:'15px'}}><b>Select an Accumulator</b></div>
                                    <AccumulatorSelect drizzle={this.props.drizzle} />
                                </Col>
                                <Col span={12}>
                                    <b>Claims</b>
                                    {keys.length > 0 && keys.map((key) => this.renderInput(properties, key))}
                                    <div style={{float: 'right', marginRight: '15px'}}>
                                        {!this.checkForm(keys.length)?
                                        <Popover content={<p>Input value not valid</p>}>
                                            <IssueCredential drizzle={this.props.drizzle} disabled onSubmit={this.handleSubmit}/>
                                        </Popover>
                                        :
                                            <IssueCredential drizzle={this.props.drizzle} schemaID={schemaID}/>
                                        }
                                    </div>
                                </Col>
                            </Row>
                        </div>
                    </div>
                    <br />
                </form>
            </div>
        )
    }
}

export default connect(
    (state) => {
        const { user, uport, name, birth, address, showRegistrationForm } = state.appReducer;
        return {
            user: user,
            uport: uport,
            showRegistrationForm: showRegistrationForm,
            name: name,
            birth: birth,
            address: address,
            accumulator: state.appReducer.accumulator,
            credentialList: state.appReducer.credentialList,
            selectedAcc: state.appReducer.selectedAcc,
            contracts: state.contracts,
            schemaKeys: state.appReducer.schemaKeys,
            value: state.appReducer.value,
            origUserInfo: state.appReducer.origUserInfo,
            validity: state.appReducer.validity,
            state
        }
    },
    (dispatch) => {
        return {
            addSchemaKey: (id, dataKey) => dispatch({ type: 'ADD_SCHEMA_KEY', key: { id: dataKey } }),
            selectSchema: (value) => dispatch({ type: 'SELECT_ACCUMULATOR', value }),
            setInputValue: (value, validity) => dispatch({ type: 'SET_INPUT_VALUE', value, validity })
        }
    }
)(CredentialForm)
