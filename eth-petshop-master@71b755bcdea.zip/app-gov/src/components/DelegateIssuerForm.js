import React from 'react';
import { connect } from 'react-redux';
import DelegateIssuer from './DelegateIssuer';
import { Modal, Button, Icon, Alert } from 'antd';

class DelegateIssuerForm extends React.Component {
    state = {
        confirmLoading: false,
    }
    handleOk = () => {
        this.props.showDelegateModal();
    };
    handleCancel = () => {
        this.props.hideDelegateModal();
    };
    render() {
        const { onQualificationPeriod, initDelegationForm, onTargetId, qualificationPeriod, targetId, isDelegated } = this.props;
        const { DelegateModal } = this.props;
        return (
            <span style={this.props.style}>
                <Button onClick={this.handleOk}><Icon type="edit" />Delegated Issuer 등록</Button>
                <Modal
                    width="90%"
                    title="Delegated Issuer 등록"
                    visible={DelegateModal}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    footer={[
                        <Button key="back" onClick={this.handleCancel}>
                            돌아가기
                        </Button>
                    ]}
                >
                    <div className="steps-content">
                        <form>
                            <div className="input-group" style={{ width: '30%', marginBottom: '15px' }}>
                                <span className="input-group-addon">기간 (ms) : </span>
                                <input id="qualificationPeriod" className="form-control" type="text" value={qualificationPeriod} onChange={onQualificationPeriod} />
                            </div>
                            <div className="input-group" style={{ width: '100%', marginBottom: '15px' }}>
                                <span className="input-group-addon">위임할 상대의 DID : </span>
                                <input id="targetID" className="form-control" type="text" value={targetId} onChange={onTargetId} />
                            </div>
                            <br />
                            <span style={{display:'inline-flex'}}>
                                <Button onClick={initDelegationForm}>
                                    <Icon type="redo" twoToneColor="#eb2f96"></Icon> 설정 초기화
                                </Button>
                                <DelegateIssuer drizzle={this.props.drizzle} />
                            </span>
                            <br/>
                            {isDelegated ? <Alert style={{width: '300px', margin: 'auto', marginTop: '20px'}} type="success" showIcon message="위임이 성공적으로 완료되었습니다."></Alert> : <div></div>}

                        </form>
                    </div>
                </Modal>
            </span>
        )
    }
}

export default connect(
    (state) => ({
        qualificationPeriod: state.appReducer.qualificationPeriod,
        targetId: state.appReducer.targetId,
        showDelegationForm: state.appReducer.showDelegationForm,
        isDelegated: state.appReducer.isDelegated,
        DelegateModal: state.appReducer.DelegateModal,
    }),
    (dispatch) => ({
        onQualificationPeriod: (event) => dispatch({
            type: 'DELEGATE_QUALIFICATION_SET_PERIOD'
            , value: event.target.value
        }),
        onTargetId: (event) => dispatch({
            type: 'DELEGATE_QUALIFICATION_SET_TARGET_ID'
            , value: event.target.value
        }),
        toggleDelegationForm: () => dispatch({ type: 'TOGGLE_DELEGATION' }),
        initDelegationForm: () => dispatch({ type: 'INIT_DELEGATION_FORM' }),
        showDelegateModal: () => dispatch({ type: 'SHOW_DELEGATE_MODAL' }),
        hideDelegateModal: () => dispatch({ type: 'HIDE_DELEGATE_MODAL' }),
    })
)(DelegateIssuerForm)
