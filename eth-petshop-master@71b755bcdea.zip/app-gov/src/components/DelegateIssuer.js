import React from "react";
import { connect } from 'react-redux';
import { Button, Icon } from 'antd';

class DelegateIssuer extends React.Component {
    render() {
        const { delegateQualification, targetId, period, state, drizzle } = this.props;
        return (
            <span style={{marginLeft: '20px'}}>
                <Button onClick={() => delegateQualification(targetId, period, 'Birthdate Credential', drizzle, state)}>
                    <Icon type="crown" /> 자격위임
                </Button>
            </span>
        )
    }
}

export default connect(
    (state, props) => (
        {
            transactions: state.transactions,
            transactionStack: state.transactionStack,
            targetId: state.appReducer.targetId,
            period: state.appReducer.qualificationPeriod,
            state: state,
            delegateStatus: state.appReducer.delegateStatus,
            schemaJsonCorrect: state.appReducer.schemaJsonCorrect,
        }),
    (dispatch) => ({
        delegateQualification: (targetId, period, qualType, drizzle, state) => dispatch({
            type: 'DELEGATE_QUALIFICATION_REQUEST'
            , request: {
                targetId: targetId,
                period: period,
                drizzle: drizzle,
                qualType: qualType,
                state: state
            }
        }),
        onRegisterSchemaRequested: (txStackIndex) => dispatch({
            type: 'REGISTER_SCHEMA_REQUESTED'
            , txStackIndex: txStackIndex
        }),
    })
)(DelegateIssuer);
