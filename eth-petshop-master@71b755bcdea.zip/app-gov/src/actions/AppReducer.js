import { uportConnect } from '../utilities/uportSetup';

let initialState = {
  uport: uportConnect.state,
  schema: `{
      "type": "object",
      "properties": {
        "Birthdate Credential": {
          "type": "object",
          "properties": {
            "year": {
              "type": "string",
              "pattern":"^[0-9]{4}$"
              },
              "month": {
              "type": "string",
              "pattern":"^[0-9]{2}$"
              },
               "day": {
              "type": "string",
              "pattern":"^[0-9]{2}$"
              }
          }
        }
      }
    }`,
  schemaId: '',
  targetId: '',
  credTypeBirth: 'Birthdate Credential',
  qualificationPeriod: 0,
  accumulator: [],
  keyPair: sessionStorage.getItem('keyPair') ? JSON.parse(sessionStorage.getItem('keyPair')) : null,
  credentialList: sessionStorage.getItem('credList') ? JSON.parse(sessionStorage.getItem('credList')) : {},
  usedAccId: new Set(),
  schemaJsonCorrect: true,
  user: sessionStorage.getItem('user') && sessionStorage.getItem('user') !== "undefined" ? JSON.parse(sessionStorage.getItem('user')) : undefined,
  SchemaModal: false,
  showDelegationForm: false,
  authStepCurrent: sessionStorage.getItem('user') && sessionStorage.getItem('user') !== "undefined" ? 2 : 0,
  accumulatorCap: 20,
  schemaKeys: {},
  schemaTitles: {},
  value: {},
  origUserInfo: {},
  validity: {},
  pendingSchema: false,
  gotSchema: false,
}

export default (state = initialState, action) => {
  switch (action.type) {
    case 'ADD_ACCUMULATOR_LIST':
      let accumulatorList = state.accumulatorList ? state.accumulatorList : [];
      accumulatorList.unshift(action.acc);
      return {
        ...state,
        accumulatorList,
      }
    case 'ADD_ACCUMULATOR_KEY':
      return {
        ...state,
        accumulatorKey: action.dataKey,
      }
    case 'SELECT_ACCUMULATOR':
      return {
        ...state,
        selectedAcc: action.value,
      }
    case 'CONNECT_UPORT_BEGIN':
      return {
        ...state,
        didAuthLoading: true
      };
    case 'CONNECT_UPORT_SUCCESS':
      sessionStorage.setItem('user', JSON.stringify(action.user));
      return {
        ...state,
        user: action.user,
        didAuthLoading: false
      }
    case 'CONNECT_UPORT_FAILED':
      return {
        ...state,
        didAuthLoading: false
      }
    case 'DISCONNECT_UPORT_BEGIN':
      return {
        ...state,
        didAuthLoading: true
      };
    case 'DISCONNECT_UPORT_SUCCESS':
      sessionStorage.removeItem('user');
      return {
        ...state,
        user: undefined,
        didAuthLoading: false,
        authStepCurrent: 0,
      }
    case 'DISCONNECT_UPORT_FAILED':
      return {
        ...state,
        didAuthLoading: false
      }
    case 'DISCONNECT_UPORT':
      sessionStorage.removeItem('user');
      return {
        ...state,
        user: undefined,
        authStepCurrent: 0,
      }
    case 'SHOW_REGISTRATION_FORM':
      return {
        ...state,
        name: action.value,
        showRegistrationForm: true
      }
    case 'REGISTRATION_INFO_SET_NAME':
      return {
        ...state,
        name: action.value,
      }
    case 'REGISTRATION_INFO_SET_BIRTHDAY':
      return {
        ...state,
        birth: action.value,
      }
    case 'REGISTRATION_INFO_SET_ADDRESS':
      return {
        ...state,
        address: action.value,
      }
    case 'ISSUE_CREDENTIAL_SUCCESS':
      return {
        ...state,
        credentialTransfered: action.credentialTransfered,
      }
    case 'ISSUE_CREDENTIAL_NAME_SUCCESS':
      return {
        ...state,
        credentialTransfered: action.credentialTransfered,
      }
    case 'ISSUE_CREDENTIAL_BIRTHDATE_SUCCESS':
      return {
        ...state,
        credentialTransfered: action.credentialTransfered,
      }
    case 'ISSUE_CREDENTIAL_ADDRESS_SUCCESS':
      return {
        ...state,
        credentialTransfered: action.credentialTransfered,
      }
    case 'ISSUE_CREDENTIAL_SCHEMA_SUCCESS':
      return {
        ...state,
        credentialTransfered: action.credentialTransfered,
      }
    case 'DISCONNECT_UPORT_SUCCESS':
      return {
        ...state,
        user: null,
        credentialTransfered: null,
        showRegistrationForm: false,
        name: null,
        birth: null,
        address: null,
      }
    case 'REGISTER_SCHEMA_SET_SCHEMA':
      return {
        ...state,
        schema: action.value,
        schemaJsonCorrect: true,
      }
    case 'REGISTER_SCHEMA_SET_ID':
      return {
        ...state,
        schemaId: action.value,
      }
    case 'REGISTER_SCHEMA_GENERATE_ID':
      return {
        ...state,
        schemaId: action.value,
      }
    case 'REGISTER_SCHEMA_REQUESTED':
      return {
        ...state,
        txStackIndex: action.txStackIndex,
      }
    case 'SCHEMA_JSON_FORMAT_ERROR':
      return {
        ...state,
        schemaJsonCorrect: false,
      }
    case 'SETUP_ACCUMULATOR':
      return {
        ...state,
        accumulator: action.value,
        usedAccId: action.used
      }
    case 'ADD_NEW_CREDENTIAL':
      sessionStorage.setItem('credList', JSON.stringify(action.value))
      return {
        ...state,
        credentialList: action.value,
      }
    case 'UPDATE_CREDENTIAL':
      sessionStorage.setItem('credList', JSON.stringify(action.value))
      return {
        ...state,
        credentialList: action.value,
      }
    case 'SET_REVOKED':
      let credentialList = state.credentialList;
      credentialList[action.id].nonrevocation = false;
      sessionStorage.setItem('credList', JSON.stringify(credentialList))
      return {
        ...state,
        credentialList: credentialList,
      }
    case 'CANCEL_REVOKED':
      credentialList = state.credentialList;
      credentialList[action.id].nonrevocation = true;
      sessionStorage.setItem('credList', JSON.stringify(credentialList))
      return {
        ...state,
        credentialList: credentialList,
      }
    case 'SHOW_SCHEMA_MODAL':
      return {
        ...state,
        SchemaModal: true,
      }
    case 'HIDE_SCHEMA_MODAL':
      return {
        ...state,
        SchemaModal: false,
      }
    case 'SHOW_DELEGATE_MODAL':
      return {
        ...state,
        DelegateModal: true,
      }
    case 'HIDE_DELEGATE_MODAL':
      return {
        ...state,
        DelegateModal: false,
      }
    case 'DELEGATE_QUALIFICATION_SET_PERIOD':
      return {
        ...state,
        isDelegated: false,
        qualificationPeriod: action.value,
      }
    case 'DELEGATE_QUALIFICATION_SET_TARGET_ID':
      return {
        ...state,
        isDelegated: false,
        targetId: action.value,
      }
    case 'DELEGATE_QUALIFICATION_SUCCESS':
      return {
        ...state,
        isDelegated: action.result,
      }
    case 'TOGGLE_DELEGATION':
      return {
        ...state,
        isDelegated: false,
        showDelegationForm: !state.showDelegationForm,
      }
    case 'INIT_DELEGATION_FORM':
      return {
        ...state,
        qualificationPeriod: 0,
        targetId: '',
        isDelegated: false,
      }
    case 'AUTH_STEP':
      if (action.position) return { ...state, authStepCurrent: action.position }
      var current = state.authStepCurrent ? state.authStepCurrent : 0;
      current = current + action.move;
      return {
        ...state,
        authStepCurrent: current,
      }
    case 'ADD_SCHEMA_KEY':
      const schemaKeys = state.schemaKeys;
      schemaKeys[action.id] = action.dataKey;
      return {
        ...state,
        schemaKeys
      }
    case 'SET_SCHEMA_TITLE':
      const schemaTitles = state.schemaTitles;
      schemaTitles[action.id] = action.title;
      return {
        ...state,
        schemaTitles
      }
    case 'SET_ORIG_USERINFO':
      const origUserInfo = action.origUserInfo;
      return {
        ...state,
        origUserInfo,
      }
    case 'SET_INPUT_VALUE':
      const value = action.value;
      const validity = action.validity;
      return {
        ...state,
        value,
        validity
      }
    case 'RESET_SCHEMA':
      return {
        ...state,
        pendingSchema: false,
        gotSchema: false,
      }
    case 'PENDING_SCHEMA':
      return {
        ...state,
        pendingSchema: true,
      }
    case 'GOT_SCHEMA':
      return {
        ...state,
        pendingSchema: false,
        gotSchema: true,
      }
    case 'SET_SIG':
      return {
        ...state,
        sig: action.sig
      }
    case 'SET_USER_SIGNATURE':
      return {
        ...state,
        userSignature: action.userSignature
      }
    case 'SET_VERF':
      let verf = action.verf;
      verf.claim['Birthdate Credential']['aggregatedSig'] = state.sig;
      return {
        ...state,
        verf: verf
      }
    case 'SET_KEY_PAIR':
      return {
        ...state,
        keyPair: action.keyPair
      }
    default:
      return state
  }
}
