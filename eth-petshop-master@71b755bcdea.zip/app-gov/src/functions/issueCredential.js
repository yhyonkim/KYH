import { select, put } from 'redux-saga/effects'
import { uportConnect } from '../utilities/uportSetup';
const bls = require('@chainsafe/bls');
const sha256 = require('js-sha256');

const Time30Days = () => Math.floor(new Date().getTime()) + 30 * 24 * 60 * 60 * 1000;

export function* issueCredentialSchema(args){
    const {result, accId, accIndex, accWitness} = args[1];
    const revocation = {accId:accId, accIndex:accIndex, accWit:accWitness, accV: args[2]};
    const title = result['title'];
    const content = result['value'];
    const claim = {};
    claim[title] = {'schemaId': result['schemaId'], ...content, 'Revocation':revocation};
    
    const verf = {
      exp: Time30Days(),
      claim,
      vc: [],
    //   sub: user.did, // uPortConnect() 안하고 사용할거면 여기에다가 uport의 did 값을 이런식으로 넣어줘야합니다. 안그러면 popup만 뜨고 저장이 안됩니다.
    //   iss: uport.keypair.did, // PortConnect() 안하고 사용할거면 여기에다가 uport의 did 값을 이런식으로 넣어줘야합니다. 안그러면 PETSHOP에서 확인이 안됩니다.
    };

    var state = yield select();
    const domain = Buffer.alloc(8, 0);

    const userSignature = new Uint8Array(state.appReducer.userSignature);

    const blsMsg = {...content, revocation: revocation};
    console.log("BLS에 사용되는 Message: ", blsMsg);
    
    const msghash = Buffer.from(sha256.arrayBuffer(JSON.stringify(blsMsg)));
    // 사용자 정보에 대한  발급 기관이 만든 signature
    const signature = bls.default.sign(state.appReducer.keyPair.privateKey, msghash, domain);
    
    // 두 signature를 합한 것
    const aggregatedSig = bls.default.aggregateSignatures([signature, userSignature]).toString('hex');
    yield put({ type: 'SET_SIG', sig: aggregatedSig });

    // 만약에 Signature된 verf가 있다면 그걸로 교체해서 보낸다
    // Gov의 Public key: 93c864b11aa111bbe2ad0dd9210d88465adc482a6590ea7fbf93a487dc01dcdf123d249348ba9125eb90ce00fe6b14ad
    yield put({type:'SET_VERF', verf});
    state = yield select(); // sig 값이 설정된 verification을 얻기 위해 다시 접근

    return new Promise((resolve, reject) => {
      uportConnect.sendVerification(state.appReducer.verf)
        .then(() => {
          return resolve(true);
        });
    });
}
