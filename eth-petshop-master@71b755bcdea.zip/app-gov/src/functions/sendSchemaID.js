import io from 'socket.io-client';
import { decodeJWT } from 'did-jwt'

function sendSchemaID(args) {
    return new Promise((resolve, reject) => {
        try {
            const schemaID = args[0];

            const endpoint = process.env.REACT_APP_PROXY_ADDR ? process.env.REACT_APP_PROXY_ADDR : "http://127.0.0.1:3030/";
            const socket = io(endpoint);
            const did = process.env.REACT_APP_DID;
            socket.emit('register', did);
            socket.emit('request', {
                iss: did,
                type: 'schemaID',
                aud: process.env.REACT_APP_AGENT_DID,
                token: schemaID,
            })

            socket.on('response', (res) => {
                console.log('response data: ', res);
                if (res.type === 'userInfo') {
                    const retval = {};
                    retval.userSignature = res.signature;
                    retval.userInfo = res.userInfo;
                    retval.validity = res.validity;
                    resolve(retval);
                } else {
                    console.log('response', decodeJWT(res.payload));
                    resolve(res);
                }
                socket.close();
            })
        } catch (e) {
            reject(e);
        }
    });
}

export default sendSchemaID;
