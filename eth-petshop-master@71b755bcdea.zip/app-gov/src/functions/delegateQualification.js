import { delegateContract, delegateContractAddress, web3 } from '../utilities/uportSetup';
import { getEthAddress } from '../utilities/registryCaller';

async function delegateQualification(args) {
    return new Promise(async (resolve, reject) => {
        console.log('delegateQualification args: ', args);

        // const issuerId = args.state.accounts[0];
        const privateKey = process.env.REACT_APP_GOV_PRIVATE_KEY;
        const issuerID = process.env.REACT_APP_GOV_ADDR;
        const qualType = args.qualType;
        const targetDID = args.targetId;
        const qualificationPeriod = args.period;
    
        const targetAddr = await getEthAddress(targetDID);

        let sendingData = delegateContract.methods.addDelegate(
            issuerID,
            web3.utils.asciiToHex(qualType),
            targetAddr,
            qualificationPeriod
        ).encodeABI();
    
        try {
            // define tx information
            var tx = {
                to: delegateContractAddress,
                data: sendingData,
                gas: 1000000,
                gasLimit: 1000000,
            }
    
            // sign transaction
            web3.eth.accounts.signTransaction(tx, privateKey, (err, signed) => {
                if (err) { console.log("Delegation signTransaction err: ", err); }
                else {
                    console.log("Delegation signTransaction signed: ", signed);
    
                    // send signed transaction
                    web3.eth.sendSignedTransaction(signed.rawTransaction, (err, res) => {
                        if (err) { console.log("Delegation sendSignedTransaction err: ", err); }
                        else { console.log("Delegation sendSignedTransaction res: ", res); }
                    }).on('receipt', receipt => { // listening 'receipt' message
                        console.log("Delegation receipt: ", receipt);
                        resolve(receipt);
                    });
                }
            });
        } catch (error) {
            console.error("Delegation addDelegate error: ", error);
        }
    })
}

export default delegateQualification;