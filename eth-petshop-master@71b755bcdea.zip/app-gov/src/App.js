import React, { Component } from 'react'
import { connect } from 'react-redux'
import './App.css';
import DidConnector from './components/DidConnector';
import AccumulatorList from './components/Accumulator/AccumulatorList';
import AccumulatorRegister from './components/Accumulator/AccumulatorRegister';
import { CredentialList, CredSchemaList } from './components/Credential';
import { SchemaList, SchemaRegisterForm } from './components/Schema';
import { Layout, Menu, Icon, Row } from 'antd';
import { hexStringToBytes } from './utilities/utils';
import DelegateIssuerForm from './components/DelegateIssuerForm';
import RegisterDID from './components/RegisterDID';
const bls = require('@chainsafe/bls');

const { SubMenu } = Menu;
const { Header, Sider } = Layout;

class App extends Component {
  state = {
    selected: 1,
    collapsed: true,
  };

  componentDidMount() {
    const keyPair = {};
    keyPair.privateKey = hexStringToBytes(process.env.REACT_APP_GOV_PRIVATE_KEY);
    keyPair.publicKey = bls.default.generatePublicKey(keyPair.privateKey);

    this.props.setKeyPair(keyPair);
  }

  onCollapse = collapsed => {
    this.setState({ collapsed });
  };

  onSelect = selected => {
    this.setState({ selected: selected.key });
  }
  renderTitle = () => {
    return this.titles[this.state.selected];
  }

  renderContents = () => {
    return this.contents[this.state.selected];
  }

  renderButton = () => {
    return this.buttons[this.state.selected];
  }

  titles = [
    null,
    "Schema List",
    "Accumulator List",
    "Credential List",
  ]

  contents = [
    null,
    <SchemaList drizzle={this.props.drizzle} />,
    <AccumulatorList drizzle={this.props.drizzle} />,
    <CredentialList drizzle={this.props.drizzle} />
  ]

  buttons = [
    null,
    <SchemaRegisterForm drizzle={this.props.drizzle} />,
    <AccumulatorRegister drizzle={this.props.drizzle} />,
    null,
  ]

  render() {
    const { drizzleInitialized } = this.props;
    if (!drizzleInitialized) return "Loading drizzle...";
    console.log(this.props.user);
    return (
      <Layout>
        <Header className="header" style={{ display: 'inherit', paddingLeft: '10px', }}>
          <div style={{ color: 'white', fontSize: '1.2em', margin: '0 30px 0 10px', lineHeight: '64px', minWidth: '1px'}}>
            <Icon type="bank" />&nbsp;
            Government
          </div>
          <Menu
            theme="dark"
            mode="horizontal"
            defaultSelectedKeys={['1']}
            style={{ lineHeight: '68px', zIndex: '300'}}
            onSelect={this.onSelect}
          >
            <Menu.Item key="1"><Icon type='layout' />Schema Registry</Menu.Item>
            <Menu.Item key="2"><Icon type='calculator' />Accumulators</Menu.Item>
            <Menu.Item key="3"><Icon type='form' />Credentials</Menu.Item>
          </Menu>
          <span style={{color:'white', minWith: '1px', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden', lineHeight: '60px'}}>
            {process.env.REACT_APP_DID}
          </span>
          <DidConnector />
        </Header>
        <Layout style={{ minHeight: '100vh' }}>
          {this.sider}
          <Layout style={{ padding: '24px' }}>
            <Row>
              <div>
                <h3 style={{ display: 'inline' }}>{this.renderTitle()}</h3>
                <span style={{ float: 'right' }}>{this.renderButton()}</span>
              </div>
              <div className="tab-content">
                {this.renderContents()}
              </div>
            </Row>
            <Row >
              <div style={{display: !this.props.user?'none':'block'}}>
                <div>
                  <h3 style={{ display: 'inline' }}>Issue Credential</h3>
                <span style={{ float: 'right' }}><DelegateIssuerForm drizzle={this.props.drizzle}/></span>
                </div>
                <div className="tab-content">
                  <CredSchemaList drizzle={this.props.drizzle} />
                </div>
              </div>
            </Row>
          </Layout>
        </Layout>
        <RegisterDID drizzle={this.props.drizzle} />
      </Layout>
    );
  }

  sider =
      <Sider collapsible collapsed={this.state.collapsed} onCollapse={this.onCollapse}>
        <Menu theme="dark" defaultSelectedKeys={['1']} mode="inline">
          <Menu.Item key="1">
            <Icon type="pie-chart" />
            <DidConnector />
          </Menu.Item>
          <Menu.Item key="2">
            <Icon type="desktop" />
            <span>Option 2</span>
          </Menu.Item>
          <SubMenu
            key="sub1"
            title={
              <span>
                <Icon type="user" />
                <span>User</span>
              </span>
            }
          >
            <Menu.Item key="3">Tom</Menu.Item>
            <Menu.Item key="4">Bill</Menu.Item>
            <Menu.Item key="5">Alex</Menu.Item>
          </SubMenu>
          <SubMenu
            key="sub2"
            title={
              <span>
                <Icon type="team" />
                <span>Team</span>
              </span>
            }
          >
            <Menu.Item key="6">Team 1</Menu.Item>
            <Menu.Item key="8">Team 2</Menu.Item>
          </SubMenu>
          <Menu.Item key="9">
            <Icon type="file" />
            <span>File</span>
          </Menu.Item>
        </Menu>
      </Sider>
}

export default connect(
  (state) => ({
    drizzleInitialized: state.drizzleStatus.initialized,
    user: state.appReducer.user,
  }),
  (dispatch) => ({
      setKeyPair: (keyPair) => dispatch({ type: 'SET_KEY_PAIR', keyPair}),
  })
)(App)
