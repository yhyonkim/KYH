var app = require('express')();
var http = require('http').createServer(app);
var SocketIo = require('socket.io');

app.get('/', function(req, res){
    res.send('<h1>Welcom to Cloud Agent!</h1>');
});

const server = http.listen(3030, function(){
  console.log('listening on *:3030');
});

const io = SocketIo(server, {
    pingInterval: 1000000,
    pingTimeout: 500000,
});

userList = {};
userList2 = {};

io.on('connection', (socket) => {
    socket.on('request', (token) => {
        if (!token) return;
        const did = token.aud;
        const toAddr = userList[did];
        for (var i = 0; toAddr && i < toAddr.length; i++){
            io.to(toAddr[i]).emit('request', token);
        }
    });
    socket.on('bulletProof', (token) => {
        if (!token) return;
        const did = token.to;
        const toAddr = userList[did];
        for (var i = 0; toAddr && i < toAddr.length; i++){
            io.to(toAddr[i]).emit('bulletProof', token);
            console.log('bulletProof To: ',toAddr[i], ' ', token);
        }
    });
    socket.on('response', (token) => {
        if (!token) return;
        const did = token.aud;
        const toAddr = userList[did];
        console.log('ToADDR:', toAddr);
        for (var i = 0; toAddr && i < toAddr.length; i++){
            io.to(toAddr[i]).emit('response', token);
            console.log('To: ',toAddr[i], ' ', token);
        }

        console.log('[USERLIST]');
        Object.keys(userList).forEach((key) => console.log(key, " ", userList[key]));
        console.log('---END---');
    });

    socket.on('disconnect', function() {
        console.log('Socket lost ' + socket.id);
        const did = userList2[socket.id];
        // remove from userList
        for (var i = 0; userList[did] && i < userList[did].length; i++) {
            if (userList[did][i] === socket.id) {
                if (userList[did].length === 1) {
                    userList[did] = undefined;
                } else {
                    userList[did].splice(i, 1);
                    i--;
                }
            }
        }
        console.log('After Disconnect:', userList[did]);
        delete userList2[socket.id];
    })

    socket.on('reconnect', ()=> {console.log('REEEEECONNECT')});

    socket.on('register', (did) => {
        console.log('Registered ', did, ' on ', socket.id)
        console.log(userList[did]);
        if (userList[did]) {
            userList[did].push(socket.id)
        } else {
            userList[did] = [socket.id];
        }
        console.log(userList[did]);
        userList2[socket.id] = did;
    })

    socket.on('getList', () => {
        console.log('[USERLIST]');
        Object.keys(userList).forEach((key) => console.log(key, " ", userList[key]));
        console.log('---END---');
    })
});
