const path = require("path");

require('dotenv').config({path: path.join(__dirname, ".env")});

module.exports = {
  // contracts_build_directory: path.join(__dirname, "app-petshop/src/contracts"),

  // See <http://truffleframework.com/docs/advanced/configuration>
  // for more about customizing your Truffle configuration!
  networks: {
    "development": {
      host: process.env.QUORUM_HOST,
      port: process.env.QUORUM_PORT,
      network_id: "*",
      type: "quorum",
      gas: 4500000,
      gasPrice:0
    },
	  "ganache" : {
		  host: process.env.GANACHE_HOST,
		  port: process.env.GANACHE_PORT,
		  network_id: "*"
	  },
  },
  compilers: {
    solc: {
      settings: {
        evmVersion: "byzantium"
      }
    }
  }
};
