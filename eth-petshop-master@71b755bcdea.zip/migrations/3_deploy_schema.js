var Schema = artifacts.require("Schema");

module.exports = function(deployer) {
	deployer.deploy(Schema);
};
