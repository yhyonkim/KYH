var Revocation = artifacts.require("Revocation");

module.exports = function(deployer) {
	deployer.deploy(Revocation);

};
