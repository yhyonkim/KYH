var Prime = artifacts.require("Primes");

module.exports = function(deployer) {
	deployer.deploy(Prime);
};
