var DIDRegister = artifacts.require("EthereumDIDRegistry");

module.exports = function(deployer) {
	deployer.deploy(DIDRegister);
};
