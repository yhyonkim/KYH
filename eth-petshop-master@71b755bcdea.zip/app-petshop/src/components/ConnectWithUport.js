import React from 'react';
import { connect } from 'react-redux';

class ConnectWithUport extends React.Component {
    render () {
        const { onConnectRequest } = this.props;
        return (
            <button className="btn btn-default btn-adopt" onClick={onConnectRequest}>
            Connect with uPort
            </button>
        )
    }
}
  
export default connect(
    (state) => ({
        uport: state.appReducer.uport,
        state
    }),
    (dispatch) => ({
        onConnectRequest: () => dispatch({ type: 'CONNECT_UPORT_REQUEST', request: {
            requested: ['name', 'phone', 'email', 'country'],
            notifications: false,
            vc: []
      }})
    })
)(ConnectWithUport)
  