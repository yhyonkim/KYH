import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Link } from 'react-router-dom'
import {Join, SubText, SubLine, ErrorText, NormalText, Button} from "../styles/AppStyles";
import { newKey } from '../utilities/utils';

const key_gov = newKey();
const key_zkp = newKey();

class Subscription extends Component {
  state = {
    exp: null,
    holder: null,
  }

  render () {
    const { drizzleInitialized, verification } = this.props;
    if ( !drizzleInitialized ) return "Loading Drizzle...";
    
    const { verifyCredential, isAdult, verifyAttr, msgVerifyAdult, issueCredential, subsInfo, uport, drizzle, contractAccount } = this.props;
    const contracts = drizzle.contracts;
    
    if (!this.state.holder && uport) {
      this.setState({holder: uport.did});
      console.log('holder Login: ', this.state.holder);
    }
    if (!this.state.exp && subsInfo && subsInfo.exp) {
      this.setState({exp: subsInfo.exp});
    }

    console.log(this.props.state);
    const verf = verification && verification[key_gov];
    return (
      <Join>
        <h3> 회원증 발급 </h3>
        <SubText> 다음 순서대로 진행해주세요. </SubText>
        <SubLine>
          <Button className="btn btn-default btn-adopt"
                  onClick={() => verifyCredential('Birthdate Credential', this.state.holder, contracts, contractAccount)}>
            성인 인증
          </Button>
          {/* { subsInfo.error ? (
              <ErrorText> {subsInfo.message} </ErrorText>
            ) : (
              <NormalText> {subsInfo.message} </NormalText>
            )
          } */}
          { verf && verf.error?
           (
              <ErrorText> { verf && verf.message} </ErrorText>
            ) : (
              <NormalText> { verf && verf.message} </NormalText>
            )
          }
        </SubLine>
        <p/>
        <SubLine>
          <Button className="btn btn-default btn-adopt"
                  onClick={() => verifyAttr('adult')}>
            성인 인증 (영지식 증명 사용)
          </Button>
          { isAdult === null || isAdult === true ? (
              <NormalText> {msgVerifyAdult} </NormalText>
            ) : (
              <ErrorText> {msgVerifyAdult} </ErrorText>
            )
          }
        </SubLine>
        <p/>
        <SubLine>
          <Button className="btn btn-default btn-adopt" 
                  disabled={!(subsInfo && subsInfo.isVerifyIdentification || isAdult === true)} 
                  onClick={() => issueCredential(subsInfo.identityName, this.state.exp)}>
            회원증 받기
          </Button>
          { (subsInfo.credentialName) ? (
            <NormalText> {subsInfo.msgMembership} </NormalText>
          ) : (<div></div>)}
        </SubLine>
        <Link to='/'>
          <Button className="btn btn-default btn-adopt"> 홈으로 </Button>
        </Link>
      </Join>
    );
    
  }
}

export default connect(
  (state) => ({
      uport: state.appReducer.uport,
      subsInfo: state.appReducer.subsInfo,
      user: state.appReducer.user,
      drizzleInitialized: state.drizzleStatus.initialized,
      contractAccount: state.accounts[0],
      isAdult: state.appReducer.isAdult,
      msgVerifyAdult: state.appReducer.msgVerifyAdult,
      verification: state.appReducer.verification,
      state,
  }),
  (dispatch) => ({
    verifyCredential: (credentialName, holder, contracts, contractAccount) => dispatch({ type: 'VERIFY_CREDENTIAL_REQUEST', request: {
      key: key_gov,
      type: credentialName,
      requested: [credentialName],
      contracts: contracts,
      contractAccount: contractAccount
    }}),
    verifyAttr: (type) => dispatch({type: 'VERIFY_ATTR_REQUEST', request: {
        type: type
    }}),
    issueCredential: (identityName, expirationPeriod) => dispatch({ type: 'ISSUE_PETSHOP_MEMBERSHIP_REQUEST', request: {
      identityName: identityName,
      notifications: false,
      exp: expirationPeriod,
    }})

  })
)(Subscription)
