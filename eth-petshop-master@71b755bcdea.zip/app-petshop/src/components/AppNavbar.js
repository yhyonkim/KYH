import React, { Component } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { withRouter, Link } from 'react-router-dom'
import * as AppActions from '../actions/AppActions'
import { NavBar, LeftArea, RightArea } from "../styles/AppStyles";
import LoginButton from './LoginButton';
import SubscriptionButton from './SubscriptionButton';
import { Button } from 'antd';

class AppNavbar extends Component {
  render() {
    // const { user } = this.props;
    return (
      <NavBar>
        <LeftArea>
          <Link to="/">
            Pet Shop
        </Link>
        </LeftArea>
        <SubscriptionButton drizzle={this.props.drizzle}/>
        <RightArea>
          <LoginButton />
        </RightArea>
      </NavBar>
    )
  }
}

function mapStateToProps(state, props) {
  return {
    uportConnected: state.appReducer.uport && state.appReducer.uport.name,
    uport: state.appReducer.uport,
    user: state.appReducer.user,
  }
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(AppActions, dispatch),
    verifyCredential: (credentialName, user) => dispatch({
      type: 'VERIFY_CREDENTIAL_REQUEST', request: {
        requested: [credentialName],
        notifications: false,
        holder: user ? user.did : process.env.REACT_APP_AGENT_DID,
        vc: []
      }
    }),
  }
}
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(AppNavbar))