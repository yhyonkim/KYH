import React from "react";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux'
import { withRouter } from 'react-router-dom';
import * as AppActions from '../actions/AppActions'


class ValidateSetup extends React.Component {
    state = {accId:11, stackId:null};

    // value * witness = accumulator of accId
    constructor(props) {
        super(props)
        this.props = props;

        this.handleClick = this.handleClick.bind(this);
    }

    handleClick() {
        const {drizzle, drizzleState} = this.props;
        const contract = drizzle.contracts.Revocation;
        console.log(contract)
        console.log(drizzleState.accounts[0])
try{
        //const stackId = contract.methods.setup(11, 5).send({from: drizzleState.accounts[0]});
        //const stackId = contract.methods.existAcc(11).send({from: drizzleState.accounts[0]});
        const stackId = contract.methods["existAcc"].cacheCall(11);

        console.log(stackId)
        this.setState({stackId});
    } catch(e) {
        console.log(e.message)
    }
    }

    // getTxStatus() {
    //     const {transactions, transactionStack} = this.props.drizzleState;
    //     const txHash = transactionStack[this.state.stackId];
    //     if(!txHash) return null;
    //     const status = transactions[txHash] && transactions[txHash].status;
    //     if(status==="success") {
    //         return true;
    //     }
    //     return false;
    // }

    render() {
        // if((this.state.stackId!==null)&&(this.getTxStatus())) {
        //     return <strong>Setup!</strong>
        // }
        return (<div>
            <button type="button" className="btn btn-default btn-adopt" onClick={this.handleClick}>
            setup</button>
        </div>);
    }


}

function wait(ms){
    var start = new Date().getTime();
    var end = start;
    while(end < start + ms) {
      end = new Date().getTime();
   }
}

function mapStateToProps (state, props) {
	return { uport: state.appReducer.uport }
}

function mapDispatchToProps (dispatch) {
	return { actions: bindActionCreators(AppActions, dispatch) }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ValidateSetup))

