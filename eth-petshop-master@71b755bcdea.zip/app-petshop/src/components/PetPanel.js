import React, { Component } from 'react';
import AdoptionStatus from "./AdoptionStatus";
import { connect } from 'react-redux';

class PetPanel extends Component {
    render() {
        const { index, pet, drizzle } = this.props;

        return (
            <div className="col-sm-6 col-md-4 col-lg-3" key={index} style={{maxWidth:'300px'}}>
                <div className="panel panel-default panel-pet">
                    <div className="panel-heading">
                        <h3 className="panel-title">{pet.name}</h3>
                    </div>
                    <div className="panel-body">
                        <img alt="140x140" data-src="holder.js/140x140" style={{ width: "100%" }} className="img-rounded img-center" src={pet.picture} data-holder-rendered="true" />
                        <br />
                        <br />
                        <strong>Breed</strong>: <span className="pet-breed">{pet.breed}</span><br />
                        <strong>Age</strong>: <span className="pet-age">{pet.age}</span><br />
                        <strong>Location</strong>: <span className="pet-location">{pet.location}</span><br />
                        <AdoptionStatus pet={pet} drizzle={drizzle}
                        />
                    </div>
                </div>
            </div>);
    }
}
const mapStateToProps = (state, props) => {
    return {}
}

const mapDispatchToProps = (dispatch) => {
    return {}
}

export default connect(mapStateToProps, mapDispatchToProps)(PetPanel)