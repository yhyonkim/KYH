import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Link } from 'react-router-dom'
import {SectionLogin, SubText, SubLine, ErrorText, NormalText, Button} from "../styles/AppStyles";

class Login extends Component {

    state = {
      holder: null,
    }

    render () {
      
      const { verifyCredential, loginPetshop, petshop, uport, user } = this.props;
      if (!this.state.holder && uport) {
        this.setState({holder: uport.did});
        console.log('holder Login: ', this.state.holder);
      }

      console.log("state: ", this.props.state);

        return (
            <SectionLogin>
              <h3> 로그인 </h3>
              <SubText> 다음 순서대로 진행해주세요.</SubText>
              <SubLine>
                <Button className="btn btn-default btn-adopt" onClick={() => verifyCredential('PetShop Membership', this.state.holder)}>
                  회원증 검사
                </Button>
                { petshop ? (
                    petshop.errorVerifyIdentification ? (
                      <ErrorText> {petshop.msgVerifyCredential} </ErrorText>
                    ) : (
                      <NormalText> {petshop.msgVerifyCredential} </NormalText>
                    )) : (
                  <NormalText> 'DID Auth' 과정을 먼저 진행하세요. </NormalText>
                )}
              </SubLine>
              <p/>
              <SubLine>
                  <Button className="btn btn-default btn-adopt" disabled={!(petshop && petshop.isVerifyIdentification)} onClick={() => loginPetshop(petshop && petshop.memberName ? petshop.memberName : "")}>
                      로그인
                  </Button>
                  { (petshop && petshop.memberName) ? (
                      user && user.name ? (
                        <SectionLogin>
                          <NormalText> {user.name} 님으로 로그인 하였습니다.</NormalText>
                        </SectionLogin>
                      ) : (
                        <NormalText> {petshop.memberName} 님 반갑습니다. </NormalText>
                      )) : (
                    <NormalText> '회원증 검사' 과정을 먼저 진행하세요. </NormalText>
                  )}
              </SubLine>
              <Link to='/'>
                <Button className="btn btn-default btn-adopt"> 홈으로 </Button>
              </Link>
            </SectionLogin>
          );
    }
}

export default connect(
  (state) => ({
      uport: state.appReducer.uport,
      petshop: state.appReducer.petshop,
      user: state.appReducer.user,
      state,
  }),
  (dispatch) => ({
    onConnectRequest: () => dispatch({ type: 'CONNECT_UPORT_REQUEST', request: {
        requested: ['name', 'address'],
        notifications: false,
        accountType: "keypair",
        type: "login",
        vc: []
    }}),
    verifyCredential: (credentialName, holder) => dispatch({ type: 'VERIFY_CREDENTIAL_REQUEST', request: {
      requested: [credentialName],
      notifications: false,
      holder: holder,
      vc: []
    }}),
    loginPetshop: (memberName) => dispatch({ type: 'LOGIN_PETSHOP_REQUEST', request: {
      memberName: memberName,
      notifications: false,
      vc: []
    }})

  })
)(Login)