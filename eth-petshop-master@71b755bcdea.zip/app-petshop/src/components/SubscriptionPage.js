import React from "react";
import { connect } from 'react-redux'
import { Collapse } from 'antd';

import IssueCredential from './IssueCredential';
const Panel = Collapse.Panel;

class SubscriptionPage extends React.Component {
  render(){
    return (
      <Collapse accordion defaultActiveKey={"1"}>
        <Panel header="민증으로 회원증 발급" key="1">
          <div style={{padding: '20px', paddingBottom: '40px'}}>
            <IssueCredential drizzle={this.props.drizzle}/>
          </div>
        </Panel>
        <Panel header="민증으로 회원증 발급 (영지식증명)" key="2">
          <div style={{padding: '20px', paddingBottom: '40px'}}>
            <IssueCredential drizzle={this.props.drizzle} mode='ZKP'/>
          </div>
        </Panel>
        <Panel header="DID Auth" key="3">
          <div style={{padding: '20px', paddingBottom: '40px'}}>
          </div>
        </Panel>
      </Collapse>
    )
  }
}

export default connect(
  (state) => ({
    state,
  }),
  (dispatch) => ({
  })
)(SubscriptionPage)
