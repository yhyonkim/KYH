import React from 'react';
import { connect } from 'react-redux';
import { Button } from 'antd';

class LoginButton extends React.Component {
    render() {
        const { user, didAuthLoading, verifyCredential, logout } = this.props;
        return (
            <span>
                {user ?
                    <span>
                        {didAuthLoading ? null : <span style={{fontSize: '14px', color: '#3f3f3f'}}>PetShop에 로그인 되었습니다. </span>}
                        <Button type="danger" loading={didAuthLoading} onClick={logout}>
                        {didAuthLoading ? `로그아웃중...` : `로그아웃`}
                        </Button>
                    </span>
                    :
                    <Button type="default" loading={didAuthLoading} onClick={()=>verifyCredential('PetShop Membership', user)}>
                        {didAuthLoading ? `연결중...` : `로그인`}
                    </Button>
                }
            </span>
        )
    }
}
export default connect(
    (state) => ({
        user: state.appReducer.user,
        didAuthLoading: state.appReducer.didAuthLoading,
        state
    }),
    (dispatch) => ({
        logout: () => dispatch({ type: 'LOGOUT_PETSHOP_REQUEST' , request: { requested: ['disconnect'], vc: [] } }),
        verifyCredential: (credentialName, user) => dispatch({ type: 'VERIFY_CREDENTIAL_REQUEST', request: {
            type: credentialName,
            requested: [credentialName],
            notifications: false,
            holder: user? user.did : process.env.REACT_APP_AGENT_DID,
            vc: []
        }}),
    })
)(LoginButton)
