import React from 'react';
import { connect } from 'react-redux';
import { isEmpty } from '../utilities/utils';
import { Button } from 'antd';

class ConnectWithUport extends React.Component {
    renderHelpMessage(user, didAuthLoading) {
        if (didAuthLoading) {
            return <div>요청을 보냈습니다. <br />기기에서 확인해주세요.</div>
        }
        return isEmpty(user) ?
            (<div>인증서 발급을 위해 서로 연결해주세요.</div>) :
            (<div>PetShop에 로그인 되었습니다.</div>)
            ;
    }
    getConnectButtonColor(user) {
        return isEmpty(user) ? "btn-default" : "btn-success";
    }
    render() {
        const { user, didAuthLoading, onConnectRequest, onDisconnectRequest } = this.props;
        return (
            <span style={this.props.style}>
                {user ?
                    <Button type="danger" loading={didAuthLoading} onClick={onDisconnectRequest}>
                        {didAuthLoading ? `Disconnecting...` : `Disconnect`}
                    </Button>
                    :
                    <Button type="default" loading={didAuthLoading} onClick={onConnectRequest}>
                        {didAuthLoading ? `Connecting...` : `Connect`}
                    </Button>
                }
                <br />
                {this.props.help && this.renderHelpMessage(user, didAuthLoading)}
            </span>
        )
    }
}
export default connect(
    (state) => ({
        user: state.appReducer.user,
        didAuthLoading: state.appReducer.didAuthLoading,
        state
    }),
    (dispatch) => ({
        onConnectRequest: () => dispatch({
            type: 'CONNECT_UPORT_REQUEST', request: {
                requested: ['name', 'phone', 'email', 'country'],
                notifications: false,
                vc: []
            }
        }),
        onDisconnectRequest: () => dispatch({ type: 'DISCONNECT_UPORT_REQUEST', request: { requested: ['disconnect'], vc: [] } })
    })
)(ConnectWithUport)
