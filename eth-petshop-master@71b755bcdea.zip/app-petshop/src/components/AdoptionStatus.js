import React from "react";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux'
import { withRouter } from 'react-router-dom';
import * as AppActions from '../actions/AppActions'
import AdoptButton from './AdoptButton';
import { adoptContract } from "../utilities/uportSetup";

class AdoptionStatus extends React.Component {
	state = {addr: undefined, adoptDeployer: undefined};

	async componentDidMount() {
		const { pet } = this.props;
		const addr = await adoptContract.methods.getAdopter(pet.id).call()
		this.setState({addr});	
	};

	isNotAdopted = (addr, account) => {
		return addr === '0x0000000000000000000000000000000000000000'
			|| addr === account
			|| addr === undefined
			;
	};

	render() {
		const { accounts } = this.props;
		const addr = this.state.addr;
		if (this.isNotAdopted(addr, process.env.REACT_APP_PETSHOP_DID_ADDR_PAIR.split(',')[1])) {
			return <AdoptButton
				pet={this.props.pet}
				drizzle={this.props.drizzle}
				drizzleState={this.props.drizzleState}
				/>;
		} else {
			return <p><strong>Adopter</strong>: {addr.substring(0,8)} </p>;
		}
	}
}

function mapStateToProps (state, props) {
	return {
		accounts: state.accounts,
	}
}

function mapDispatchToProps (dispatch) {
	return { actions: bindActionCreators(AppActions, dispatch) }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(AdoptionStatus))
