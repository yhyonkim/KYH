import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as AppActions from '../actions/AppActions';
import { uportConnect } from '../utilities/uportSetup';
import {UserName, NormalText} from "../styles/AppStyles";

class DisconnectFromUport extends React.Component {

    constructor (props) {
        super(props)
        this.logout = this.logout.bind(this);
    }

    logout () {
        uportConnect.logout();
        this.props.actions.logoutPetShop();
    }

    render () {
        const {userName} = this.props;
        return (
            <UserName >
                {userName ? (
                    <UserName>
                        <NormalText>{userName} 님, 반갑습니다.</NormalText>
                        <button className="btn btn-default btn-adopt" onClick={this.logout}>
                            로그아웃
                        </button>
                    </UserName>
                ) : (
                    <NormalText>
                        <button className="btn btn-default btn-adopt" onClick={this.logout}>
                            로그아웃
                        </button>

                    </NormalText>
                )}
                </UserName>
                
            
        )
    }
}

const mapStateToProps = (state, props) => {
    return {
      uport: state.appReducer.uport,
      userName: state.appReducer.user.name
    }
}

const mapDispatchToProps = (dispatch) => {
    return { 
        actions: bindActionCreators(AppActions, dispatch) 
    }
}
  
  export default connect(mapStateToProps, mapDispatchToProps)(DisconnectFromUport)
  