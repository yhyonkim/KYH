import React, { Component } from 'react'
import { connect } from 'react-redux'
import SubscriptionPage from './SubscriptionPage';
import { Modal, Button, Icon } from 'antd';

class SubscriptionButton extends Component {
  state = {
    ModalText: 'Default',
  }
  handleOk = () => {
    this.props.showModal();
  };

  handleCancel = () => {
    this.props.hideModal();
  };

  render() {
    const { visible } = this.props;
    return (
      <span>
        <Button onClick={this.handleOk}><Icon type="edit" />회원증 발급</Button>
        <Modal
          width="90%"
          title="회원증 발급"
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          footer= { null }
        >
          <div className="steps-content">
            <SubscriptionPage drizzle={this.props.drizzle}/>
          </div>
        </Modal>
      </span>
    );
  }
}

export default connect(
  (state) => ({
    visible: state.appReducer.showSubscription,
    state,
  }),
  (dispatch) => ({
    showModal: () => dispatch({ type: 'SHOW_SUBSCRIPTION' }),
    hideModal: () => dispatch({ type: 'HIDE_SUBSCRIPTION' })
  })
)(SubscriptionButton)
