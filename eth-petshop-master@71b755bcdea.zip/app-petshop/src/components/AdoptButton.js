import React from "react";
import { connect } from 'react-redux';
import { adoptContract, uportConnect, web3 } from "../utilities/uportSetup";
import { getEthAddress } from '../utilities/registryCaller';
import { adopt, processAdoption, getPetPrice } from '../utilities/adoptionCaller';

// const ReqId = 'setStatus';

class AdoptButton extends React.Component {
	state = { successAdopt: false, stackId: null };

	constructor(props) {
		super(props);
		uportConnect.onResponse("setStatus").then(cd => {
			console.log("credential");
			console.log(cd);
		});
	}

	handleClick = async e => {
		const { pet, user } = this.props;
		const id = pet.id;
		const petShopPrivateKey = process.env.REACT_APP_PETSHOP_PRIVATE_KEY;
		const petShopAddr = process.env.REACT_APP_PETSHOP_DID_ADDR_PAIR.split(',')[1];
		const userAddr = await getEthAddress(user.did);
		// holder 계좌 확인
		// eth.getBalance('0x506a757f347c60a97a5c2e9d07e79ede44660bf5')
		// petshop 계좌 확인
		// eth.getBalance('0x790BAA46ab9a45352683fa8d8C06377863F8E8C2')
		// holder에게 이더 충전
		// eth.sendTransaction({from:eth.accounts[0], to:'0x506a757f347c60a97a5c2e9d07e79ede44660bf5', value: web3.toWei(0.05, "ether")})
		const petPrice = await getPetPrice(id);

		adoptContract.methods.payAdoptFee(id).send({ 
			from: userAddr,
			value: Number(petPrice),
			vc:[]
		}).on('receipt', async receipt => {
			if (receipt.status === true) {
				const adoptReceipt = await adopt(id, petShopPrivateKey);
				if (adoptReceipt.status === true) {
					const processAdoptionReceipt = await processAdoption(id, userAddr, petShopPrivateKey);
					if (processAdoptionReceipt.status === true) {
						this.setState({ successAdopt: true });
					}
				}
			}
		});

	};

	render() {
		if (this.state.successAdopt) {
			return <strong>Thank you!</strong>;
		}
		return (
			<div>
				<button type="button" className="btn btn-default btn-adopt" onClick={this.handleClick} disabled={!this.props.user}>
					{!this.props.user && `Login to `}adopt</button>
			</div>
		);
	}
}

export default connect(
    (state, props) => (
    {
		user: state.appReducer.user,
    }),
    (dispatch) => ({
    })
)(AdoptButton);
