import React from "react";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux'
import { withRouter } from 'react-router-dom';
import * as AppActions from '../actions/AppActions'


class ValidateRevocation extends React.Component {
    state = {accId:"0x0000000000000000000000000000000000000000", value:5, witness:1001, result:false, data:null};

    // value * witness = accumulator of accId
    constructor(props) {
        super(props)
        this.props = props;

        this.handleClick = this.handleClick.bind(this);
    }

    handleClick() {
        const {drizzle} = this.props;
        const contract = drizzle.contracts.Revocation;

        const data = contract.methods.getAcc.cacheCall(this.state.accId);
        this.setState({data});
        console.log(data);
    }

    render() {
        if(this.state.data!==null) {
            const result = this.props.drizzleState.contracts.Revocation.getAcc[this.state.data];
            console.log(result)
            if(result) {
                let acc = this.state.value * this.state.witness;
                if(acc == result.value) { // ===를 쓰면 안 된다
                    console.log("Validate!")
                } else {
                    console.log("acc of holder : "+acc)
                    console.log("acc in ledger : "+result.value)
                }
            }
        }

        return (<div>
            <button type="button" className="btn btn-default btn-adopt" onClick={this.handleClick}>
            test</button>
        </div>);
    }

}

function mapStateToProps (state, props) {
	return { uport: state.appReducer.uport }
}

function mapDispatchToProps (dispatch) {
	return { actions: bindActionCreators(AppActions, dispatch) }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ValidateRevocation))

