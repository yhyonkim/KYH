import React from 'react';
import { connect } from 'react-redux';

class Logout extends React.Component {
    render () {
        const { onDisconnectRequest } = this.props;
        return (
            <button className="btn btn-default btn-adopt" onClick={() => onDisconnectRequest()}>
             로그아웃
            </button>
        )
    }
}
  
export default connect(
    (state) => ({
        uport: state.appReducer.uport
    }),
    (dispatch) => ({
        onDisconnectRequest: () => dispatch({ type: 'LOGOUT_PETSHOP_REQUEST' })
    })
)(Logout)
  