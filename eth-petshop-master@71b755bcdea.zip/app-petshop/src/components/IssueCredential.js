import React from "react";
import { connect } from 'react-redux'
import { Steps, Button, message, Icon, Progress } from 'antd';
import { newKey } from '../utilities/utils';
import Success from "./Success";

const { Step } = Steps;

const key = newKey();

class IssueCredential extends React.Component {
  state = {
    issued: false,
  }
  constructor(props) {
    super(props);
    const verification = {
      message: '민증을 제출하세요',
      current: 0,
      verifying: null,
    }
    this.props.setVerification(verification, key);
  }
  steps = [
    {
      title: '민증 확인',
      content: <Button onClick={()=>this.props.mode? this.props.verifyAttr('adult', this.props.drizzle.contracts) : this.props.verifyCredential('Birthdate Credential', process.env.REACT_APP_AGENT_DID, this.props.drizzle.contracts, this.props.contractAccount)}>민증 제출</Button>,
      icon: <Icon type="user"/>
    },
    {
      title: '회원증 발급',
      content: <Button onClick={()=>{this.props.issueCredential(this.props.subsInfo.msgMembership, this.props.subsInfo.exp); this.setState({issued: true});}}>회원증 발급</Button>,
      icon: <Icon type="solution"/>
    },
    {
      title: '완료',
      content: null,
      icon: <Icon type="smile-o"/>
    },
  ];

  render() {
    const { verification } = this.props;
    const error = verification && verification[key] && verification[key].error;
    const verifying = verification && verification[key] && verification[key].verifying ? verification[key].verifying : null;
    const current = verification && verification[key] && verification[key].current ? verification[key].current : 0;
    const percent = verification && verification[key] && verification[key].percent ? verification[key].percent : 0;
    const msg = verification && verification[key] && verification[key].message ? verification[key].message : 'Something wrong';
    return (
      <div>
        <Steps size="small" current={current}>
          {this.steps.map(item => (
            <Step key={item.title} title={item.title} icon={item.icon} />
          ))}
        </Steps>
          <div className="steps-content content">
            {this.steps[current].content}
            <br/>
            <div style={{textAlign: 'center'}}>
              {current === 0 && JSON.stringify(msg, null, 4) } 
              {current === 1 && '버튼을 눌러서 회원증을 발급받으세요'} 
              {current === 2 && <Success comment="회원증 발급 완료!"/>}
            </div>
            <br/>
            {(verifying && current===0) &&
            <div style={{textAlign: 'center'}}>
            <i style={{textAlign: 'center', fontFamily: 'Times', fontSize: '18px'}}>
              {verifying}
            </i>
            <br/>
            <Progress 
              status={error ? "exception" : "active"}
              strokeColor={{
                '0%': '#108ee9',
                '100%': '#87d068',
              }} percent={percent} />
            </div>

            }
          </div>
        <div className="steps-action">
          {current > 0 && (
            <Button style={{ marginRight: 8 }} onClick={() => this.props.step_prev(key)}>
              Previous
            </Button>
          )}
          {current === this.steps.length - 1 && (
            <Button id="success" className="steps-button" type="primary" onClick={() => { this.props.hideModal() ; message.success('Issue complete!')}}>
              Done
            </Button>
          )}
          {(current < this.steps.length - 1 && verification[key].verified )&& (
            <Button disabled={(current === 1 && !this.state.issued)}className="steps-button" type="primary" onClick={() => this.props.step_next(key)}>
              Next
            </Button>
          )}
        </div>
      </div>
    );
  }
}



export default connect(
    (state) => ({
      uport: state.appReducer.uport,
      subsInfo: state.appReducer.subsInfo,
      user: state.appReducer.user,
      contractAccount: state.accounts[0],
      isAdult: state.appReducer.isAdult,
      msgVerifyAdult: state.appReducer.msgVerifyAdult,
      steps: state.appReducer.steps,
      verification: state.appReducer.verification,
      state,
    }),
    (dispatch) => ({
      verifyCredential: (credentialName, holder, contracts, contractAccount) => dispatch({
        type: 'VERIFY_CREDENTIAL_REQUEST', request: {
          requested: [credentialName],
          type: credentialName,
          contracts: contracts,
          contractAccount: contractAccount,
          key: key,
        }
      }),
      verifyAttr: (type, contracts) => dispatch({
        type: 'VERIFY_ATTR_REQUEST', request: {
          type: type,
          key: key,
          contracts: contracts,
        }
      }),
      issueCredential: (identityName, expirationPeriod) => dispatch({
        type: 'ISSUE_PETSHOP_MEMBERSHIP_REQUEST', request: {
          identityName: identityName,
          notifications: false,
          exp: expirationPeriod,
          vc: []
        }
      }),
      step_next: (key) => dispatch({ type: 'STEP_NEXT', key: key}),
      step_prev: (key) => dispatch({ type: 'STEP_PREV', key: key}),
      setVerification: (v, k) => dispatch({ type: 'SET_VERIFICATION', verification: v, key: k}),
      showModal: () => dispatch({ type: 'SHOW_SUBSCRIPTION' }),
      hideModal: () => dispatch({ type: 'HIDE_SUBSCRIPTION' })
    })
  )(IssueCredential)
  