import styled from 'styled-components'

export const AppWrap = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  height: 100%;
`

export const AppBody = styled.div`
  flex: 1 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
  max-width: 100%;
  padding: 20px;
`

export const Join = styled.section`
  color: #000000;
  font-size: 18px;
  text-align: left;
`

export const SubText = styled.p`
  margin: 0 auto 3em auto;
  font-size: 18px;
`

export const SubLine = styled.div`
  margin: 0 auto 1em auto;
  font-size: 18px;
`

export const ErrorText = styled.span`
  color: red;
  font-size: 18px;
`

export const NormalText = styled.span`
  color: black;
  font-size: 18px;
`

export const Button = styled.button`
  margin-right: 1em;
  font-size: 18px;
`

export const SectionLogin = styled.section`
  color: #000000;
  font-size: 18px;
  text-align: left;
`

export const UserName = styled.span`
  display: inline-block;
  vertical-align: middle;
  font-size: 11px;
  color: black;
  text-align: right;
  margin-right: 1em;
`

export const NavBar = styled.nav`
  color: #FFFFFF;
  padding: 20px 40px;
  font-size: 18px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`

export const LeftArea = styled.div`
  display: block;
  text-decoration: none;
  flex: 1;
  text-align: left;
`
export const RightArea = styled.div`
  display: block;
  flex: 1;
  text-align: right;
`