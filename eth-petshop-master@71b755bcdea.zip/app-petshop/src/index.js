import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route } from 'react-router-dom'
import { Provider } from 'react-redux'

import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';

import Subscription from "./components/Subscription";
import Login from "./components/Login";
import {Drizzle} from "drizzle";
import Adoption from "./contracts/Adoption.json";
import Schema from "./contracts/Schema.json";
import Revocation from "./contracts/Revocation";
import DIDRegister from "./contracts/EthereumDIDRegistry";
import { uportConnect } from "./utilities/uportSetup.js";
import appReducer  from './actions/AppReducer';
import { AppSaga } from './actions/AppSaga';

const options = {
	contracts: [Adoption, Revocation, Schema, DIDRegister],
	web3: {
		customProvider: uportConnect.getProvider(),
		fallback: {
			type: "ws",
			url: process.env.REACT_APP_QUORUM_WS_URL
		}
	},
	appReducers: { appReducer },
	appSagas: [ AppSaga ]
};

const drizzle = new Drizzle(options);

ReactDOM.render(
	<Router>
		<Provider store={drizzle.store}>
			<App drizzle={drizzle}/>
			{/* <Route exact path='/' render={(props) => <App drizzle={drizzle}/>} />
			<Route exact path='/login' render={(props) => <Login drizzle={drizzle}/>} />
			<Route exact path='/subscription' render={(props) => <Subscription drizzle={drizzle}/>} /> */}
		</Provider>
	</Router>, document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
