import io from 'socket.io-client';
import { decodeJWT } from 'did-jwt'

function websocketTransport (request, {data, cancel}) {
    return new Promise((resolve, reject) => {
        try {
            const endpoint = process.env.REACT_APP_PROXY_ADDR? process.env.REACT_APP_PROXY_ADDR :"http://127.0.0.1:3030/";
            const socket = io(endpoint);
            const did = process.env.REACT_APP_DID;
            socket.emit('register', did);
            socket.emit('request', { 
                iss: did, 
                aud: process.env.REACT_APP_AGENT_DID, 
                token: request
            })

            socket.on('response', (data) => {
                socket.close();
                if (data.type === 'signTx') {
                    console.log('signTx', data);
                    resolve({...data, payload:data.tx.transactionHash});
                } else {
                    console.log("data", data);
                    console.log('response', decodeJWT(data.payload));
                    resolve({data, payload:data.payload});
                }
            })
        } catch (e) {
            reject(e);
        }
    });
}

export default websocketTransport;
