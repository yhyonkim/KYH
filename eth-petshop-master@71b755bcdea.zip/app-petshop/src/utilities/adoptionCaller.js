import { adoptContract, adoptionContractAddress, web3 } from "./uportSetup";

export async function adopt (id, privateKey) {
    return new Promise(async (resolve, reject) => {
        const sendingData = adoptContract.methods.adopt(
            id
        ).encodeABI();

        // define tx information
        const tx = {
            to: adoptionContractAddress,
            data: sendingData,
            gas: 100000000,
            gasLimit: 100000000,
        }
    
        try {
            // sign transaction
            web3.eth.accounts.signTransaction(tx, privateKey, (err, signed) => {
                if (err) console.log("adopt signTransaction err: ", err);
                else {
                    // send signed transaction
                    web3.eth.sendSignedTransaction(signed.rawTransaction, (err, res) => {
                        if (err) console.log("adopt sendSignedTransaction err: ", err);
                    }).on('receipt', receipt => { // listening 'receipt' message
                        resolve(receipt);
                    });
                }
            });
        } catch (error) {
            console.error("adopt error: ", error);
            reject(error);
        }
    });
}

export async function processAdoption (id, to, privateKey) {
    return new Promise(async (resolve, reject) => {
        const sendingData = adoptContract.methods.processAdoption(
            id,
            to
        ).encodeABI();

        // define tx information
        const tx = {
            to: adoptionContractAddress,
            data: sendingData,
            gas: 100000000,
            gasLimit: 100000000,
        }
    
        try {
            // sign transaction
            web3.eth.accounts.signTransaction(tx, privateKey, (err, signed) => {
                if (err) console.log("adoptPet signTransaction err: ", err);
                else {
                    // send signed transaction
                    web3.eth.sendSignedTransaction(signed.rawTransaction, (err, res) => {
                        if (err) console.log("adoptPet sendSignedTransaction err: ", err);
                    }).on('receipt', receipt => { // listening 'receipt' message
                        resolve(receipt);
                    });
                }
            });
        } catch (error) {
            console.error("adoptPet error: ", error);
            reject(error);
        }
    });
}

export async function getPetPrice (id) {
    return new Promise(async resolve => {
        const sendingData = adoptContract.methods.getPetPrice(
            id
        ).encodeABI();
    
        const tx = {
            to: adoptionContractAddress,
            data: sendingData,
            gas: 100000000,
            gasLimit: 100000000,
        }
    
        const petPrice = await web3.eth.call(tx);
        resolve(petPrice);
    });
}