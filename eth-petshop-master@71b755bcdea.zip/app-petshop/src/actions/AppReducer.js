import { uportConnect } from '../utilities/uportSetup';

const initialState = {
  sharesInput: 0, // Stupid FB warning about controlled inputs
  uport: null,
  user: sessionStorage.getItem('user') ? JSON.parse(sessionStorage.getItem('user')) : null,
  petshop: {
    msgDIDAuth: "",
    msgVerifyCredential: ""
  },
  subsInfo: {
    msgDIDAuth: "",
    msgVerifyCredential: "정부에서 발급한 출생 인증서를 제출하세요."
  },
  msgVerifyAdult: "나이 정보를 전송하지 않고 인증을 받고자 한다면 버튼을 클릭하세요.",
  isAdult: null,
  signClaimPage: false,
  didAuthLoading: false,
  SchemaModal: true,
  verification: {},
  keyPair: sessionStorage.getItem('keyPair') ? JSON.parse(sessionStorage.getItem('keyPair')) : null,
}

export default (state = initialState, action) => {
  switch (action.type) {
    case 'VERIFY_PETSHOP_BEGIN':
      return {
        ...state,
        didAuthLoading: true,
      }
    case 'VERIFY_PETSHOP_END':
      return {
        ...state,
        didAuthLoading: false,
      }
    case 'ISSUE_PETSHOP_MEMBERSHIP_SUCCESS':
      console.log('reducer ISSUE_PETSHOP_MEMBERSHIP_SUCCESS: ', action.subsInfo);
      return {
        ...state,
        subsInfo: {
          ...state.subsInfo,
          msgMembership: action.subsInfo.msgMembership,
          credentialName: action.subsInfo.credentialName
        },
      }

    case 'VERIFY_ATTR_ADULT_SUCCESS':
      console.log('reducer VERIFY_ATTR_ADULT_SUCCESS: ', action);
      return {
        ...state,
        isAdult: action.isAdult,
        msgVerifyAdult: action.msgVerifyAdult,
      }
    case 'VERIFY_IDENTITY_BEGIN':
      let verification = state.verification;
      const verf = {
        message: '민증을 제출하세요',
        current: 0,
        verifying: null,
      }
      verification[action.key] = verf;
      verification[action.key].verifying = "Waiting for response...";
      verification[action.key].percent = 0;
      return {
        ...state,
        verification
      }
    case 'VERIFY_IDENTITY_NEXT':
      verification = state.verification;
      verification[action.key].verifying = action.verifying+'...';
      verification[action.key].percent = action.percent;
      return {
        ...state,
        verification
      }
    case 'VERIFY_IDENTITY_SUCCESS':
      verification = state.verification;
      verification[action.key] = action.response;
      verification[action.key].current = 0;
      verification[action.key].percent = 100;
      verification[action.key].verifying = "Verifying Complete";
      return {
        ...state,
        subsInfo: action.response,
        verification
      }
    case 'VERIFY_IDENTITY_FAILED':
      verification = state.verification;
      verification[action.key] = action.response;
      verification[action.key].current = 0;
      verification[action.key].verifying = "Verifying Failed";
      return {
        ...state,
        subsInfo: action.response,
        verification
      }
    case 'VERIFY_IDENTITY_ERROR':
      verification = state.verification;
      verification[action.key].message = action.error;
      return {
        ...state,
        verification
      }


    case 'VERIFY_MEMBERSHIP_BEGIN':
      let loading = state.loading ? state.loading : [];
      loading[action.key] = true;
      return {
        ...state,
        loading,
      }
    case 'VERIFY_MEMBERSHIP_END':
      loading = state.loading ? state.loading : [];
      loading[action.key] = false;
      return {
        ...state,
        loading,
      }
    case 'VERIFY_MEMBERSHIP_SUCCESS':
      verification = state.verification;
      verification[action.key] = action.response;
      return {
        ...state,
        subsInfo: action.response,
        verification,
        user: action.response.user,
      }
    case 'VERIFY_MEMBERSHIP_FAILED':
      return {
        ...state,
        subsInfo: action.response,
      }

    case 'VERIFY_IDENTIFICATION_CREDENTIAL_SUCCESS':
      console.log('reducer VERIFY_IDENTIFICATION_CREDENTIAL_SUCCESS: ', action.subsInfo);
      return {
        ...state,
        subsInfo: action.subsInfo,
      }

    case 'VERIFY_IDENTIFICATION_CREDENTIAL_FAILED':
      console.log('reducer VERIFY_IDENTIFICATION_CREDENTIAL_FAILED.');
      return {
        ...state,
        subsInfo: initialState.subsInfo
      }

    case 'VERIFY_PETSHOP_CREDENTIAL_SUCCESS':
      console.log('reducer VERIFY_PETSHOP_CREDENTIAL_SUCCESS: ', action);
      sessionStorage.setItem('user', JSON.stringify(action.user));
      return { ...state, user: action.user }

    case 'CONNECT_UPORT_REQUEST':
      return {
        ...state,
        uport: null,
        signClaimPage: true
      }
    case 'CONNECT_UPORT_SUCCESS':
      uportConnect.did = action.uport.did;
      return {
        ...state,
        uport: action.uport,
        petshop: {
          msgDIDAuth: "'DID Auth'가 완료되었습니다. '회원증 검사' 과정을 진행하세요.",
          msgVerifyCredential: "진행을 원하시면 왼쪽 '회원증 검사' 버튼을 클릭하세요."
        },
        subsInfo: {
          msgDIDAuth: "'DID Auth'가 완료되었습니다. '민증 검사' 과정을 진행하세요.",
          msgVerifyCredential: "진행을 원하시면 왼쪽 '민증 검사' 버튼을 클릭하세요."
        },
        signClaimPage: true
      }

    case 'DISCONNECT_UPORT_BEGIN':
      return {
        ...state,
        didAuthLoading: true
      };
    case 'DISCONNECT_UPORT_SUCCESS':
      sessionStorage.removeItem('user');
      return {
        ...state,
        user: undefined,
        didAuthLoading: false,
        authStepCurrent: 0,
      }
    case 'DISCONNECT_UPORT_FAILED':
      return {
        ...state,
        didAuthLoading: false
      }

    case 'SIGN_CLAIM':
      return {
        ...state,
        signTransactionPage: true
      }

    case 'GET_CURRENT_SHARES_REQUEST':
      return {
        ...state,
        gettingShares: true
      }
    case 'GET_CURRENT_SHARES_SUCCESS':
      return {
        ...state,
        gettingShares: false,
        sharesTotal: action.data
      }
    case 'GET_CURRENT_SHARES_ERROR':
      return {
        ...state,
        gettingShares: false,
        error: action.data
      }
    case 'UPDATE_SHARES_INPUT':
      return {
        ...state,
        sharesInput: action.data
      }

    case 'BUY_SHARES_REQUEST':
      return {
        ...state,
        confirmingInProgress: true
      }
    case 'BUY_SHARES_PENDING':
      return {
        ...state,
        buyingInProgress: true,
        confirmingInProgress: false
      }
    case 'BUY_SHARES_SUCCESS':
      return {
        ...state,
        txHash: action.tx,
        buyingInProgress: false,
        sharesTotal: action.data
      }
    case 'BUY_SHARES_ERROR':
      return {
        ...state,
        buyingInProgress: false,
        sharesTotal: action.data
      }

    case 'BUY_SHARES_DEMO_COMPLETE':
      return {
        ...state,
        collectCredentialsPage: true
      }

    case 'CREDENTIALS_DEMO_COMPLETE':
      return {
        ...state,
        registerYourAppPage: true
      }
    case 'LOGOUT':
      return {
        ...state,
        uport: null,
        logOutPage: true
      }
    case 'SHOW_SCHEMA_MODAL':
      return {
        ...state,
        SchemaModal: true,
      }
    case 'SET_KEY_PAIR':
      return {
        ...state,
        keyPair: action.keyPair
      }
    case 'HIDE_SCHEMA_MODAL':
      return {
        ...state,
        SchemaModal: false,
      }
    case 'SET_VERIFICATION':
      if (!action.key || !action.verification) return state;
      verification = state.verification;
      verification[action.key] = action.verification;
      return {
        ...state,
        verification: verification,
      }
    case 'STEP_NEXT':
      verification = state.verification;
      if (verification[action.key]) {
        if (verification[action.key].current) verification[action.key].current = verification[action.key].current + 1;
        else verification[action.key].current = 1;
        return {
          ...state,
          verification: verification
        }
      } else return state;
    case 'STEP_PREV':
      verification = state.verification;
      if (verification[action.key]) {
        if (verification[action.key].current) verification[action.key].current = verification[action.key].current - 1;
        else verification[action.key].current = 0;
        return {
          ...state,
          verification: verification
        }
      } else return state;
    case 'SHOW_SUBSCRIPTION':
      return { ...state, showSubscription: true };
    case 'HIDE_SUBSCRIPTION':
      return { ...state, showSubscription: false };
    default:
      return state
  }
}
