import { takeLatest, call, put } from "redux-saga/effects";

import { isEmpty } from '../utilities/utils';
import loginPetshop from '../functions/loginPetshop';
import logoutPetshop from '../functions/logoutPetshop';
import requestDisclosure from '../functions/requestDisclosure';
import verifyAdult from '../functions/verifyAdult'
import verifyCredential from '../functions/verifyCredential';
import verifyMembership from '../functions/verifyMembership';
import verifyIdentity from '../functions/verifyIdentity';
import issuePetshopMembership from '../functions/issuePetshopMembership';
import { setEthAddress, getEthAddress, registerDID } from "../utilities/registryCaller";

export function* AppSaga() {
    yield takeLatest('CONNECT_UPORT_REQUEST', connectUportSaga);    
    yield takeLatest('DISCONNECT_UPORT_REQUEST', disconnectUportSaga);
    yield takeLatest('VERIFY_CREDENTIAL_REQUEST', verifyCredentialSaga);
    yield takeLatest('VERIFY_ATTR_REQUEST', verifyAttrSaga);
    yield takeLatest('LOGIN_PETSHOP_REQUEST', loginPetshopSaga);
    yield takeLatest('LOGOUT_PETSHOP_REQUEST', logoutPetshopSaga);
    yield takeLatest('ISSUE_PETSHOP_MEMBERSHIP_REQUEST', issuePetshopMembershipSaga);
    yield takeLatest('REGISTER_DID', registerDIDSaga);
    
} 

function* registerDIDSaga(action) {
    yield call(setEthAddress, action.didAddrPair[0], action.didAddrPair[1], action.privateKey);
    const ethAddr = yield call(getEthAddress, action.didAddrPair[0]);
    yield call(registerDID, ethAddr, action.publicKey, action.privateKey);
}

function* loginPetshopSaga(action) {
    try {
        const response = yield call(loginPetshop, [action.request]);
        yield put({ type: 'LOGIN_PETSHOP_SUCCESS', user:response });
        this.props.history.push('/');
    } catch (error) {
        yield put({ type: 'LOGIN_PETSHOP_FAILED', error });
    }
}

function* connectUportSaga(action) {
    try {
        const ConnectReqID = 'ConnectRequest';
        const response = yield call(requestDisclosure, [ConnectReqID, action.request]);
        yield put({ type: 'CONNECT_UPORT_SUCCESS', uport:response.payload });
    } catch (error) {
        yield put({ type: 'CONNECT_UPORT_FAILED', error });
    }
}

function* disconnectUportSaga(action) {
    try {
        yield put({ type: 'DISCONNECT_UPORT_BEGIN' });
        const response = yield call(requestDisclosure, ['DisconnectRequest', action.request]);
        yield put({ type: 'DISCONNECT_UPORT_SUCCESS' });
    } catch (error) {
        yield put({ type: 'DISCONNECT_UPORT_FAILED', error });
    }
}


function* logoutPetshopSaga(action) {
    try {
        yield put({ type: 'DISCONNECT_UPORT_BEGIN' });
        const response = yield call(requestDisclosure, ['DisconnectRequest', action.request]);
        yield put({ type: 'DISCONNECT_UPORT_SUCCESS' });
    } catch (error) {
        yield put({ type: 'DISCONNECT_UPORT_FAILED', error });
    }
}

function* verifyAttrSaga(action) {
    const key = action.request.key;
    try {
        if (action.request.type === 'adult') {
            yield put({ type: 'VERIFY_IDENTITY_BEGIN', key})
            let result = yield call(verifyAdult, action.request.contracts);
            let response = {
                error: !result.retval,
                percentage: result.retval? 100 : 0,
                message: result.retval? "성인 인증에 성공하였습니다." : result.message,
                exp: Math.floor(new Date().getTime()) + 30 * 24 * 60 * 60 * 1000,
                verified: result.retval,
            }
            if (result.retval === true) {
                yield put({ type: 'VERIFY_IDENTITY_SUCCESS', key, response});
            } else {
                yield put({ type: 'VERIFY_IDENTITY_FAILED', key, response});
            }
        }
    } catch (error) {
        yield put({ type: 'VERIFY_IDENTITY_ERROR', error, key });
    } finally {
        yield put({ type: 'VERIFY_IDENTITY_END', key})
    }
}

function* verifyCredentialSaga(action) {
    // You must generated and pass on an unique key for the verification
    // Save the key at the state.
    const request = action.request;
    const key = action.request.key;
    const type = request.type? request.type : request.requested[0];
    let response;
    try {
        yield put({ type: 'VERIFY_IDENTITY_BEGIN', key})
        response = yield call(verifyCredential, action.request);
    } catch (error) {
        yield put({type: 'VERIFY_CREDENTIAL_ERROR'});
        return;
    }
    var retval;
    
    if (type === 'Birthdate Credential') {
        try {
            retval = yield call(verifyIdentity, response, request.contracts, key);
            console.log(retval);
            if (retval.error) {
                yield put({ type: 'VERIFY_IDENTITY_FAILED', response: retval, key })
            } else {
                yield put({ type: 'VERIFY_IDENTITY_SUCCESS', response: retval, key})
            }
        } catch (error) {
            console.log('ERROR', error);
            yield put({ type: 'VERIFY_IDENTITY_ERROR', error , key })
        } finally {
            yield put({ type: 'VERIFY_IDENTITY_END', key})
        }
    } else if (type === 'PetShop Membership') {
        try {
            yield put({ type: 'VERIFY_MEMBERSHIP_BEGIN', key })
            retval = yield call(verifyMembership, response, request.contracts, request.contractAccount);
            if (retval.error) {
                yield put({ type: 'VERIFY_MEMBERSHIP_FAILED', response: retval, key })
            } else {
                yield put({ type: 'VERIFY_MEMBERSHIP_SUCCESS', response: retval, key })
            }
        } catch (error) {
            yield put({ type: 'VERIFY_MEMBERSHIP_ERROR', error , key })
        } finally {
            yield put({ type: 'VERIFY_MEMBERSHIP_END', key})
        }
    }
    console.log(retval);

        // const verifyCredentialReqID = 'vfCredentialRequest';
        // const credentialName = action.request.requested[0];
        // if (credentialName === 'PetShop') {
        //     yield put({type: 'VERIFY_PETSHOP_BEGIN'});
        //     const response = yield call(verifyCredential, [verifyCredentialReqID, action.request, verifyMembership]);
        //     yield put({ type: 'VERIFY_PETSHOP_END'});
        //     yield put({ type: 'VERIFY_PETSHOP_CREDENTIAL_SUCCESS', petshop:response.payload, user: response.user });
        // } else if (credentialName === 'GovBirth') {
        //     const response = yield call(verifyCredential, [verifyCredentialReqID, action.request, verifyIdentity]);

        //     if (isEmpty(response.payload)) {
        //         yield put({ type: 'VERIFY_IDENTIFICATION_CREDENTIAL_FAILED'});
        //     } else {
        //         yield put({ type: 'VERIFY_IDENTIFICATION_CREDENTIAL_SUCCESS', subsInfo: response.payload });
        //     }
        // }
        
}

function* issuePetshopMembershipSaga(action) {
    try {
        const response = yield call(issuePetshopMembership, [action.request]);
        yield put({ type: 'ISSUE_PETSHOP_MEMBERSHIP_SUCCESS', subsInfo: response });
    } catch (error) {
        yield put({ type: 'ISSUE_PETSHOP_MEMBERSHIP_FAILED', error });
    }
}