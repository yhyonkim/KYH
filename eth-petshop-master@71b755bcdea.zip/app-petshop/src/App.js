import React, { Component } from 'react';
import './App.css';

import { connect } from 'react-redux'
import RegisterDID from './components/RegisterDID';

import AppNavbar from "./components/AppNavbar";
import PetPanel from "./components/PetPanel";

import {AppWrap, AppBody} from "./styles/AppStyles";
import { hexStringToBytes } from './utilities/utils';
const bls = require('@chainsafe/bls');

class App extends Component {

	data = require('./pets.json');

  componentDidMount() {
    const { drizzle } = this.props;
    const keyPair = {};
    keyPair.privateKey = hexStringToBytes(process.env.REACT_APP_PETSHOP_PRIVATE_KEY);
    keyPair.publicKey = bls.default.generatePublicKey(keyPair.privateKey);

    this.props.setKeyPair(keyPair);
  }

	contentOne(pet, index) {
		const { drizzle } = this.props;
		return <PetPanel key={index} pet={pet} drizzle={drizzle}/>;
	}

  render() {
		const { drizzleInitialized } = this.props;
		if ( !drizzleInitialized ) return "Loading Drizzle...";
    return (
		<div>
			<AppWrap>
			<AppNavbar drizzle={this.props.drizzle}/>
			<AppBody>
			<div className="row">
		  		<div className="col-xs-12 col-sm-8 col-sm-push-2">
			  		<h1 className="text-center"> Pete's Pet Shop</h1>
						<p>{process.env.REACT_APP_DID}</p>
			  		<hr/> <br/>
		  		</div>
	  		</div>
			<div id="petsRow" className="row">
				{this.data.map((pet, index)=>this.contentOne(pet, index))}
			</div>
			</AppBody>
			</AppWrap>
			<RegisterDID drizzle={this.props.drizzle}/>
			</div>
    );
  }
}

export default connect(
  (state) => ({
    uport: state.appReducer.uport,
	  signTransactionPage: state.appReducer.signTransactionPage,
	  collectCredentialsPage: state.appReducer.collectCredentialsPage,
	  registerYourAppPage: state.appReducer.registerYourAppPage,
	  logOutPage: state.appReducer.logOutPage,
		signClaimPage: state.appReducer.signClaimPage,
		drizzleInitialized: state.drizzleStatus.initialized,
		state
  }),
  (dispatch) => ({
      setKeyPair: (keyPair) => dispatch({ type: 'SET_KEY_PAIR', keyPair}),
  })
)(App)
