import { uportConnect } from '../utilities/uportSetup';

function verifyCredential(request) {
    const id = request.key ? request.key : 'vfCredentialRequest';

    return new Promise((resolve, reject) => {
        try {
            // console.log(`uportConnect.requestDisclosure credentialName=${credentialName}`);
            uportConnect.requestDisclosure({
                requested: ["name"],
                verified: request.requested,
                vc:[]
            }, id);

            uportConnect.onResponse(id).then(async res => {
                // console.log(`uportConnect.onResponse[${id}] response`,JSON.stringify(res,null,4))
                console.log(res);
                resolve(res);
            });
        } catch (error) {
            reject(error);
        }
    });
}


function verifyCredentialLegacy(request) {
    const id = 'vfCredentialRequest';
    // const request = args[1];
    // const verifier = args[2];

    const credentialName = request.requested;
    const holder = request.holder;
    const contracts = request.contracts;
    const contractAccount = request.contractAccount;

    return new Promise((resolve, reject) => {
        try {
            console.log(`uportConnect.requestDisclosure credentialName=${credentialName}`);
            uportConnect.requestDisclosure({
                requested: ["name"],
                verified: request.requested,
                vc:[]
            }, id);

            uportConnect.onResponse(id).then(async res => {
                console.log(`uportConnect.onResponse[${id}] response`,JSON.stringify(res,null,4))
                resolve(res);
                let retval = {credentialName: credentialName};
                // retval.payload = await verifier(res, holder, contracts, contractAccount);
                retval.user = res.payload;
                resolve(retval);
            });
        } catch (error) {
            reject(error);
        }
    });
}
export default verifyCredential;