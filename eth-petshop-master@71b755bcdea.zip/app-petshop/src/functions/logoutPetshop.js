import { uportConnect } from '../utilities/uportSetup';

const logoutPetshop = () => {
    return new Promise((resolve, reject) => {
        try {
            uportConnect.logout();
            resolve(true);
        } catch (e) {
            reject(e);
        }
    });
}

export default logoutPetshop;