import { uportConnect } from '../utilities/uportSetup';

const verifyMemberShip = (res, holder, contracts, contractAccount) => {
    console.log("verifyMemberShip.res.payload=",  JSON.stringify(res.payload,null,4));

    let retval = {};
    retval.error = false;
    retval.message = "'회원증 검사'가 완료되었습니다.";
    retval.user = res.payload;
    retval.verified = res.payload.verified[0];
    retval.isVerifyIdentification = false;
    console.log(res);
    
    if (!retval.verified) {
        retval.error = true;
        retval.message = "회원증이 존재하지 않군요. 회원가입을 먼저 진행하세요.";
    } else {
        const name = res.payload.name;
        const issuer = retval.verified.iss;
        const exp = retval.verified.exp;
        
        if (issuer !== uportConnect.state.keypair.did) {
            retval.error = true;
            retval.message = "Pet shop에서 발급받은 회원증이 아니군요. 돌아가십시오.";
        } else if (exp < Math.floor(new Date().getTime())) {
            retval.error = true;
            retval.message = "회원증 기간이 만료되었군요. 돌아가십시오.";
        } else {
            retval.isVerifyIdentification = true;
            retval.memberName = name;
        }
    }

    return retval;
}

export default verifyMemberShip;