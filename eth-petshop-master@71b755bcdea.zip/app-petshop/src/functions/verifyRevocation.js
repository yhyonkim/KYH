const verifyRevocation = (NonRevocationInfo, contract) => {
    return new Promise(async (resolve, reject) => {
        if(NonRevocationInfo) {
            const accId = NonRevocationInfo.accId;
            const accIndex = NonRevocationInfo.accIndex;
            const accWit = NonRevocationInfo.witness;
            if(accId && accIndex && accWit) {
                const acc = await contract.methods.getAcc(accId).call({from:''});
                const value = await contract.methods.getTails(accId,accIndex).call({from:''});
                if(acc && value) {
                    if(value * accWit === acc * 1) {
                        resolve(true);
                    }
                }
            }
        }
        resolve(false);
    });
}
export default verifyRevocation;