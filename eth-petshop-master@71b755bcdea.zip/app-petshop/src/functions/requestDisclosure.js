import { uportConnect } from '../utilities/uportSetup';

function requestDisclosure(args) {
    const id = args[0];
    const request = args[1];
    /* for debug
    console.log('requestDisclosure:');
    console.log('\tid:',id);
    console.log('\trequest:',request);
    */
    return new Promise((resolve, reject) => {
        try {
            uportConnect.requestDisclosure(request, id);
            uportConnect.onResponse(id).then(jwt => {
                jwt.payload.isDIDAuth = true;
                resolve(jwt)
            });
        } catch (e) {
            reject(e);
        }
    });
}

export default requestDisclosure;
