import { uportConnect } from '../utilities/uportSetup';

const issuePetshopMembership = (args) => {
    const request = args[0];
    const exp = request.exp;
    let retval = {credentialName: 'PetShop Membership'};
    const month = Math.floor(new Date().getTime()) + 30 * 24 * 60 * 60 * 1000; // (current month) + (30 days)
    console.log("request: ", request);

    return new Promise((resolve, reject) => {
        try {
            const claim = {};
            claim['PetShop Membership'] = {'memberLevel': 'economy'};
            const verf = {
                exp: exp? exp : month,
                claim,
                vc: [],
              };
            uportConnect.sendVerification(verf).then(res => {
                console.log('res sendVerification: ', res);
                retval.msgMembership = "회원증 발급이 완료되었습니다.";
                resolve (retval);
            });
        } catch (error) {
            reject (error);
        }
    })
}

export default issuePetshopMembership;