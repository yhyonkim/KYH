import { isEmpty } from '../utilities/utils';
import verifySchema from './verifySchema';
import verifyRevocation from './verifyRevocation';
//import web3 from 'web3';
import { call, put } from "redux-saga/effects";
import { getPublicKey } from "../utilities/registryCaller";

import {  web3 } from "../utilities/uportSetup";

const bls = require('@chainsafe/bls');
const sha256 = require('js-sha256');

const title = 'Birthdate Credential';

// retval 에는 return 할 애들만 넣어주세요.
// 모든 verify logic은 res.payload.verified[0] verified를 넘겨서,
// 추가로 필요한 경우에는 res에서 뽑아서 추가 parameter로 넘겨주세요.
function* verifyIdentity(res, contracts, key) {
    let retval = {
        error: true,
        // error: true 이면 실패, error: false 이면 성공. 아래것은 의미가 겹침.
        // isVerifyIdentification: false
    };

    // Verified가 있는지 확인
    if (isEmpty(res.payload.verified)) {
        retval.message = "아무런 인증서도 제출되지 않았습니다. 정부로부터 출생 인증서를 발급 받으세요.";
        return retval;
    }

    // 모든 verify logic은 이 verified를 넘겨서
    const presentation = res.payload.verified[0].claim[title];
    const holderPublicKey = yield getPublicKey(res.payload.verified[0].iss);
    if (holderPublicKey === null) {
        retval.message = "Wallet의 public key를 Ledger로 부터 가져올 수 없습니다. Wallet의 DID를 Ledger에 등록하세요.";
        return retval;
    }
    const verified = presentation[title];
    const aggSig = presentation['aggregatedSignature'];
    const NonRevocationInfo = presentation['NonRevocationInfo'];
    
    // 성공/만족시 true, 실패시 false를 return 한다.
    // check bls
    const { blsResult, presentResult, issuerPublicKey } = yield callNext(key,'Verifying BLS Signature' ,16 , verifyBLS, verified, holderPublicKey, presentation)
    if (issuerPublicKey === null) {
        retval.message = "Issuer의 public key를 Ledger로 부터 가져올 수 없습니다. Issuer의 DID를 Ledger에 등록하세요.";
        return retval;
    }
    if (!presentResult) {
        retval.message = "Issuer가 Holder에게 발행한 인증서를 가지고 Holder가 만든 Presentation이 아니군요.";
        return retval;
    }
    if (!blsResult) {
        retval.message = "Issuer가 Holder에게 발행한 것이 아니군요.";
        return retval;
    }
    // check schema
    const schema = yield callNext(key, 'Verifying Schema', 32, verifySchema, verified, contracts.Schema)
    if (!schema) {
        retval.message = "Schema가 일치하지 않습니다. 돌아가십시오.";
        return retval;
    }
    // check revocation
    const revocation = yield callNext(key, 'Verifying Revocation', 48, verifyRevocation, NonRevocationInfo, contracts.Revocation);
    if (!revocation) {
        retval.message = "취소된 인증서입니다. 취소되지 않은 인증서를 제출하세요.";
        return retval;
    }
    // check age
    const age = yield callNext(key, 'Verifying Age', 64, verifyAge, verified, 19);
    if (!age) {
        retval.message = "19세 미만이시군요. 회원이 될 수 없습니다. 돌아가십시오.";
        return retval;
    }
    // check issuer and delegator
    const { isIssuer, isPrivilege } = yield callNext(key, 'Verifying Issuer / Delegator', 80, verifyIssuer, verified, contracts) 
    if (!isIssuer && !isPrivilege) {
        retval.message = "신뢰할 수 있는 기관에서 발급된 인증서가 아닙니다. 돌아가십시오.";
        return retval;
    }
    // check expiration
    const expiration = yield callNext(key, 'Verifying Expiration', 96, verifyExpiration, verified);
    if (!expiration) {
        retval.message = "민증 기간이 만료되었군요. 돌아가십시오.";
        return retval;
    }
    retval.message = "성인임이 확인되었습니다.";
    const month = Math.floor(new Date().getTime()) + 30 * 24 * 60 * 60 * 1000; // (current month) + (30 days)
    retval.exp = month;
    retval.error = false;
    retval.verified = true;

    return retval;
}
/*
 @params 
 key: 전체 verification의 unique key
 message: 표시할 메시지
 percent: 현재 진행도
 ...args: 기존 call에 들어가는 args들
*/
function* callNext(key, message, percent, ...args){
    yield put({ type: 'VERIFY_IDENTITY_NEXT', key, verifying: message, percent: percent})
    // 여기에 delay 값을 0 으로 주면 쉬지않고 프로세스합니다.
    yield call(delay, 2000);
    const result = yield call(...args);
    return result;
}
function* delay(time) {
    yield new Promise(resolve => setTimeout(resolve, time));
}
async function verifyIssuer(verified, contracts) {
    const issuer = verified.iss;
    const issuerId = issuer.split(':')[2];
    console.log("issuer: ", issuer)
    const isIssuer = issuer === process.env.REACT_APP_GOV_DID;
    console.log('Validate REACT_APP_GOV_ADDR: ',process.env.REACT_APP_GOV_ADDR);
    console.log('Validate issuerId: ',issuerId);
    const isPrivilege = await contracts.EthereumDIDRegistry.methods.validDelegate(process.env.REACT_APP_GOV_ADDR, web3.utils.asciiToHex(title), issuerId).call();
    console.log("isPrivilege:", isPrivilege);
    return {isIssuer, isPrivilege}
}

async function verifyAge(verified, targetAge) {
    const claims = verified.claim[title];
    const birthYear = claims.year;
    const curYear = new Date().getFullYear();
    const age = curYear - birthYear + 1;
    if (age < targetAge) return false;
    else return true;
}

async function verifyBLS(verified, holderPublicKey, presentation) {
    return new Promise(async resolve => {
        const claims = verified.claim[title];
    
        const issuerPublicKey = await getPublicKey(verified.iss);
        if (issuerPublicKey === null) {
            resolve ({blsResult: false, presentResult: false, issuerPublicKey: issuerPublicKey});
        }
        const aggregatesig = Buffer.from(claims.aggregatedSig, 'hex');
        const presentaggsig = Buffer.from(presentation.aggregatedSignature, 'hex');

        const domain = Buffer.alloc(8, 0);
        const origUserInfo = claims.orig;
        const userInfo = { year: claims.year, month: claims.month, day: claims.day, orig: claims.orig, revocation: claims.Revocation };
        let presentInfo = presentation;
        delete presentInfo.aggregatedSignature;

        const holderMsgHash = Buffer.from(sha256.arrayBuffer(JSON.stringify(origUserInfo)));
        const issuerMsgHash = Buffer.from(sha256.arrayBuffer(JSON.stringify(userInfo)));
        const presntMsgHash = Buffer.from(sha256.arrayBuffer(JSON.stringify(presentInfo)));

        const blsResult = bls.default.verifyMultiple([Buffer.from(holderPublicKey, 'hex'), Buffer.from(issuerPublicKey, 'hex')], [holderMsgHash, issuerMsgHash], aggregatesig, domain);
        const presentResult = bls.default.verifyMultiple([Buffer.from(holderPublicKey, 'hex'), Buffer.from(issuerPublicKey, 'hex'), Buffer.from(holderPublicKey, 'hex')], [holderMsgHash, issuerMsgHash, presntMsgHash], presentaggsig, domain);

        resolve ({ blsResult, presentResult, issuerPublicKey});
    });
}

async function verifyExpiration(verified) {
    const exp = verified.exp;
    if (exp < Math.floor(new Date().getTime())) return false;
    else return true;
}

export default verifyIdentity;
