import {isEmpty} from '../utilities/utils';
import Ajv from 'ajv';

const verifySchema = async(verified, contract) => {
    const key = 'Birthdate Credential';
    // console.log('verifySchema payload=',payload);
    const cred = verified.claim[key];
    console.log('cred', cred);
    if (cred.schemaId) {
        const schemaId = cred.schemaId;
        const schemaRaw = await contract.methods.get(schemaId).call({from:''});
        if (isEmpty(schemaRaw)) {
            return false;
        }
        let schema;
        try {
            schema = JSON.parse(schemaRaw).properties[key.replace(' ','')];
        } catch (e){
            console.log(e);
            return false;
        }

        var ajv = new Ajv();
        var valid = ajv.validate(schema, cred);
        if (!valid) console.log('AJVERROR', ajv);
        if (valid) return true;
    }
    return false;
}
export default verifySchema;