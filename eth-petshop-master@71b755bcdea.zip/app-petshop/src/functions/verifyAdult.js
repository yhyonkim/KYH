import io from 'socket.io-client';
import Verifier from '../libs/bullet_proof_range_verif';
import verifyRevocation from './verifyRevocation';
const BigInt = require("big-integer");
const EC = require('elliptic').ec;
const ec = new EC('secp256k1');

const utils = require('../libs/utils');

const START_AGE = 19;
const BOUND = 8;

function verifyAdult(contracts) {
    var verifier = null, A = null, S = null, T1 = null, T2 = null, finalpedCom = null;

    return new Promise((resolve, reject) => {
        try {
            const endpoint = process.env.REACT_APP_PROXY_ADDR? process.env.REACT_APP_PROXY_ADDR :"http://127.0.0.1:3030/";
            const socket = io(endpoint);

            socket.emit('register', process.env.REACT_APP_PETSHOP_DID);
            socket.emit('request', {
                iss: process.env.REACT_APP_PETSHOP_DID,
                type: 'checkAge',
                aud: process.env.REACT_APP_AGENT_DID,
                token: { 
                    startAge: START_AGE,
                    bound: BOUND 
                }
            });

            socket.on('bulletProof', async (data) => {
                if (data.type === 'proof1') {
                    console.log("bulletProof proof1 data: ", data);
                    
                    const revokeInfo = data.payload.revokeInfo;
                    console.log("revokeInfo: ", revokeInfo);
                    console.log("contracts.Revocation: ", contracts.Revocation);
                    
                    revokeInfo.witness = Number(revokeInfo.accWit);
                    const isNotRevocated = await verifyRevocation(revokeInfo, contracts.Revocation);
                    if (isNotRevocated === false) {
                        socket.close();
                        const result = {retval: false, message: "취소된 인증서입니다. 인증서를 갱신 해주세요."};
                        resolve(result);
                    }

                    const r1_diff = new BigInt(data.payload.r1_diff);
                    A = ec.curve.pointFromJSON(data.payload.A, false);
                    S = ec.curve.pointFromJSON(data.payload.S, false)
                    const r0 = new BigInt(data.payload.r0.replace(/"/g,""));
                    const r1 = new BigInt(data.payload.r1.replace(/"/g,""));
                    const r2 = new BigInt(data.payload.r2.replace(/"/g,""));
                    const r3 = new BigInt(data.payload.r3.replace(/"/g,""));
                    const x1 = new BigInt(data.payload.x1.replace(/"/g,""));
                    
                    const start = utils.turnToBig(START_AGE);
                    
                    const pedCom1 = utils.ec.g.mul(x1.toString(utils.HEX)).add(utils.ec.g.mul((r2.multiply(r3)).toString(utils.HEX)));

                    const gstarA = utils.ec.g.mul(start.toString(utils.HEX));
                    const negGstarA = gstarA.neg(gstarA);
                    const gr0tor1 = utils.ec.g.mul((r0.multiply(r1)).toString(utils.HEX));
                    const gr2tor1 = utils.ec.g.mul((r2.multiply(r1)).toString(utils.HEX));
                    const gr0tor3 = utils.ec.g.mul((r0.multiply(r3).toString(utils.HEX)))
                    const sum_gr2tor1 = gr2tor1.add(gr0tor3);
                    const neg_sum_gr2tor1 = sum_gr2tor1.neg(sum_gr2tor1)
                    finalpedCom = pedCom1.add(negGstarA).add(gr0tor1).add(neg_sum_gr2tor1)

                    verifier = new Verifier(r1_diff, 8);
                    
                    var {y,z} = verifier.rangeBpVerifier2(A, S);
                    console.log('emit proof1');
                    socket.emit('bulletProof', {
                        from: data.to,
                        to: data.from,
                        type: 'proof1',
                        payload: {
                            y: y,
                            z: z
                        }
                    });
                } else if (data.type === 'proof2') {
                    console.log("bulletProof proof2 data: ", data);

                    T1 = ec.curve.pointFromJSON(data.payload.T1, false);
                    T2 = ec.curve.pointFromJSON(data.payload.T2, false);
                    var xtest = verifier.rangeBpVerifier4(T1, T2);

                    console.log('emit proof2');
                    socket.emit('bulletProof', {
                        from: data.to,
                        to: data.from,
                        type: 'proof2',
                        payload: {
                            xtest: xtest,
                        }
                    });
                } else if (data.type === 'proof3') {
                    console.log("bulletProof proof3 data: ", data);

                    const tauX = new BigInt(data.payload.tauX.replace(/"/g,""));
                    const miu = new BigInt(data.payload.miu.replace(/"/g,""));
                    const tX = new BigInt(data.payload.tX.replace(/"/g,""));
                    
                    const L = [];
                    for (let i = 0; i < data.payload.L.length; i++) {
                        L.push(ec.curve.pointFromJSON(data.payload.L[i], false));
                    }

                    const R = [];
                    for (let i = 0; i < data.payload.R.length; i++) {
                        R.push(ec.curve.pointFromJSON(data.payload.R[i], false));
                    }
                    
                    const aTag = data.payload.aTag;
                    for (let i = 0; i < aTag.length; i++) {
                        aTag[i] = new BigInt(aTag[i].replace(/"/g,"")); 
                    }
                    const bTag = data.payload.bTag;
                    for (let i = 0; i < bTag.length; i++) {
                        bTag[i] = new BigInt(bTag[i].replace(/"/g,"")); 
                    }
                    const retval = verifier.rangeBpVerifier6(finalpedCom, A, S, T1, T2, tauX, miu, tX, L, R, aTag, bTag);
                    var result = {retval: retval, message: "19세 미만이시군요. 돌아가세요."};
                    
                    console.log('BLS signature result', result);
                    socket.close();
                    resolve(result);
                }
            });

        } catch (error) {
            reject(error);
        }
    });
}

export default verifyAdult;