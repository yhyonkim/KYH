import {isEmpty} from '../utilities/utils';
import verifySchema from './verifySchema';
import verifyRevocation from './verifyRevocation';
import web3 from 'web3';
const bls = require('@chainsafe/bls');
const sha256 = require('js-sha256');

async function verifyIdentification (res, holder, contracts, contractAccount) {
    let retval = {
        errorVerifyIdentification: true,
        isVerifyIdentification: false
    };

    const title = 'Birthdate Credential';
 
    if (isEmpty(res.payload.verified)) {
        retval.errorVerifyIdentification = true;
        retval.msgVerifyCredential = "아무런 인증서도 제출되지 않았습니다. 정부로부터 출생 인증서를 발급 받으세요.";
        return retval;
    }
    retval.verified = res.payload.verified[0].claim[title][title];
    
    if (!retval.verified || !retval.verified.claim) {
        retval.errorVerifyIdentification = true;
        retval.msgVerifyCredential = "아무런 인증서도 제출되지 않았습니다. 정부로부터 출생 인증서를 발급 받으세요.";
        return retval;
    }

    const claims = retval.verified.claim['Birthdate Credential'];
    const holderPublicKey = res.data.walletPublickKey;
    const issuerPublicKey = claims.govPublicKey;
    
    const domain = Buffer.alloc(8, 0);
    const origUserInfo = claims.orig;
    const userInfo = {year: claims.year, month: claims.month, day: claims.day, orig: origUserInfo, revocation: claims.Revocation};
    const presentaggsig = Buffer.from(res.payload.verified[0].claim[title].aggregatedSignature, 'hex');
    let presentInfo = res.payload.verified[0].claim[title];
    delete presentInfo.aggregatedSignature;

    // verify aggregated signature by bls signature
    const holderMsgHash = Buffer.from(sha256.arrayBuffer(JSON.stringify(origUserInfo)));
    const issuerMsgHash = Buffer.from(sha256.arrayBuffer(JSON.stringify(userInfo)));
    const presntMsgHash = Buffer.from(sha256.arrayBuffer(JSON.stringify(presentInfo)));
    const aggregatesig = Buffer.from(claims.aggregatedSig, 'hex');
    const blsResult = bls.default.verifyMultiple([Buffer.from(holderPublicKey, 'hex'), Buffer.from(issuerPublicKey, 'hex')], [holderMsgHash, issuerMsgHash], aggregatesig, domain);
    const presentResult = bls.default.verifyMultiple([Buffer.from(holderPublicKey, 'hex'), Buffer.from(issuerPublicKey, 'hex'), Buffer.from(holderPublicKey, 'hex')], [holderMsgHash, issuerMsgHash, presntMsgHash], presentaggsig, domain);

    const birthYear = claims.year;
    const issuer = retval.verified.iss;
    const exp = retval.verified.exp;
    const curYear = new Date().getFullYear();
    const month = Math.floor(new Date().getTime()) + 30 * 24 * 60 * 60 * 1000; // (current month) + (30 days)
    const age = curYear - birthYear + 1;
    const schema = await verifySchema(res.payload, contracts.Schema, contractAccount);
    const revocation = await verifyRevocation(res.payload, contracts.Revocation, contractAccount);
    const issuerId = issuer.split(':')[2];
    const isPrivilege = await contracts.EthereumDIDRegistry.methods.validDelegate(contractAccount, web3.utils.asciiToHex('Birthdate Credential'), issuerId).call();
    
    if (!presentResult) {
        retval.msgVerifyCredential = "Issuer가 Holder에게 발행한 인증서를 가지고 Holder가 만든 Presentation이 아니군요.";
        return retval;
    }
    if (!blsResult) {
        retval.msgVerifyCredential = "Issuer가 Holder에게 발행한 것이 아니군요.";
        return retval;
    }
    if (schema) {
        retval.msgVerifyCredential = "Schema가 일치하지 않습니다. 돌아가십시오.";
        return retval;
    } 
    if(revocation) {
        retval.msgVerifyCredential = "취소된 인증서입니다. 취소되지 않은 인증서를 제출하세요.";
        return retval;
    } 
    if (age < 19) {
        retval.msgVerifyCredential = "19세 미만이시군요. 회원이 될 수 없습니다. 돌아가십시오.";
        return retval;
    } 
    if (issuer !== process.env.REACT_APP_DID_GOV) {
        if (!isPrivilege) {
            retval.msgVerifyCredential = "신뢰할 수 있는 기관에서 발급된 인증서가 아닙니다. 돌아가십시오.";
            return retval;
        } 
        retval.msgVerifyCredential = "정부에서 발급받은 인증서가 아니군요. 돌아가십시오.";
        return retval;
    }
 
    if (exp < Math.floor(new Date().getTime())) {
        retval.msgVerifyCredential = "민증 기간이 만료되었군요. 돌아가십시오.";
        return retval;
    }

    retval.msgDIDAuth = "'DID Auth'가 완료되었습니다.";
    retval.msgVerifyCredential = "성인임이 확인되었습니다.";
    retval.msgMembership = "회원증을 발급받기 원한다면 '받기' 버튼을 클릭하세요.";
    retval.exp = month;
    retval.errorVerifyIdentification = false;
    retval.isVerifyIdentification = true;
    
    return retval;
}

export default verifyIdentification;
