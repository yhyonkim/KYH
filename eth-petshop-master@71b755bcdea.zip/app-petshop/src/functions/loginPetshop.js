function loginPetshop(args) {
    const request = args[0];
    const memberName = request.memberName;
    const retval = {userName: memberName};
    return retval;
}

export default loginPetshop;