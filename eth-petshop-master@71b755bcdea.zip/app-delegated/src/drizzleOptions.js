import Schema from './contracts/Schema.json';
import Revocation from './contracts/Revocation.json';
import { uportConnect } from "./utilities/uportSetup";
import rootReducer from './actions/AppReducer';
import { AppSaga } from './actions/AppSaga';

const options = {
	contracts: [Schema, Revocation],
	web3: {
		customProvider: uportConnect.getProvider(),
		fallback: {
			type: "ws",
			url: process.env.REACT_APP_QUORUM_WS_URL
		}
	},
	appReducers: { rootReducer },
    appSagas: [ AppSaga ],
};

export default options;