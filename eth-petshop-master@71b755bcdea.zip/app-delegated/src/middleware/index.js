import { EventActions } from 'drizzle'
import { message } from 'antd';

export const contractEventNotifier = store => next => action => {
    if (action.type === EventActions.EVENT_FIRED) {
        const contract = action.name
        const contractEvent = action.event.event
        const mess = action.event.returnValues._message
        const display = `${contract}(${contractEvent}): ${mess}`

        message.success(display);
    }
    return next(action);
}
