import { uportConnect } from '../utilities/uportSetup';

function disconnectUport () {
    uportConnect.logout();
}

export default disconnectUport;