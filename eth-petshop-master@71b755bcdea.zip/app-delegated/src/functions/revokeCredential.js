import { put } from "redux-saga/effects";

export function* revokeCredential(props) {
    const {drizzle, state, credId, credentialList} = props;
    const contract = drizzle.contracts.Revocation;
    const id = credentialList[credId].accId;
    const index = credentialList[credId].index;
    const stackId = contract.methods.revokeCred.cacheSend(id,index,{from: state.accounts[0]})
    yield put({ type: 'SET_REVOKED', id: credId});
    return stackId
}

export function* cancelRevocation(props) {
    const {drizzle, state, credId, credentialList} = props;
    const contract = drizzle.contracts.Revocation;
    const id = credentialList[credId].accId;
    const index = credentialList[credId].index;
    const stackId = contract.methods.cancelRevocation.cacheSend(id,index,{from: state.accounts[0]});
    yield put({ type: 'CANCEL_REVOKED', id: credId});
    return stackId
}
