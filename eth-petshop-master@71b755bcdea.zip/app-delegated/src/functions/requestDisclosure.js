import { uportConnect } from '../utilities/uportSetup';

function requestDisclosure (args) {
    const id = args[0];
    const request = args[1];

    return new Promise((resolve, reject) => {
        try {
            uportConnect.requestDisclosure(request, id);
            
            uportConnect.onResponse(id).then(jwt => {console.log(jwt);resolve(jwt)});
        } catch (e) {
            reject(e);
        }
    });
}

export default requestDisclosure;
