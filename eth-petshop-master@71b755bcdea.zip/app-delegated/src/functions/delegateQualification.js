import web3 from 'web3';

async function delegateQualification(args) {
    console.log('delegateQualification args: ', args);
    
    const qualificationPeriod = args.period;
    const issuerId = args.state.accounts[0];
    const qualType = args.qualType;
    const targetId = args.targetId;
    const callerAccount = args.state.accounts[0];
    
    const contract = args.drizzle.contracts.EthereumDIDRegistry;
    try {
        await contract.methods.addDelegate.cacheSend(issuerId, web3.utils.asciiToHex(qualType), targetId, qualificationPeriod, {from : callerAccount, gas:3000000});
        return true;
    } catch (e) {
        return false;
    }   
}

export default delegateQualification;