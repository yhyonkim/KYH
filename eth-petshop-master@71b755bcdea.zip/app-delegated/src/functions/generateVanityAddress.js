import Wallet from 'ethereumjs-wallet';

function generateVanityAddress() {
    return Wallet.generateVanityAddress().getAddressString();
}

export default generateVanityAddress;