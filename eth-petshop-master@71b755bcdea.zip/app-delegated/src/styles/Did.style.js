import styled from 'styled-components';

export const Area = styled.div`
  color: #000000;
  display: block;
  flex: 1;
  text-align: center;
`

export const Text = styled.span`
  color: #000000;
  font-size: 15px;
  text-decoration: none
`

export const Name = styled.span`
  color: #000000;
  font-weight: bold;
  margin-right: 1em;
`