import styled from 'styled-components'

export const NavBarWrap = styled.nav`
  color: #FFFFFF;
  padding: 20px 40px;
  font-size: 18px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`

export const DemoText = styled.span`
  font-weight: bold;
  text-decoration: none
`

export const LeftArea = styled.div`
  display: block;
  flex: 1;
  text-decoration: none;
  text-align: left;
`
export const RightArea = styled.div`
  display: block;
  flex: 1;
  text-align: right;
`

export const UserName = styled.span`
  display: inline-block;
  vertical-align: middle;
  font-size: 18px;
  color: black;
  text-align: right;
  margin-right: 1em;
  `