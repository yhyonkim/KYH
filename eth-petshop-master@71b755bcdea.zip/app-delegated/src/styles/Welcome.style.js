import styled from 'styled-components';

export const WelcomeWrap = styled.section`

`

export const SubText = styled.p`
    margin: 0 auto 3em auto;
    font-size: 18pt;
`