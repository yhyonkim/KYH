import styled from 'styled-components';

export const MainPageWrap = styled.section`

`

export const TableWrap = styled.table`
    width:100%

`