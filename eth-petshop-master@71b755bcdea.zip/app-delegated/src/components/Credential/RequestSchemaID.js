import React from 'react';
import { connect } from 'react-redux';
import { Button } from 'antd';

class RequestSchemaID extends React.Component {
    render() {
        const { schemaID, sendSchemaID } = this.props;
        return (
            <Button type="primary" onClick={() => sendSchemaID(schemaID)}>
                SchemaID 받기
            </Button>
        )
    }
}

export default connect(
    (state) => ({

    }),
    (dispatch) => ({
        sendSchemaID: (schemaID) => dispatch({ type: 'SEND_SCHEMA_ID', schemaID }),
    })
)(RequestSchemaID)