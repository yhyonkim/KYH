import React, { Component } from 'react';
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import SchemaDetail from '../Schema/SchemaDetail';
import SchemaTitle from '../Schema/SchemaTitle';
import { Table, Button, Icon, Tabs, PageHeader, Tag, Statistic, Row, Col, Skeleton } from 'antd';
import CredentialForm from './CredentialForm';
import IssueCredential from './IssueCredential';
import RequestSchemaID from './RequestSchemaID';
const { TabPane } = Tabs;

class TabKey extends Component {
    render() {
        return (
            <span><Icon type={this.props.type} />{this.props.content}</span>
        )
    }
}

const Description = ({ term, children, span = 12 }) => (
    <Col span={span}>
        <div className="description" style={{ marginBottom: '10px' }}>
            <span className="term"><b>{term}</b>: </span>
            <span className="detail">{children}</span>
        </div>
    </Col>
);

const renderContent = (id) => {
    return (
        <Row>
            <Description term="Schema ID" span={24}>{id}</Description>
            <Description term="Issuer DID" span={24}>{process.env.REACT_APP_GOV_DID}</Description>
            <Description term="Issuer">강서구청</Description>
            <Description term="Issuer URL"><a>https://www.gangseo.seoul.kr/</a></Description>
            <Description term="Creation Time">2017-01-10</Description>
            <Description term="Effective Time">2022-10-10</Description>
            <Description term="Address" span={24}>
                서울시 강서구 화곡6동 강서구청
            </Description>
        </Row>
    )
};

class CredSchemaList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dataKey: null,
            activeKey: "1",
        }
    }

    componentDidMount = () => {
        const { drizzle, uport } = this.props;
        const id = (process.env.REACT_APP_GOV_DID.split(':')[2]);
        const contract = drizzle.contracts.Schema;
        const dataKey = contract.methods["getList"].cacheCall(id);
        this.setState({ dataKey });
    }

    handleClick = (id) => {
        this.setState({ activeKey: "2" })
    }
    next = (id) => {
        this.setState({ selectedID: id, activeKey: "2" })
        this.props.onPendingSchema();
        
    }
    prev = (id) => {
        this.setState({ activeKey: "1" })
        this.props.resetSchema();
    }

    renderColumns(schemaList) {
        var columns = [];
        schemaList.map(id => {
            const col = {
                key: id,
                id: <span style={{
                    whiteSpace: 'nowrap', 
                    textOverflow: 'ellipsis', 
                    overflow: 'hidden', 
                    maxWidth:'1px',
                }}>{id}</span>,
                title: <SchemaTitle drizzle={this.props.drizzle} index={id} addr={id} />,
                request: <Button onClick={() => this.next(id)}><Icon type="solution" />Request</Button>,
                description: <SchemaDetail addr={id} drizzle={this.props.drizzle} />
            }
            columns.unshift(col);
        })
        return columns;
    }

    columns = [
        {
            title: 'Schema ID',
            dataIndex: 'id',
            key: 'id',
        },
        {
            title: 'Title',
            dataIndex: 'title',
            key: 'title',
        },
        {
            title: 'Request Schema',
            dataIndex: 'request',
            key: 'request',
        }
    ]

    callback(key) {
        this.setState({ activeKey: key })
    }

    renderState = () => {
        if (this.props.pendingSchema) return "Pending";
        else if (this.props.gotSchema) return "Writing";
        else return "Something";
    }

    render() {
        const { contracts } = this.props;
        const { Schema } = contracts;
        const schemaList = Schema.getList[this.state.dataKey];
        return (
            <Tabs activeKey={this.state.activeKey} onClick={this.callback} >
                <TabPane tab="Tab 1" key="1">
                    <Table
                        columns={this.columns}
                        dataSource={schemaList ? this.renderColumns(schemaList.value) : null}
                        expandedRowRender={schema => <span style={{ margin: 0 }}>{schema.description}</span>} />
                </TabPane>
                <TabPane tab="Tab 2" key="2">
                    <PageHeader
                        onBack={() => this.prev()}
                        title={<SchemaTitle drizzle={this.props.drizzle} addr={this.state.selectedID} />}
                        subtitle={this.state.selectedID}
                        tags={<Tag color="green">Active</Tag>}
                        extra={
                        <Row>
                            <Col span={12}>
                                <Statistic title="Status" value={this.renderState()} />
                            </Col>
                        </Row>}
                        footer={
                            this.props.gotSchema?<CredentialForm drizzle={this.props.drizzle} schemaID={this.state.selectedID} />:
                            <div style={{float: 'right'}}>
                                <RequestSchemaID drizzle={this.props.drizzle} schemaID={this.state.selectedID}/>
                            </div>
                        }
                    >
                        <div className="wrap">
                            <div className="content padding">{renderContent(this.state.selectedID)}</div>
                        </div>
                    </PageHeader>
                </TabPane>
            </Tabs>
        )
    }
}

export default withRouter(connect(
    (state) => ({
        uport: state.appReducer.uport,
        contracts: state.contracts,
        user: state.appReducer.user,
        pendingSchema: state.appReducer.pendingSchema,
        gotSchema: state.appReducer.gotSchema,
        state,
    }),
    (dispatch) => ({
        resetSchema: () => dispatch({ type: 'RESET_SCHEMA' }),
        onPendingSchema: () => dispatch({ type:'PENDING_SCHEMA' }),
        onGotSchema: () => dispatch({ type:'GOT_SCHEMA' })
    })
)(CredSchemaList));