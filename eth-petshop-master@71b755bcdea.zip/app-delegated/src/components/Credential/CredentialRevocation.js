import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Button } from 'antd';

class CredentialRevocation extends Component {
    render() {
        const { credId, credentialList, revokeCredential, cancelCredential } = this.props;
        if (credentialList[credId].nonrevocation){
            return (
                <Button onClick={() => revokeCredential(this.props)}>Revoke</Button>
            )
        } else {
            return (
                <Button onClick={() => cancelCredential(this.props)}>Cancel</Button>
            )
        }
    }
}

export default connect(
    (state, props) => {
        return {
            accumulator: state.appReducer.accumulator,
            credentialList: state.appReducer.credentialList,
            state
        }
    },
    (dispatch) => ({
        updateCredential: (list) => dispatch({ type: 'UPDATE_CREDENTIAL', value: list }),
        revokeCredential: (props) => dispatch({ type: 'REVOKE_CREDENTIAL', props }),
        cancelCredential: (props) => dispatch({ type: 'CANCEL_REVOKE_CREDENTIAL', props }),
    })
)(CredentialRevocation)