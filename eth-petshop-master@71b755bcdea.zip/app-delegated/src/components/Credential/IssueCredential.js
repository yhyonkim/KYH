import React, { Component } from 'react'
import { connect } from 'react-redux'
import { isEmpty, isTrue, isFalse, notify } from '../../utilities/utils';
import { Button } from 'antd';

class issueCredential extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showRegistrationForm: false,
      result: null,
      value: null,
      validity: null,
      accId: null, accIndex: null, accWitness: null,
      stackId: null, credId: null
    }
    this.handleSubmit = this.handleSubmit.bind(this);
    this.renderNonrevocation = this.renderNonrevocation.bind(this);
    this.getTxStatus = this.getTxStatus.bind(this);
    this.getCredentialRevInfo = this.getCredentialRevInfo.bind(this);
    this.storeCredentialInfo = this.storeCredentialInfo.bind(this);
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const { schema, schemaID, schemaTitles } = this.props;
    let title = null;
    if (schema && schema.properties) {
      title = Object.keys(schema.properties)[0];
    }

    const userInfo = {...this.props.value, orig: this.props.origUserInfo};
    
    let result = { 'schemaId': schemaID, 'title': schemaTitles[schemaID], 'value': userInfo, };
    console.log("issueCredential handleSubmit result: ", result);
    this.renderNonrevocation(result);
  }

  renderNonrevocation(result) {
    const { drizzle, state, selectedAcc, credentialList } = this.props;
    const contract = drizzle.contracts.Revocation;

    const lastAcc = selectedAcc;
    if (lastAcc === undefined) { //|| !lastAcc.status) {
      notify('error', 'Issue Credential Error', "Error : Need to make new accumulator")
      return;
    }
    const id = lastAcc;
    const stackId = contract.methods.issueCred.cacheSend(id, { from: state.accounts[0] });
    let credId = null;
    do {
      credId = ("00000000" + Math.floor(Math.random() * 10000000)).slice(-8);
    } while (credentialList.hasOwnProperty(credId))
    this.setState({ accId: id, stackId, credId, result });
  }

  getTxStatus = () => {
    const { transactions, transactionStack } = this.props.state;
    const txHash = transactionStack[this.state.stackId];
    if (!txHash || !transactions[txHash]) return null;
    if (transactions[txHash].status === 'success') {
      this.getCredentialRevInfo();
      this.setState({ stackId: null });
    }
    return transactions[txHash].status;
  }

  getCredentialRevInfo() {
    const contract = this.props.drizzle.contracts.Revocation;
    contract.methods.getAllInfo(this.state.accId).call({ from: this.props.state.accounts[0] })
      .then(r => {
        this.storeCredentialInfo(r);
        this.setState({ accIndex: r.idx, accWitness: r.witness })
      }).catch(e => console.log(e))
  }

  storeCredentialInfo(r) {
    const { credentialList, addNewCredential } = this.props;
    if (credentialList.hasOwnProperty(this.state.credId)) return;
    credentialList[this.state.credId] = { accId: this.state.accId, index: r.idx, nonrevocation: true, issued: Date.now() };
    addNewCredential(credentialList);

    const contract = this.props.drizzle.contracts.Revocation;
    contract.methods.getNonrevidx(this.state.accId).call({ from: this.props.state.accounts[0] })
      .then(r => {
        this.props.onIssueCredentialSchema(this.props, this.state, r); // accID, index, witness, nonRevIdx[]
      }).catch(e => console.log(e))
  }

  render() {
    const result = this.getTxStatus();
    if ((this.state.stackId !== null) && (result === 'success')) {
      notify('success', 'Issue Credential Success', "Accumulator with id '" + this.state.accId + "' issues : " + result)
    } else if (result === 'error') {
      notify('error', 'Issue Credential Error', "ERROR: IssueNonrevocation, transaction error")
    }

    return (
      <Button type="primary" disabled={this.props.disabled} onClick={this.handleSubmit}>
        Credential 발급
      </Button>
    )
  }
}

export default connect(
  (state, props) => {
    const { user, uport, name, birth, address, showRegistrationForm } = state.appReducer;
    const formIncomplite = isEmpty(name) || isEmpty(birth) || isEmpty(address);
    return {
      user: user,
      uport: uport,
      showRegistrationForm: showRegistrationForm,
      registrationFormIncomplite: formIncomplite,
      name: name,
      birth: birth,
      address: address,
      accumulator: state.appReducer.accumulator,
      credentialList: state.appReducer.credentialList,
      selectedAcc: state.appReducer.selectedAcc,
      origUserInfo: state.appReducer.origUserInfo,
      value: state.appReducer.value,
      schemaTitles: state.appReducer.schemaTitles,
      state
    }
  },
  (dispatch) => {
    return {
      onShowRegistrationForm: (name) => dispatch({ type: 'SHOW_REGISTRATION_FORM', value: name }),
      addNewCredential: (list) => dispatch({ type: 'ADD_NEW_CREDENTIAL', value: list }),
      onIssueCredentialSchema: (props, state, accV) => dispatch({ type: 'ISSUE_CREDENTIAL_SCHEMA_REQUEST', props, state, accV })
    }
  }
)(issueCredential)
