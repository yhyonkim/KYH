import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Table, Tag } from 'antd';
import CredentialRevocation from './CredentialRevocation';

class CredentialList extends Component {
    renderColumns(credentialList) {
        const credentialId = Object.keys(credentialList);
        var columns = [];
        credentialId.map(id => {
            const info = credentialList[id];
            const col = {
                key: id,
                id: id,
                state: info.nonrevocation ? <Tag color="green">Live</Tag> : <Tag color="volcano">Revoked</Tag>,
                accId: info.accId,
                index: info.index,
                nonrevocation: <CredentialRevocation drizzle={this.props.drizzle} credId={id}/>
            }
            columns.push(col);
        })
        return columns;
    }

    columns = [
        {
            title: 'Credential ID',
            dataIndex: 'id',
            key: 'id',
        },
        {
            title: 'Accumulator ID',
            dataIndex: 'accId',
            key: 'accId',
        },
        {
            title: 'Revocation State',
            dataIndex: 'state',
            key: 'state',
        },
        {
            title: 'Accumulator Index',
            dataIndex: 'index',
            key: 'index',
        },
        {
            title: 'Action',
            dataIndex: 'nonrevocation',
            key: 'nonrevocation',
        }
    ]

    render() {
        const { credentialList } = this.props;
        return (
            <Table dataSource={this.renderColumns(credentialList)} columns={this.columns} />
        )
    }
}

export default connect(
    (state) => {
        return {
            credentialList: state.appReducer.credentialList,
            state
        }
    },
    (dispatch) => ({
    })
)(CredentialList)