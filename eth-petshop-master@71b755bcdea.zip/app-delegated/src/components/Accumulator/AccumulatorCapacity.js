import React from "react";
import { connect } from 'react-redux';

class AccumulatorCapacity extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            dataKey: null,
        }
    }
    componentDidMount = () => {
        const { drizzle, accId } = this.props;
        const contract = drizzle.contracts.Revocation;
        const dataKey = contract.methods["getIndex"].cacheCall(accId);
        this.setState({dataKey})
    }
    render() {
        const { contracts } = this.props;
        const { dataKey } = this.state;
        const indexes = contracts.Revocation.getIndex[dataKey] && contracts.Revocation.getIndex[dataKey].value;
        let used, capacity = 0;
        if (indexes) {
            used = parseInt(indexes[0]);
            capacity = parseInt(indexes[1]);
        }
        return (
            <span>
                {indexes && `${used}/${capacity}`}
            </span>
        )
    }
}

export default connect(
    (state) => ({
        contracts: state.contracts,
        accumulator : state.appReducer.accumulator,
        usedAccId : state.appReducer.usedAccId,
        schemaId : state.appReducer.schemaId,
        state
    }),
    (dispatch) => ({
        addAccumulator: (acc,id) => dispatch({type: 'SETUP_ACCUMULATOR', value: acc, used: id}),
    })
)(AccumulatorCapacity);