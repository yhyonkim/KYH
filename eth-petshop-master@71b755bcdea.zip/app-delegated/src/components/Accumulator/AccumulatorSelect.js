import React, { Component } from 'react';
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { Select, Divider, Row, Col } from 'antd';
import AccumulatorRegister from './AccumulatorRegister';
import AccumulatorCapacity from './AccumulatorCapacity';

const { Option } = Select;

class AccumulatorSelect extends Component {
    componentDidMount = () => {
        const { drizzle, uport } = this.props;
        const ownerId = (uport.keypair.did.split(':')[2]);
        const contract = drizzle.contracts.Revocation;
        const dataKey = contract.methods["getAccList"].cacheCall(ownerId);
        this.props.addAccumulatorKey(dataKey);
    }

    disabled = (dataKey) => {
        const { contracts } = this.props;
        const indexes = contracts.Revocation.getIndex[dataKey] && contracts.Revocation.getIndex[dataKey].value;
        let used, capacity = 0;
        if (indexes) {
            used = parseInt(indexes[0]);
            capacity = parseInt(indexes[1]);
        }
        return (
            <span>
                {indexes && (used < capacity) ? `Enabled` : `Disabled`}
            </span>
        )
    }

    render() {
        const { contracts } = this.props;
        const { Revocation } = contracts;
        const dataKey = this.props.accumulatorKey;
        const accList = Revocation.getAccList[dataKey] && Revocation.getAccList[dataKey].value;
        if (accList && accList[0] && !this.props.selectedAcc) this.props.selectAccumulator(accList[0]);
        return (
            <div>
                <Select
                    showSearch
                    style={{ width: '80%' }}
                    optionFilterProp="children"
                    onChange={this.props.selectAccumulator}
                    value={this.props.selectedAcc}
                    filterOption={(input, option) =>
                        option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                    }
                    dropdownRender={(option) => (
                        <div>
                            {option}
                            <AccumulatorRegister block drizzle={this.props.drizzle} />
                        </div>
                    )}
                >
                    {accList && accList.map((acc, index) =>
                        <Option key={index} value={acc}>
                                <span style={{ whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden', width: '80%' }}>
                                    {acc}
                                </span>
                        </Option>)}
                </Select>
            </div>
        )
    }
}

export default withRouter(connect(
    (state) => ({
        contracts: state.contracts,
        accumulator: state.appReducer.accumulator,
        accumulatorKey: state.appReducer.accumulatorKey,
        selectedAcc: state.appReducer.selectedAcc,
        uport: state.appReducer.uport,
        state,
    }),
    (dispatch) => ({
        addAccumulator: (acc, id) => dispatch({ type: 'SETUP_ACCUMULATOR', value: acc, used: id }),
        addAccumulatorKey: (dataKey) => dispatch({ type: 'ADD_ACCUMULATOR_KEY', dataKey }),
        selectAccumulator: (value) => dispatch({ type: 'SELECT_ACCUMULATOR', value })
    })
)(AccumulatorSelect));