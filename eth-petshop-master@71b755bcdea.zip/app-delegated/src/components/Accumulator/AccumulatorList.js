import React, { Component } from 'react';
import { connect } from 'react-redux'
import { Table, Skeleton } from 'antd';
import AccumulatorCapacity from './AccumulatorCapacity';
import AccumulatorEnabled from './AccumulatorEnabled';

class AccumulatorList extends Component {
    state = { loading: false }
    componentDidMount = () => {
        const { drizzle, uport } = this.props;
        const ownerId = (uport.keypair.did.split(':')[2]);
        const contract = drizzle.contracts.Revocation;
        const dataKey = contract.methods["getAccList"].cacheCall(ownerId);
        this.props.addAccumulatorKey(dataKey);
    }
    renderColumns(accList) {
        const { drizzle } = this.props;
        var columns = [];
        accList.map(accId => {
            const col = {
                key: accId,
                id: accId,
                status: <AccumulatorEnabled drizzle={drizzle} accId={accId} />,
                capacity: <AccumulatorCapacity drizzle={drizzle} accId={accId} />,
            }
            columns.unshift(col);
        })
        return columns;
    }

    columns = [
        {
            title: 'Accumulator ID',
            dataIndex: 'id',
            key: 'id',
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
        },
        {
            title: 'Capacity',
            dataIndex: 'capacity',
            key: 'capacity',
        }
    ]

    render() {
        const { contracts } = this.props;
        const { Revocation } = contracts;
        const dataKey = this.props.accumulatorKey;
        const accList = Revocation.getAccList[dataKey] && Revocation.getAccList[dataKey].value;
        let contents = null;
        if (accList) contents = this.renderColumns(accList);
        return (
            <div>
                {this.state.loading? <Skeleton active/>:
                <Table
                    pagination={{ pageSize: 5 }}
                    columns={this.columns}
                    dataSource={contents}
                    expandedRowRender={accumulator => <span style={{ margin: 0 }}>{accumulator.description}</span>}
                />}
            </div>
        )
    }
}

export default connect(
    (state) => ({
        contracts: state.contracts,
        accumulatorKey: state.appReducer.accumulatorKey,
        uport: state.appReducer.uport,
        state,
    }),
    (dispatch) => ({
        addAccumulator: (acc, id) => dispatch({ type: 'SETUP_ACCUMULATOR', value: acc, used: id }),
        addAccumulatorKey: (dataKey) => dispatch({ type: 'ADD_ACCUMULATOR_KEY', dataKey })
    })
)(AccumulatorList);