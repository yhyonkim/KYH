import React, { Component } from 'react'
import { connect } from 'react-redux'
import generateVanityAddress from '../../functions/generateVanityAddress';
import { Button, Icon } from 'antd';

class AccumulatorRegister extends Component {

    state = { accId: null, number: 20, stackId: null } // How many do you want?

    setupAccumulator = () => {
        console.log('setup');
        const { drizzle, state, uport, accumulatorCap } = this.props;
        const contract = drizzle.contracts.Revocation;
        const newAcc = generateVanityAddress();
        const ownerId = (uport.keypair.did.split(':')[2]);
        const stackId = contract.methods.setup.cacheSend(ownerId, newAcc, accumulatorCap, { from: state.accounts[0], gas: 3000000 });
        this.setState({ accId: newAcc, stackId });
    }

    getTxStatus = () => {
        const { transactions, transactionStack } = this.props.state;
        const txHash = transactionStack[this.state.stackId];
        if (txHash && transactions[txHash]){
            if (transactions[txHash].status === 'success') {
                console.log("Accumulator with id '" + this.state.accId + "' setup : success");
            } else {
                console.log("ERROR: SetupAccumulator, transaction error")

            }
        }
    }

    render() {
        this.getTxStatus();
        return (
            <Button block={this.props.block} onClick={this.setupAccumulator}>
                <Icon type="plus"/> New Accumulator
            </Button>
        );
    }
}

export default connect(
    (state, props) => {
        return {
            accumulator: state.appReducer.accumulator,
            accumulatorCap: state.appReducer.accumulatorCap,
            usedAccId: state.appReducer.usedAccId,
            uport: state.appReducer.uport,
            state
        }
    },
    (dispatch) => ({
    })
)(AccumulatorRegister)