import React from 'react';
import { connect } from 'react-redux';
import { Button } from 'antd';

class ConnectWithUport extends React.Component {
    render() {
        const { user, didAuthLoading, onConnectRequest, onDisconnectRequest } = this.props;
        return (
            <span style={{...this.props.style, margin: '0 0 0 auto'}}>
                {user ?
                    <Button type="danger" loading={didAuthLoading} onClick={onDisconnectRequest}>
                        {didAuthLoading ? `Deauthorizing...` : `Deauthorize`}
                    </Button>
                    :
                    <Button type="default" loading={didAuthLoading} onClick={onConnectRequest}>
                        {didAuthLoading ? `Authenticating...` : `DID Auth`}
                    </Button>
                }
            </span>
        )
    }
}
export default connect(
    (state) => ({
        user: state.appReducer.user,
        didAuthLoading: state.appReducer.didAuthLoading,
        state
    }),
    (dispatch) => ({
        onConnectRequest: () => dispatch({
            type: 'CONNECT_UPORT_REQUEST', request: {
                requested: ['name', 'phone', 'email', 'country'],
                notifications: false,
                vc: []
            }
        }),
        onDisconnectRequest: () => dispatch({ type: 'DISCONNECT_UPORT_REQUEST', request: { requested: ['disconnect'], vc: [] } })
    })
)(ConnectWithUport)
