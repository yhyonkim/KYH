import React from "react";
import { connect } from 'react-redux';
import { hasValue } from '../../utilities/utils';
import { Button, message } from 'antd';

class SchemaRegister extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            stackId: null,
        }
    }

    handleClick = e => { 
        e.preventDefault();
        const { onRegisterSchemaRequested } = this.props;
        const { schemaId, schema, uport, state, drizzle } = this.props;
        let title;
        try {
            title = Object.keys(JSON.parse(schema).properties)[0];
        } catch (e) {
            return message.warning('Incorrect JSON format');
        }
        if (!schemaId) {
            return message.warning('No Schema ID');
        }
        const contract = drizzle.contracts.Schema;
        const ownerId = (uport.keypair.did.split(':')[2]);
        const stackId = contract.methods["set"].cacheSend(schemaId, schema.replace(/\s/g,''), ownerId, title, {from : state.accounts[0], gas:3000000});
        message.loading('Registering schema in progress...', 1).then(()=>this.setState({ stackId }));
    }
    getTxStatus = () => {
        const { transactions, transactionStack } = this.props;
        const txHash = transactionStack[this.state.stackId];
        if (!txHash) return null;
        if (transactions[txHash]){
            if (transactions[txHash].status === 'success'){
                message.success('Succesfully Registered');
                this.setState({ stackId: null });
                this.props.hideSchemaModal();
            }
        }
      };

    render() {
        this.getTxStatus();
        return (
                <Button key={this.props.key} loading={this.props.loading} type="primary" onClick={this.handleClick}>
                    Register
                </Button>
        )
    }
}

export default connect(
    (state, props) => (
    {
        transactions: state.transactions,
        transactionStack: state.transactionStack,
        schema: state.appReducer.schema,
        schemaId: state.appReducer.schemaId,
        uport: state.appReducer.uport,
        state: state,
        transactionStackIndex: state.appReducer.txStackIndex,
        schemaJsonCorrect: state.appReducer.schemaJsonCorrect,
    }),
    (dispatch) => ({
        hideSchemaModal: () => dispatch({ type: 'HIDE_SCHEMA_MODAL' }),
    })
)(SchemaRegister);