import React from "react";
import { connect } from 'react-redux';

class SchemaTitle extends React.Component {
    state = {dataKey: null}

    componentDidMount = () => {
        const {drizzle, addr} = this.props;
        const schemaID = addr;
        const contract = drizzle.contracts.Schema;
        const dataKey = contract.methods["getTitle"].cacheCall(schemaID);
        this.setState({dataKey});
    }

    render(){
        const { contracts, addr, schemaTitles} = this.props;
        const schemaTitle = contracts.Schema.getTitle[this.state.dataKey] && contracts.Schema.getTitle[this.state.dataKey].value;
        if (schemaTitle && !schemaTitles[addr]) this.props.setSchemaTitle(addr, schemaTitle);
        return(
            <span>{schemaTitle}</span>
        )
    }
}


export default connect(
    (state) => ({
        schemaTitles: state.appReducer.schemaTitles,
        contracts: state.contracts,
    }),
    (dispatch) => ({
        setSchemaTitle: (id, title) => dispatch({ type: 'SET_SCHEMA_TITLE', id, title})
    })
)(SchemaTitle);