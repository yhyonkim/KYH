import React, { Component } from 'react';
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import SchemaDetail from './SchemaDetail';
import SchemaTitle from './SchemaTitle';
import { Table, Button, Icon } from 'antd';

class SchemaList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dataKey: null,
        }
    }

    componentDidMount = () => {
        const { drizzle, uport } = this.props;
        const id = (process.env.REACT_APP_GOV_DID.split(':')[2]);
        const contract = drizzle.contracts.Schema;
        const dataKey = contract.methods["getList"].cacheCall(id);
        this.setState({ dataKey });
    }

    renderColumns(schemaList) {
        var columns = [];
        schemaList.map(id => {
            const col = {
                key: id,
                id: id,
                title: <SchemaTitle drizzle={this.props.drizzle} index={id} addr={id} />,
                request: <Button><Icon type="solution"/>Request</Button>,
                description: <SchemaDetail addr={id} drizzle={this.props.drizzle} />
            }
            columns.unshift(col);
        })
        return columns;
    }

    columns = [
        {
            title: 'Schema ID',
            dataIndex: 'id',
            key: 'id',
        },
        {
            title: 'Title',
            dataIndex: 'title',
            key: 'title',
        },
    ]

    render() {
        const { contracts } = this.props;
        const { Schema } = contracts;
        const schemaList = Schema.getList[this.state.dataKey];
        return (
            <div>
                <Table
                    columns={this.columns}
                    dataSource={schemaList ? this.renderColumns(schemaList.value) : null}
                    expandedRowRender={schema => <span style={{ margin: 0 }}>{schema.description}</span>}
                />
            </div>
        )
    }
}

export default withRouter(connect(
    (state) => ({
        uport: state.appReducer.uport,
        contracts: state.contracts,
        user: state.appReducer.user,
        state,
    }),
    (dispatch) => ({})
)(SchemaList));