import React from 'react';
import { connect } from 'react-redux';
import SchemaRegister from './SchemaRegister';
import generateVanityAddress from '../../functions/generateVanityAddress';
import { Modal, Button, Icon, Popover } from 'antd';

const content = (
    <div><Icon type="warning" theme="twoTone" twoToneColor="#eb2f96"/> Only Government can register schema</div>
)
class SchemaRegisterForm extends React.Component {
    state = {
        ModalText: 'Default',
        visible: false,
        confirmLoading: false,
    }

    handleOk = () => {
        this.props.showSchemaModal();
    };

    handleCancel = () => {
        this.props.hideSchemaModal();
    };

    render() {
        const { visible, confirmLoading } = this.state;
        const { onSchemaChanged, onSchemaIDChanged, generateSchemaId, schema, schemaId, SchemaModal, showSchemaModal } = this.props;
        return (
            <Popover content={content}>
                <Button onClick={showSchemaModal} disabled={true}><Icon type="edit" />Schema 등록</Button>
                <Modal
                    width="90%"
                    title="Schema 등록"
                    visible={SchemaModal}
                    onOk={this.handleOk}
                    confirmLoading={confirmLoading}
                    onCancel={this.handleCancel}
                    footer={[
                        <Button key="back" onClick={this.handleCancel}>
                            Return
                        </Button>,
                        <SchemaRegister key="submit" drizzle={this.props.drizzle} loading={confirmLoading} />
                    ]}
                >
                    <div className="steps-content">
                        <form>
                            <div>
                                <textarea id="schema" className="md-textarea form-control" style={{ width: '80%', display: 'inline' }} rows="20" value={schema} onChange={onSchemaChanged} />
                            </div>
                            <label>SchemaID : </label><br />
                            <div className="input-group" style={{ width: '80%', margin: 'auto' }}>
                                <span className="input-group-addon">did:ethr:</span>
                                <input id="schemaID" className="form-control" type="text" value={schemaId} onChange={onSchemaIDChanged} />
                                <span className="input-group-btn">
                                    <button className="btn btn-default" type="button" onClick={generateSchemaId}>생성</button>
                                </span>
                            </div>
                        </form>
                    </div>
                </Modal>
            </Popover>
        )
    }
}

export default connect(
    (state) => ({
        user: state.appReducer.user,
        schema: state.appReducer.schema,
        schemaId: state.appReducer.schemaId,
        SchemaModal: state.appReducer.SchemaModal,
    }),
    (dispatch) => ({
        onSchemaChanged: (event) => dispatch({ type: 'REGISTER_SCHEMA_SET_SCHEMA', value: event.target.value }),
        onSchemaIDChanged: (event) => dispatch({ type: 'REGISTER_SCHEMA_SET_ID', value: event.target.value }),
        generateSchemaId: () => dispatch({ type: 'REGISTER_SCHEMA_GENERATE_ID', value: generateVanityAddress() }),
        showSchemaModal: () => dispatch({ type: 'SHOW_SCHEMA_MODAL' }),
        hideSchemaModal: () => dispatch({ type: 'HIDE_SCHEMA_MODAL' })
    })
)(SchemaRegisterForm)
