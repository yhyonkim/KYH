import React from "react";
import { connect } from 'react-redux';
import IssueCredential from '../Credential/IssueCredential';

class SchemaDetail extends React.Component {
    state = { dataKey: null }

    componentDidMount = () => {
        const { drizzle, addr } = this.props;
        const id = addr;
        const contract = drizzle.contracts.Schema;
        const dataKey = contract.methods["get"].cacheCall(id);
        // this.props.addSchemaKey(id, dataKey);
        this.setState({ dataKey });
    }
    beautify = (jsonString) => {
        try {
            const jsonObj = JSON.parse(jsonString);
            return JSON.stringify(jsonObj, null, 4);
        } catch (e) {
            // console.log("failed beautifying json");
            return jsonString;
        }
    }
    canBeParsed = (jsonString) => {
        try {
            JSON.parse(jsonString);
            return true;
        } catch (e) {
            return false;
        }
    }

    getTitle = (jsonstring) => {
        try {
            return Object.keys(JSON.parse(jsonstring).properties)[0];
        } catch (e) {
            return null;
        }
    }

    render() {
        const { addr, contracts } = this.props;
        const schema = contracts.Schema.get[this.state.dataKey];
        return (
            <div>
                <br/>
                <h3>{schema && schema.value && this.getTitle(schema.value)}</h3>
                <br />
                <pre style={{ textAlign: 'left' }}>{schema && this.beautify(schema.value)}</pre>        
            </div>
        )
    }
}


export default connect(
    (state) => ({
        contracts: state.contracts,
    }),
    (dispatch) => ({
        createCredential: (schema) => dispatch({ type: 'CREATE_CREDENTIAL', schema: schema}),
        addSchemaKey: (id, dataKey) => dispatch({ type: 'ADD_SCHEMA_KEY', id, dataKey})
    })
)(SchemaDetail);