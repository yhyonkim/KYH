import React from 'react';
import { connect } from 'react-redux';
import DelegateIssuer from './DelegateIssuer';

class DelegateIssuerForm extends React.Component {
    render () {
        const { onQualificationPeriod, initDelegationForm, onTargetId, qualificationPeriod, targetId, showDelegationForm, toggleDelegationForm, isDelegated } = this.props;
        return (
            <div>
                {
                    showDelegationForm ? 
                    (
                        <form>
                            <div className="input-group" style={{width:'30%', margin:'auto', marginBottom: '15px'}}>
                                <span className="input-group-addon">기간 : </span>
                                <input id="qualificationPeriod" className="form-control"  type="text" value={qualificationPeriod} onChange={onQualificationPeriod} />
                            </div>
                            <div className="input-group" style={{width:'50%', margin:'auto', marginBottom: '15px'}}>
                                <span className="input-group-addon">위임할 상대 ID : </span>
                                <input id="targetID" className="form-control"  type="text" value={targetId} onChange={onTargetId} />
                                
                            </div>
                            <br/>
                            {isDelegated ? <div> 위임이 완료되었습니다. </div> : null }

                            <br/>
                            <DelegateIssuer drizzle={this.props.drizzle}/>
                            <button className="btn btn-default btn-adopt" onClick={initDelegationForm}>
                                설정 초기화
                                &nbsp; <i style={{color:'red'}} className="far fa-times"/>
                            </button>
                            &nbsp; &nbsp; 
                            <button className="btn btn-default btn-adopt" onClick={toggleDelegationForm}>
                                닫기 
                                &nbsp; <i style={{color:'red'}} className="far fa-times"/>
                            </button>
                        </form>
                    ):
                    (
                        <button className="btn btn-default btn-adopt" onClick={toggleDelegationForm}>
                            자격 위임 설정
                        </button>
                    )
                }
                
                <br/>
            </div>
        )
    }
}
  
export default connect(
    (state) => ({
        qualificationPeriod: state.appReducer.qualificationPeriod,
        targetId: state.appReducer.targetId,
        showDelegationForm: state.appReducer.showDelegationForm,
        isDelegated: state.appReducer.isDelegated,
    }),
    (dispatch) => ({
        onQualificationPeriod: (event) => dispatch({ type: 'DELEGATE_QUALIFICATION_SET_PERIOD'
            , value: event.target.value
        }),
        onTargetId: (event) => dispatch({ type: 'DELEGATE_QUALIFICATION_SET_TARGET_ID'
            , value: event.target.value
        }),
        toggleDelegationForm: () => dispatch({ type: 'TOGGLE_DELEGATION' }),
        initDelegationForm: () => dispatch({ type: 'INIT_DELEGATION_FORM' })
    })
)(DelegateIssuerForm)
  