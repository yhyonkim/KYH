import React from "react";
import { Steps, Button, message, Icon } from 'antd';
import { connect } from "react-redux";

import DidConnector from '../DidConnector'

const { Step } = Steps;

class AuthPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 0,
    };
  }

  steps = [
    {
      title: 'DID Auth',
      content: <DidConnector/>,
      icon: <Icon type="user"/>
    },
    {
      title: 'Waiting Response',
      content: <DidConnector/>,
      icon: <Icon type={this.props.user?"check-circle":"loading"}/>
    },
    {
      title: 'Done',
      content: <DidConnector/>,
      icon: <Icon type="smile-o"/>
    },
  ];

  onChange = current => {
    this.props.authStep(current);
  }

  render() {
    const { current, user } = this.props;
    return (
      <div>
        <Steps current={current} >
          {this.steps.map(item => (
            <Step key={item.title} title={item.title} icon={item.icon} />
          ))}
        </Steps>
        <div className="steps-content">{this.steps[current].content}</div>
      </div>
    );
  }
}


export default connect(
  (state) => ({
    current: state.appReducer.authStepCurrent? state.appReducer.authStepCurrent : 0,
    user: state.appReducer.user,
    state
  }),
  (dispatch) => ({
      authStep: (current) => dispatch({ type: 'AUTH_STEP', position: current }),
  })
)(AuthPage);