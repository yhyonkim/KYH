import React from "react";
import { Steps, Button, message, Icon } from 'antd';

import SchemaList from '../Schema/SchemaList';
import IssueCredential from '../Credential/IssueCredential';
import Success from '../Success';

const { Step } = Steps;



class CredentialPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 0,
    };
  }

  steps = [
    {
      title: 'Select Schema',
      content: <SchemaList drizzle={this.props.drizzle} />,
      icon: <Icon type="solution" />
    },
    {
      title: 'Fill Credential',
      content: <div><Button>Schema ID 보내기</Button></div>,
      icon: this.props.receivedCrendential ? <Icon type="check-circle" /> : <Icon type="loading" />
    },
    {
      title: 'Finish Credential',
      content: <IssueCredential drizzle={this.props.drizzle} />,
      icon: <Icon type="form" />
    },
    {
      title: 'Done',
      content: <Success comment='issued a credential!' />,
      icon: <Icon type="smile-o" />
    },
  ];

  next() {
    const current = this.state.current + 1;
    this.setState({ current });
  }

  prev() {
    const current = this.state.current - 1;
    this.setState({ current });
  }
  onChange = current => {
    this.setState({ current });
  }

  render() {
    const { current } = this.state;
    return (
      <div>
        <Steps size="small" current={current} onChange={this.onChange}>
          {this.steps.map(item => (
            <Step key={item.title} title={item.title} icon={item.icon} />
          ))}
        </Steps>
        <div className="steps-content">{this.steps[current].content}</div>
        <div className="steps-action">
          {current > 0 && (
            <Button style={{ marginRight: 8 }} onClick={() => this.prev()}>
              Previous
            </Button>
          )}
          {current === this.steps.length - 1 && (
            <Button id="success" className="steps-button" onClick={() => message.success('Processing complete!')}>
              Done
            </Button>
          )}
          {current < this.steps.length - 1 && (
            <Button className="steps-button" type="primary" onClick={() => this.next()}>
              Next
            </Button>
          )}
        </div>
      </div>
    );
  }
}

export default CredentialPage;