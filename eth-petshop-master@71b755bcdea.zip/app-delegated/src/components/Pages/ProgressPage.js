import React from "react";
import { Steps, Button, message, Icon } from 'antd';

import DidConnector from '../DidConnector'
import AccumulatorList from '../Accumulator/AccumulatorList';
import SchemaRegisterForm from '../Schema/SchemaRegisterForm';
import SchemaList from '../Schema/SchemaList';

const { Step } = Steps;



class ProgressPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 0,
    };
  }

  steps = [
    {
      title: 'DID Auth',
      content: <DidConnector/>,
      icon: <Icon type="user"/>
    },
    {
      title: 'Select Schema',
      content: <AccumulatorList drizzle={this.props.drizzle}/>,
      icon: <Icon type="solution"/>
    },
    {
      title: 'Fill Credential',
      content: <SchemaRegisterForm/>,
      icon: this.props.receivedCrendential?<Icon type="check-circle"/>:<Icon type="loading"/>
    },
    {
      title: 'Finish Credential',
      content: <SchemaRegisterForm/>,
      icon: <Icon type="form"/>
    },
    {
      title: 'Done',
      content: <SchemaList drizzle={this.props.drizzle}/>,
      icon: <Icon type="smile-o"/>
    },
  ];

  next() {
    const current = this.state.current + 1;
    this.setState({ current });
  }

  prev() {
    const current = this.state.current - 1;
    this.setState({ current });
  }
  onChange = current => {
    this.setState({ current });
  }

  render() {
    const { current } = this.state;
    return (
      <div>
        <Steps size="small" current={current} onChange={this.onChange}>
          {this.steps.map(item => (
            <Step key={item.title} title={item.title} icon={item.icon} />
          ))}
        </Steps>
        <div className="steps-content">{this.steps[current].content}</div>
        <div className="steps-action">
          {current > 0 && (
            <Button style={{ marginRight: 8 }} onClick={() => this.prev()}>
              Previous
            </Button>
          )}
          {current === this.steps.length - 1 && (
            <Button id="success" className="steps-button" onClick={() => message.success('Processing complete!')}>
              Done
            </Button>
          )}
          {current < this.steps.length - 1 && (
            <Button className="steps-button" type="primary" onClick={() => this.next()}>
              Next
            </Button>
          )}
        </div>
      </div>
    );
  }
}

export default ProgressPage;