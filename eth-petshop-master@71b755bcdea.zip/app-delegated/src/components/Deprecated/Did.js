import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Text, Name } from '../../styles/Did.style';
import { uportConnect } from '../../utilities/uportSetup';

class AppDid extends Component {
  render () {
    return (
      <Text>
          <Name>DID :</Name>
          {uportConnect.state.keypair.did}
      </Text>
    )
  }
}

const mapStateToProps = (state, props) => (
  {}
);
function mapDispatchToProps (dispatch) {
  return {}
}
export default connect(mapStateToProps, mapDispatchToProps)(AppDid);
