import React, { Component } from 'react'
import { connect } from 'react-redux'

class RevokeCredential extends Component {
    
    state = {accId:null, stackId: null}

    constructor(props) {
        super(props);
        this.revokeCredential = this.revokeCredential.bind(this);
        this.getTxStatus = this.getTxStatus.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.revokeCredInfo = this.revokeCredInfo.bind(this);
    }

    revokeCredential = e => {
        const {drizzle, state, credId, credentialList} = this.props;
        const contract = drizzle.contracts.Revocation;
        
        if(!credentialList[credId].nonrevocation) {
            console.log("ERROR : the credential is already revoked")
            return;
        }
        const id = credentialList[credId].accId;
        const index = credentialList[credId].index;
        const stackId = contract.methods.revokeCred.cacheSend(id,index,{from: state.accounts[0]});
        this.setState({accId : id, stackId});
    }

    handleClick = e => {
        const {drizzle, accumulator} = this.props;
        const contract = drizzle.contracts.Revocation;
        const lastAcc = accumulator.slice(-1).pop();
        if(lastAcc===undefined || !lastAcc.status) {
            console.log("Error : Need to make new accumulator")
            return;
        }
        const id = lastAcc.id;
        const stackId = contract.methods["getNonrevidx"].cacheCall(id);
        this.setState({accId : id, stackId});
    }

    getTxStatus = () => {
        const { transactions, transactionStack } = this.props.state;
        const txHash = transactionStack[this.state.stackId];
        if (!txHash || !transactions[txHash]) return null;
        if(transactions[txHash].status === 'success') {
            this.revokeCredInfo();
            this.setState({stackId:null});
        }
        //console.log("Revoke credential, Transaction status : "+(transactions[txHash] && transactions[txHash].status));
        return transactions[txHash].status;
    }

    revokeCredInfo() {
        const {credentialList, updateCredential} = this.props;
        let content = credentialList[this.props.credId];
        content['nonrevocation'] = false;
        credentialList[this.props.credId] = content;
        updateCredential(credentialList);
    }

    render () {
        const result = this.getTxStatus();
        if((this.state.stackId!==null)&&(result==='success')) {
            console.log("Accumulator with id '"+this.state.accId+"' revoke cred "+this.props.credId+" : "+result)
        } else if (result==='error') {
            console.log("ERROR: RevokeCredential, transaction error")
        } else if (this.state.stackId!==null) {
            const result = this.props.state.contracts.Revocation.getNonrevidx[this.state.stackId];
            if(result) console.log("Accumulator with id '"+this.state.accId+"' non-revocation index : "+result.value)
        }
        return (
            <div>
				<button type="button" className="btn btn-default btn-adopt" onClick={()=>this.props.revokeCredential(this.props)}>
				Revoke credential</button>
			</div>
        )
    }
}

export default connect(
    (state, props) => {
        return {
            accumulator : state.appReducer.accumulator,
            credentialList : state.appReducer.credentialList,
            state
        }
    },
    (dispatch) => ({
        updateCredential: (list) => dispatch({type: 'UPDATE_CREDENTIAL', value: list}),
        revokeCredential: (props) => dispatch({type: 'REVOKE_CREDENTIAL', props})
    })
  )(RevokeCredential)