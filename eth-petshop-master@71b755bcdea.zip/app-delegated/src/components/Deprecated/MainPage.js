import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
<<<<<<< HEAD:app-gov/src/components/Deprecated/MainPage.js
import SchemaList from '../Schema/SchemaList';
import DelegateIssuerForm from '../DelegateIssuerForm';
import AuthPage from '../Pages/AuthPage';
import CredentialList from '../Credential/CredentialList';
import AccumulatorList from '../Accumulator/AccumulatorList';
=======
import SchemaList from './Schema/SchemaList';
import DelegateIssuerForm from './DelegateIssuerForm';
import RequestSchemaID from './RequestSchemaID';
import BlsTest from './BlsTest';
import AuthPage from './Pages/AuthPage';
import CredentialList from './Credential/CredentialList';
import AccumulatorList from './Accumulator/AccumulatorList';
>>>>>>> b31704c3bd6890c4d3702b12eec62fe5ee7b8813:app-gov/src/components/MainPage.js
import { Menu, Icon, Tabs } from 'antd';
import Accumulator from '../Accumulator';
import DidConnector from '../DidConnector';

const { TabPane } = Tabs;

// import { MainPageWrap } from '../styles/MainPage.style';

class TabKey extends Component {
  render() {
    return (
      <span><Icon type={this.props.type} />{this.props.content}</span>
    )
  }
}

class MainPage extends Component {
  render() {
    return (
      <div>
        <Accumulator drizzle={this.props.drizzle}/>
        <Tabs defaultActiveKey="1">
          <TabPane tab={<TabKey type="layout" content="Schema Registry" />} key="1">
            <div className="tab-content">
              <SchemaList drizzle={this.props.drizzle} />
            </div>
          </TabPane>
          <TabPane tab={<TabKey type="calculator" content="Accumulators" />} key="2">
            <div className="tab-content">
            <AccumulatorList drizzle={this.props.drizzle} />
            </div>
          </TabPane>
          <TabPane tab={<TabKey type="form" content="Credentials" />} key="3">
            <div className="tab-content">
            <CredentialList drizzle={this.props.drizzle} />
            </div>
          </TabPane>
        </Tabs>
        <hr />
        <h3>Delegate Qualification</h3>
        <br />
        <DelegateIssuerForm drizzle={this.props.drizzle} />
        <br />
        <hr/>
        <h3>Receive Schema ID</h3>
        <br/>
          <RequestSchemaID drizzle={this.props.drizzle}/>
        <br/>
        <hr/>
        <h3>Receive Schema ID</h3>
        <br/>
          <RequestSchemaID drizzle={this.props.drizzle}/>
        <br/>
        <hr />
        <AuthPage />
      </div>
    )
  }
}
// export default MainPage
export default withRouter(connect(
  (state) => ({
    state,
  }),
  (dispatch) => ({})
)(MainPage));