import React, { Component } from 'react'
import { connect } from 'react-redux'

class IssueNonrevocation extends Component {
    state = {accId:null, credId:null, stackId: null, dataKey:null}

    constructor(props) {
        super(props);
        this.issueNonrevocation = this.issueNonrevocation.bind(this);
        this.getTxStatus = this.getTxStatus.bind(this);
        this.getAccumulatorValue = this.getAccumulatorValue.bind(this);
        this.getCredentialInfo = this.getCredentialInfo.bind(this);
        this.storeCredentialInfo = this.storeCredentialInfo.bind(this);
    }

    issueNonrevocation = e => {
        const {drizzle, state, accumulator, credentialList} = this.props;
        const contract = drizzle.contracts.Revocation;

        const lastAcc = accumulator.slice(-1).pop();
        if(lastAcc===undefined || !lastAcc.status) {
            console.log("Error : Need to make new accumulator")
            return;
        }
        const id = lastAcc.id;
        let stackId = contract.methods.issueCred.cacheSend(id,{from: state.accounts[0]});
        let credId = null;
        do{
            credId = ("00000000"+Math.floor(Math.random()*10000000)).slice(-8);
        } while(credentialList.hasOwnProperty(credId))
        this.setState({accId : id, stackId, credId});
    }

    getAccumulatorValue = e => {
        const {drizzle, accumulator} = this.props;
        const contract = drizzle.contracts.Revocation;
        const lastAcc = accumulator.slice(-1).pop();
        if(lastAcc===undefined || !lastAcc.status) {
            console.log("Error : Need to make new accumulator")
            return;
        }
        const id = lastAcc.id;
        const dataKey = contract.methods["getAcc"].cacheCall(id);
        this.setState({accId : id, dataKey})
    }

    getTxStatus = () => {
        const { transactions, transactionStack } = this.props.state;
        const txHash = transactionStack[this.state.stackId];
        if (!txHash || !transactions[txHash]) return null;
        if(transactions[txHash].status === 'success') {
            this.getCredentialInfo();
            this.setState({stackId:null});
        }
        //console.log("Issue new non-revocation credential, Transaction status : "+(transactions[txHash] && transactions[txHash].status));
        return transactions[txHash].status;
    }

    getCredentialInfo() {
        const contract = this.props.drizzle.contracts.Revocation;
        contract.methods.getAllInfo(this.state.accId).call({from: this.props.state.accounts[0]})
        .then(r => {
            this.storeCredentialInfo(r);
        }).catch(e=>console.log(e))
    }

    storeCredentialInfo(r) {
        const {credentialList, addNewCredential} = this.props;
        if(credentialList.hasOwnProperty(this.state.credId)) return;
        credentialList[this.state.credId] = { accId: this.state.accId, index: r.idx, nonrevocation:true };
        addNewCredential(credentialList);
    }

    render () {
        const result = this.getTxStatus();
        if((this.state.stackId!==null)&&(result==='success')) {
            console.log("Accumulator with id '"+this.state.accId+"' issues : "+result)
        } else if (result==='error') {
            console.log("ERROR: IssueNonrevocation, transaction error")
        } else if (this.state.dataKey!==null) {
            const res = this.props.state.contracts.Revocation.getAcc[this.state.dataKey];
            if(res) console.log("Accumulator with id '"+this.state.accId+"' : "+res.value);
        }
        return (
            <div>
				<button type="button" className="btn btn-default btn-adopt" onClick={this.issueNonrevocation}>
				Issue non-revocation credential</button>
                <button type="button" className="btn btn-default btn-adopt" onClick={this.getAccumulatorValue}>
				Accumulator value</button>
			</div>
        )
    }
}

export default connect(
    (state, props) => {
        return {
            accumulator : state.appReducer.accumulator,
            credentialList : state.appReducer.credentialList,
            state
        }
    },
    (dispatch) => ({
        addNewCredential: (list) => dispatch({type: 'ADD_NEW_CREDENTIAL', value: list}),
    })
  )(IssueNonrevocation)