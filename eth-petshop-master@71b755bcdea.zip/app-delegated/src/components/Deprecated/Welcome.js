import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter, Link } from 'react-router-dom'

import { WelcomeWrap, SubText } from '../../styles/Welcome.style';

class Welcome extends Component {
  render () {
    return (
      <WelcomeWrap>
        <h3>Welcome to Government system!</h3>
        <SubText>Make your identification card</SubText>
        <Link to="/main">
          <button className="btn btn-default btn-adopt">
            Let's start!
          </button>
        </Link>
      </WelcomeWrap>
    )
  }
}

const mapStateToProps = (state, props) => {
  return {state}
}
const mapDispatchToProps = (dispatch) => {
  return {}
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Welcome));
