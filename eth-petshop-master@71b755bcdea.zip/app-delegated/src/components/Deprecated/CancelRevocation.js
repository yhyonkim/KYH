import React, { Component } from 'react'
import { connect } from 'react-redux'

class CancelRevocation extends Component {
    
    state = {accId:null, stackId: null}

    constructor(props) {
        super(props);
        this.cancelRevocation = this.cancelRevocation.bind(this);
        this.getTxStatus = this.getTxStatus.bind(this);
        this.revokeCredInfo = this.revokeCredInfo.bind(this);
    }

    cancelRevocation = e => {
        const {drizzle, state, credId, credentialList} = this.props;
        const contract = drizzle.contracts.Revocation;

        if(credentialList[credId].nonrevocation) {
            console.log("ERROR : the credential is not revoked")
            return;
        }
        const id = credentialList[credId].accId;
        const index = credentialList[credId].index;
        const stackId = contract.methods.cancelRevocation.cacheSend(id,index,{from: state.accounts[0]});
        this.setState({accId : id, stackId});
    }

    getTxStatus = () => {
        const { transactions, transactionStack } = this.props.state;
        const txHash = transactionStack[this.state.stackId];
        if (!txHash || !transactions[txHash]) return null;
        if(transactions[txHash].status === 'success') {
            this.revokeCredInfo();
            this.setState({stackId:null});
        }
        //console.log("Revoke credential, Transaction status : "+(transactions[txHash] && transactions[txHash].status));
        return transactions[txHash].status;
    }

    revokeCredInfo() {
        const {credentialList, updateCredential} = this.props;
        let content = credentialList[this.props.credId];
        content['nonrevocation'] = true;
        credentialList[this.props.credId] = content;
        updateCredential(credentialList);
    }

    render () {
        const result = this.getTxStatus();
        if((this.state.stackId!==null)&&(result==='success')) {
            console.log("Accumulator with id '"+this.state.accId+"' cancel revocation of cred "+this.props.credId+" : "+result)
        } else if (result==='error') {
            console.log("ERROR: CancelRevocation, transaction error")
        }
        return (
            <div>
				<button type="button" className="btn btn-default btn-adopt" onClick={()=>this.props.cancelCredential(this.props)}>
				Cancel Revocation</button>
			</div>
        )
    }
}

export default connect(
    (state, props) => {
        return {
            accumulator : state.appReducer.accumulator,
            credentialList : state.appReducer.credentialList,
            state
        }
    },
    (dispatch) => ({
        updateCredential: (list) => dispatch({type: 'UPDATE_CREDENTIAL', value: list}),
        cancelCredential: (props) => dispatch({type: 'CANCEL_REVOKE_CREDENTIAL', props})
    })
  )(CancelRevocation)