import React, { Component } from 'react'
import { connect } from 'react-redux'
import { isNonZero } from '../../utilities/utils';
import Accumulator from '../Accumulator';
import Accumulators from './Accumulators';

class ManageAccumulators extends Component {
    
    componentWillMount() {
        this.getList = this.getList.bind(this);
        this.storeAccumulator = this.storeAccumulator.bind(this);
        this.storeAccumulators = this.storeAccumulators.bind(this);
    }

    getList() {
        const contract = this.props.drizzle.contracts.Revocation;
        const getAccListFunction = contract.methods.getAccList;
        
        getAccListFunction().call({from:''})
            .then(r => {
                this.storeAccumulators(r);
            }).catch(e => console.log(e))
    }

    storeAccumulators(accList) {
        const contract = this.props.drizzle.contracts.Revocation;

        accList.forEach(accId => {
            contract.methods.getIndex(accId).call({from:''})
                .then(indexes => {
                    this.storeAccumulator(accId, indexes)
                }).catch(e => console.log(e))
        });
    }

    storeAccumulator(accId, indexes) {
        const {accumulator, addAccumulator, usedAccId} = this.props;
        const enable = !(indexes[0]===indexes[1]);
        const newAcc = { id: accId, number: indexes[1], status:enable };
        if(usedAccId.has(accId.toUpperCase())) return;
        accumulator.push(newAcc);
        usedAccId.add(accId.toUpperCase());
        addAccumulator(accumulator, usedAccId);
    }

    render () {
        const { accumulator } = this.props;

        let contents = null;
        let button = null;
        let enable = false;
        if (isNonZero(accumulator.length)) {
            contents = accumulator.map(function(item, index){
                if(item.status) enable=true;
                return <Accumulator key={index} item={item} />
            });
        } else {
            this.getList();
        }
        button = <Accumulators drizzle={this.props.drizzle}/>;
        return (
            <div>
                <h3>Accumulators</h3>
                {contents}
                {button}
            </div>
        );
    }
}

export default connect(
    (state, props) => {
        return {
            accumulator : state.appReducer.accumulator,
            usedAccId : state.appReducer.usedAccId,
            schemaId : state.appReducer.schemaId,
            state
        }
    },
    (dispatch) => ({
        addAccumulator: (acc,id) => dispatch({type: 'SETUP_ACCUMULATOR', value: acc, used: id}),
    })
  )(ManageAccumulators)