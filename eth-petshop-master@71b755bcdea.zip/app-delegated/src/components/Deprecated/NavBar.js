import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter, Link } from 'react-router-dom'
import { isEmpty } from '../../utilities/utils';
import Did from './Did'

import { NavBarWrap, DemoText, LeftArea, RightArea, UserName} from '../../styles/NavBar.style';

class NavBar extends Component {
  renderLoginInfo(user, onDisconnectRequest) {
    if (isEmpty(user)) return null;
    return (
      <div>
        <UserName>{user.name}</UserName>
        <button className="btn btn-default btn-adopt" onClick={onDisconnectRequest}>
          Disconnect
        </button>
      </div>
    )
  }
  render () {
    return (
      <NavBarWrap>
        <Link to="/">
        <LeftArea>
          <DemoText>Government</DemoText>
        </LeftArea>
        </Link>
        <RightArea>
          <Did/>
        </RightArea>
      </NavBarWrap>
    )
  }
}

export default withRouter(connect(
  (state, props) => ({
    user: state.user
  }),
  (dispatch) => ({
      onDisconnectRequest: () => dispatch({ type: 'DISCONNECT_UPORT_REQUEST' })
  })
)(NavBar))