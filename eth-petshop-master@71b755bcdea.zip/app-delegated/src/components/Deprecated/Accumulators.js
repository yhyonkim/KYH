import React, { Component } from 'react'
import { connect } from 'react-redux'
import generateVanityAddress from '../../functions/generateVanityAddress';
import { isEmpty } from '../../utilities/utils';

class Accumulators extends Component {
    
    state = {accId:null, number:20, stackId: null} // How many do you want?

    constructor(props) {
        super(props);
        this.setupAccId = this.setupAccId.bind(this);
        this.setupAccumulator = this.setupAccumulator.bind(this);
        this.getTxStatus = this.getTxStatus.bind(this);
        this.storeAccumulator = this.storeAccumulator.bind(this);
    }

    setupAccId() {
        this.setupAccumulator(generateVanityAddress());
    }

    setupAccumulator = (accumulatorAddress) => {
        const {drizzle, state} = this.props;
        const contract = drizzle.contracts.Revocation;

        const stackId = contract.methods.setup.cacheSend(accumulatorAddress, this.state.number,{from: state.accounts[0], gas:3000000});
        this.setState({accId : accumulatorAddress, stackId});
    }

    getTxStatus = (txHash, transactions) => {
        if (isEmpty(transactions[txHash])) return null;
        if(transactions[txHash].status === 'success') {
            this.storeAccumulator();
        }
        return transactions[txHash].status;
    }

    storeAccumulator() {
        const {accumulator, addAccumulator, usedAccId} = this.props;
        const newAcc = { id: this.state.accId, number: this.state.number, status:true };
        if(usedAccId.has(this.state.accId.toUpperCase())) return;
        accumulator.push(newAcc);
        usedAccId.add(this.state.accId.toUpperCase());
        addAccumulator(accumulator, usedAccId);
        this.setState({stackId:null});
    }

    render () {
        const { transactions, transactionStack } = this.props.state;
        const result = this.getTxStatus(transactionStack[this.state.stackId], transactions);

        if((this.state.stackId!==null)&&(result==='success')) {
            console.log("Accumulator with id '"+this.state.accId+"' setup : "+result);
        } else if (result==='error') {
            console.log("ERROR: SetupAccumulator, transaction error")
        } 
        return (
            <button type="button" className="btn btn-default btn-adopt" onClick={this.setupAccId}>
                Setup New Accumulator
            </button>
        );
    }
}

export default connect(
    (state, props) => {
        return {
            accumulator : state.appReducer.accumulator,
            usedAccId : state.appReducer.usedAccId,
            schemaId : state.appReducer.schemaId,
            state
        }
    },
    (dispatch) => ({
        addAccumulator: (acc,id) => dispatch({type: 'SETUP_ACCUMULATOR', value: acc, used: id}),
    })
  )(Accumulators)