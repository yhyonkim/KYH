import React, { Component } from 'react';
import { Icon } from 'antd';

export default class Success extends Component {
    render() {
        return (
            <div>
                <Icon type="check-circle" theme="twoTone" twoToneColor="#52c41a" style={{ fontSize: '30px' }} />
                <br />
                <br />
                <h4 style={{ color: '#2f2f2f' }}>You have successfully {this.props.comment}</h4>
            </div>
        )
    }
}

