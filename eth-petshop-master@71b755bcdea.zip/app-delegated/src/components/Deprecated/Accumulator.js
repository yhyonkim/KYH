import React, { Component } from 'react'
import { connect } from 'react-redux'

class Accumulator extends Component {
    componentDidMount = () => {
        const { drizzle, uport } = this.props;
        const ownerId = (uport.keypair.did.split(':')[2]);
        const contract = drizzle.contracts.Revocation;
        const dataKey = contract.methods["getAccList"].cacheCall(ownerId);
        this.props.addAccumulatorKey(dataKey);
    }
    render () {
        return null;
    }
}
export default connect(
    (state) => ({
        uport: state.appReducer.uport,
        state
    }),
    (dispatch) => ({
        addAccumulatorKey: (dataKey) => dispatch({ type: 'ADD_ACCUMULATOR_KEY', dataKey })
    })
)(Accumulator);