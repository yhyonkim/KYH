import React, { Component } from 'react'
import { connect } from 'react-redux'
import { isEmpty, isTrue, isFalse } from '../../utilities/utils';
import { uportConnect } from '../../utilities/uportSetup';

class IssueCredential extends Component {
  state = {accId:null, accIndex:null, accWitness:null, accV:null, credId:null, stackId: null, dataKey: null, version:null}
  constructor(props) {
    super(props);
    this.renderNonrevocation = this.renderNonrevocation.bind(this);
    this.getTxStatus = this.getTxStatus.bind(this);
    this.getCredentialRevInfo = this.getCredentialRevInfo.bind(this);
    this.storeCredentialInfo = this.storeCredentialInfo.bind(this);
    this.sendCredential = this.sendCredential.bind(this);
  }
  renderHelpMessage = (user, showRegistrationForm, formIncomplite) => {
    if (isEmpty(user)) return null;
    if (isFalse(showRegistrationForm)) return (<p>발급 정보가 아직 입력되지 않았습니다.</p>);
    if (isTrue(formIncomplite))
      return (<p>자격증명에 들어갈 내용을 모두 채워주세요.</p>);
    else
      return (<p>위의 내용으로 자격증명을 발급합니다!</p>);
  };
  renderIssueButtons = (props) => {
    const { user, showRegistrationForm, formIncomplite } = props;
    if (isEmpty(user)) return null;
    // if (isFalse(showRegistrationForm)) return (null);
    // if (isTrue(formIncomplite))
    //   return (null);
    else
      return (
      <div>
        <button className="btn btn-default btn-adopt" 
                onClick={()=>this.renderNonrevocation('ALL')} >
            전자 민증 통합 발급
        </button>
        <br/>
        <div>
          <button className="btn btn-default btn-adopt" 
                onClick={()=>this.renderNonrevocation('NAME')} >
            전자 민증 이름 발급
          </button>
          <button className="btn btn-default btn-adopt" 
                onClick={()=>this.renderNonrevocation('BIRTH')} >
            전자 민증 생일 발급
          </button>
          <button className="btn btn-default btn-adopt" 
                onClick={()=>this.renderNonrevocation('ADDR')} >
            전자 민증 주소 발급
          </button>
        </div>
      </div>);
  };
  renderNonrevocation(ver) {
    const {drizzle, state, accumulator, credentialList} = this.props;
    const contract = drizzle.contracts.Revocation;

    const lastAcc = accumulator.slice(-1).pop();
    if(lastAcc===undefined || !lastAcc.status) {
        console.log("Error : Need to make new accumulator")
        return;
    }
    const id = lastAcc.id;
    const stackId = contract.methods.issueCred.cacheSend(id,{from: state.accounts[0]});
    let credId = null;
    do{
      credId = ("00000000"+Math.floor(Math.random()*10000000)).slice(-8);
    } while(credentialList.hasOwnProperty(credId))
    this.setState({accId : id, stackId, version:ver, credId});
  }
  getTxStatus = () => {
    const { transactions, transactionStack } = this.props.state;
    const txHash = transactionStack[this.state.stackId];
    if (!txHash || !transactions[txHash]) return null;
    if(transactions[txHash].status === 'success') {
      this.getCredentialRevInfo();
      this.setState({stackId:null});
    }
    //console.log("Issue new non-revocation credential, Transaction status : "+(transactions[txHash] && transactions[txHash].status));
    return transactions[txHash].status;
  }
  getCredentialRevInfo() {
    const contract = this.props.drizzle.contracts.Revocation;
    contract.methods.getAllInfo(this.state.accId).call({from: this.props.state.accounts[0]})
      .then(r => {
        this.storeCredentialInfo(r);
        this.setState({accIndex:r.idx, accWitness:r.witness})
      }).catch(e=>console.log(e))
  }
  storeCredentialInfo(r) {
    const {credentialList, addNewCredential} = this.props;
    if(credentialList.hasOwnProperty(this.state.credId)) return;
    credentialList[this.state.credId] = { accId: this.state.accId, index: r.idx, nonrevocation:true };
    addNewCredential(credentialList);

    const contract = this.props.drizzle.contracts.Revocation;
    contract.methods.getNonrevidx(this.state.accId).call({from: this.props.state.accounts[0]})
      .then(r => {
        this.sendCredential(r);
      }).catch(e=>console.log(e))
  }
  sendCredential(r) {
    const {uport, user, name, birth, address} = this.props;
    const {credId, accId, accIndex, accWitness} = this.state;
    const time30days = Math.floor(new Date().getTime()) + 30 * 24 * 60 * 60 * 1000;
    const content = {accId:accId, accIndex:accIndex, accWit:accWitness, accV:r};
    const births = birth.split('-');
    switch(this.state.version) {
      case 'ALL' :
        const cred1 = {
          exp: time30days,
          claim: {'GovIdentification': {id:credId, name:name, birth:{'year':births[0],'month':births[1],'day':births[2]}, address:address, 'Revocation':content}},
          vc: [],
          sub: user.did,
          iss: uport.keypair.did
        };
        console.log(cred1)
        return new Promise((resolve, reject)=> {
          uportConnect.sendVerification(cred1).then(()=>{
            return resolve(true);
          }).catch(e=>console.log(e))
        })

      case 'NAME' :
        const cred2 = {
          exp: time30days,
          claim: {'GovName': {id:credId, name:name, 'Revocation':content}},
          vc: [],
          sub: user.did,
          iss: uport.keypair.did
        };
        console.log(cred2)
        return new Promise((resolve, reject)=> {
          uportConnect.sendVerification(cred2).then(()=>{
            return resolve(true);
          }).catch(e=>console.log(e))
        })

      case 'BIRTH' :
        const cred3 = {
          exp: time30days,
          claim: {'Birthdate Credential': {id:credId, birth:{'year':births[0],'month':births[1],'day':births[2]}, 'Revocation':content}},
          vc: [],
          sub: user.did,
          iss: uport.keypair.did
        };
        console.log(cred3)
        return new Promise((resolve, reject)=> {
          uportConnect.sendVerification(cred3).then(()=>{
            return resolve(true);
          }).catch(e=>console.log(e))
        })

      case 'ADDR' :
        const cred4 = {
          exp: time30days,
          claim: {'GovAddress': {id:credId, address:address, 'Revocation':content}},
          vc: [],
          sub: user.did,
          iss: uport.keypair.did
        };
        console.log(cred4)
        return new Promise((resolve, reject)=> {
          uportConnect.sendVerification(cred4).then(()=>{
            return resolve(true);
          }).catch(e=>console.log(e))
        })

      default: break;
    }
    this.setState({version:null})
  }
  renderCredentialTransferResult(credentialTransfered) {
    if (isTrue(credentialTransfered)) {
      return (<p>전자 민증이 전송 되었습니다.</p>)
    }
  }
  render () {
    const result = this.getTxStatus();
        if((this.state.stackId!==null)&&(result==='success')) {
            console.log("Accumulator with id '"+this.state.accId+"' issues : "+result)
        } else if (result==='error') {
            console.log("ERROR: IssueNonrevocation, transaction error")
        }
    const { user, showRegistrationForm, formIncomplite, credentialTransfered } = this.props;
    return (
      <div>
        {this.renderIssueButtons(this.props)}
        {this.renderHelpMessage(user, showRegistrationForm, formIncomplite)}
        {this.renderCredentialTransferResult(credentialTransfered)}
      </div>
    )
  }
}

export default connect(
  (state, props) => {
    const { user, name, birth, address, showRegistrationForm, credentialTransfered } = state.appReducer;
    const formIncomplite = isEmpty(name) || isEmpty(birth) || isEmpty(address);
    return {
      uport: state.appReducer.uport,
      accumulator : state.appReducer.accumulator,
      credentialList : state.appReducer.credentialList,
      user: user,
      showRegistrationForm: showRegistrationForm,
      formIncomplite: formIncomplite,
      name: name,
      birth: birth,
      address: address,
      credentialTransfered: credentialTransfered,
      state
    }
  },
  (dispatch) => {
    return {
      addNewCredential: (list) => dispatch({type: 'ADD_NEW_CREDENTIAL', value: list}),
    }
  }
)(IssueCredential)
