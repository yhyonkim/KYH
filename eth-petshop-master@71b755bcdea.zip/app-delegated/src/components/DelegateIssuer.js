import React from "react";
import { connect } from 'react-redux';
import { hasValue } from '../utilities/utils';

class DelegateIssuer extends React.Component {
    render() {
        const { transactionStackIndex, delegateQualification, targetId, qualificationPeriod, state, drizzle, uport } = this.props;
        const { transactions, transactionStack } = this.props.state;
        const txId = transactionStack[transactionStackIndex];
        return (
            <div>
                <button className="btn btn-default btn-adopt" onClick={() => delegateQualification(targetId, qualificationPeriod, 'Birthdate Credential', drizzle, uport, state)}>
                    자격 위임
                </button>
                <br /><br />
                {(() => {
                    if (hasValue(transactions[txId])) {
                        return <div><pre>{JSON.stringify(transactions[txId], null, 2)}</pre></div>
                    }
                })()}
            </div>
        )
    }
}

export default connect(
    (state, props) => (
    {
        transactions: state.transactions,
        transactionStack: state.transactionStack,
        targetId: state.appReducer.targetId,
        qualificationPeriod: state.appReducer.qualificationPeriod,
        uport: state.appReducer.uport,
        state: state,
        transactionStackIndex: state.appReducer.txStackIndex,
        schemaJsonCorrect: state.appReducer.schemaJsonCorrect,
    }),
    (dispatch) => ({
        delegateQualification: (targetId, period, qualType, drizzle, uport, state) => dispatch({ type: 'DELEGATE_QUALIFICATION_REQUEST'
            , request: {
                targetId: targetId,
                period: period,
                drizzle: drizzle,
                uport: uport,
                qualType: qualType,
                state: state
            } 
        }),
        onRegisterSchemaRequested: (txStackIndex) => dispatch({ type: 'REGISTER_SCHEMA_REQUESTED'
        , txStackIndex: txStackIndex}),
    })
)(DelegateIssuer);
