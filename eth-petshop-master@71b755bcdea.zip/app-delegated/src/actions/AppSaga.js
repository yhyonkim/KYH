import { takeLatest, takeEvery, select, call, put } from "redux-saga/effects";
import requestDisclosure from '../functions/requestDisclosure';
import { issueCredentialSchema } from '../functions/issueCredential';
import delegateQualification from '../functions/delegateQualification';
import sendSchemaID from '../functions/sendSchemaID'
import { revokeCredential, cancelRevocation } from '../functions/revokeCredential';
import { setEthAddress, getEthAddress, registerDID } from "../utilities/registryCaller";

function* connectUportSaga(action) {
    try {
        yield put({ type: 'CONNECT_UPORT_BEGIN' });
        const response = yield call(requestDisclosure, ['ConnectRequest', action.request]);
        yield put({ type: 'CONNECT_UPORT_SUCCESS', user:response.payload });
    } catch (error) {
        yield put({ type: 'CONNECT_UPORT_FAILED', error });
    }
}

function* disconnectUportSaga(action) {
    try {
        yield put({ type: 'DISCONNECT_UPORT_BEGIN' });
        const response = yield call(requestDisclosure, ['DisconnectRequest', action.request]);
        yield put({ type: 'DISCONNECT_UPORT_SUCCESS' });
    } catch (error) {
        yield put({ type: 'DISCONNECT_UPORT_FAILED', error });
    }
}

function* sendSchemaIDSaga(action) {
    try {
        const state = yield select();
        const keyPair = state.appReducer.keyPair;
        const result = yield call(sendSchemaID, [action.schemaID, keyPair]);
        const userSignature = result.userSignature;
        const userInfo = result.userInfo;
        const validity = result.validity;
        yield put({ type: 'SET_ORIG_USERINFO', origUserInfo: userInfo});
        yield put({ type: 'SET_INPUT_VALUE', value: userInfo, validity });
        yield put({ type: 'GOT_SCHEMA' });
        yield put({ type: 'SET_USER_SIGNATURE', userSignature: userSignature });
    } catch (error) {
        yield put({ type: 'SEND_SCHEMA_ID_FAILED', error });
    }
}
function* registerSchemaSaga(action) {
    try {
        yield put({ type: 'REGISTER_SCHEMA_SUCCESS', value: 'abc'})
    } catch (error) {
        yield put({ type: 'REGISTER_SCHEMA_FAILED'})
    }
}

function* issueCredentialSchemaRequestSaga(action) {
    try {
        const result = yield call(issueCredentialSchema, [action.props, action.state, action.accV])
        yield put({ type: 'ISSUE_CREDENTIAL_SCHEMA_SUCCESS',  credentialTransfered: result});
    } catch (error) {
        yield put({ type: 'ISSUE_CREDENTIAL_SCHEMA_FAILED', error })
    }
}

function* delegateQualificationRequestSaga(action) {
    try {
        const result = yield call(delegateQualification, action.request);
        yield put({ type: 'DELEGATE_QUALIFICATION_SUCCESS', result: result });
    } catch (error) {
        yield put({ type: 'DELEGATE_QUALIFICATION_FAILED', error });
    }
}

function* revokeCredentialSaga(action){
    try{
        yield call(revokeCredential, action.props);
    } catch (error) {
        console.error(error);
    }
}

function* cancelRevocationSaga(action){
    try{
        yield call(cancelRevocation, action.props);
    } catch (error) {
        console.error(error);
    }
}

function* registerDIDSaga(action) {
    yield call(setEthAddress, action.didAddrPair[0], action.didAddrPair[1], action.privateKey);
    const ethAddr = yield call(getEthAddress, action.didAddrPair[0]);
    yield call(registerDID, ethAddr, action.publicKey, action.privateKey);
}

export default function* appSaga() {
    yield takeEvery('REGISTER_SCHEMA_REQUEST', registerSchemaSaga);
    yield takeLatest('CONNECT_UPORT_REQUEST', connectUportSaga);
    yield takeLatest('DISCONNECT_UPORT_REQUEST', disconnectUportSaga);
    yield takeLatest('ISSUE_CREDENTIAL_SCHEMA_REQUEST', issueCredentialSchemaRequestSaga);
    yield takeLatest('DELEGATE_QUALIFICATION_REQUEST', delegateQualificationRequestSaga);
    yield takeLatest('SEND_SCHEMA_ID', sendSchemaIDSaga);
    yield takeLatest('REVOKE_CREDENTIAL', revokeCredentialSaga);
    yield takeLatest('CANCEL_REVOKE_CREDENTIAL', cancelRevocationSaga);
    yield takeLatest('REGISTER_DID', registerDIDSaga);
}