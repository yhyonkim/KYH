import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import { Drizzle } from 'drizzle';
import App from './App';
import * as serviceWorker from './serviceWorker';
import Schema from './contracts/Schema.json';
import Revocation from './contracts/Revocation.json';
import DIDRegister from "./contracts/EthereumDIDRegistry.json";
import { uportConnect } from "./utilities/uportSetup";
import appReducer from './actions/AppReducer';
import appSaga from './actions/AppSaga';

console.log("GOV DID:", uportConnect.state.keypair.did)
const options = {
	contracts: [Schema, Revocation, DIDRegister],
	web3: {
		customProvider: uportConnect.getProvider(),
		fallback: {
			type: "ws",
			url: process.env.REACT_APP_QUORUM_WS_URL
		}
	},
	appReducers: { appReducer },
	appSagas: [ appSaga ],
	disableReduxDevTools: false
};

const drizzle = new Drizzle(options);

ReactDOM.render(
	<BrowserRouter>
		<Provider store={drizzle.store}>
			<App drizzle={drizzle}/>
		</Provider>
	</BrowserRouter>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
