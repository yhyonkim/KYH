const util = require('util');
const utils = require('./lib/utils');
const bullet = require('./lib/bullet_proof_specific_range');

const controller = (x, a, bound) => {

    const numOfBits = Math.log2(bound);
    const ceilBits = Math.ceil(numOfBits);
    const padSize = Math.pow(2,ceilBits) - bound;
  
    if(bound>256){console.log("error: upper bound should be <256bits");return;}
    if(padSize>0){console.log("error: range works only for powers of 2 for now");return;}


    const x1 = utils.turnToBig(x)
    const start= utils.turnToBig(a)
    const r0 = utils.pickRandom(utils.q)
    const r1 = utils.pickRandom(utils.q)
    const r2 = utils.pickRandom(utils.q,r0)
    const r3 = utils.pickRandom(utils.q,r1)

    const difference=x1.subtract(start);
    
    const r1_diff=r2.subtract(r0); // all
    const r2_diff=r3.subtract(r1);
    var {A,S,T1,T2,tauX,miu,tX,L,R,aTag,bTag} = bullet.rangeBpProver(difference,r1_diff,r2_diff, bound);

    // prover proves that they have x1
    const pedCom1 =utils.ec.g.mul(x1.toString(utils.HEX)).add(utils.ec.g.mul((r2.multiply(r3)).toString(utils.HEX)));

    const gstarA=utils.ec.g.mul(start.toString(utils.HEX));
    const negGstarA=gstarA.neg(gstarA);
    const gr0tor1=utils.ec.g.mul((r0.multiply(r1)).toString(utils.HEX));
    const gr2tor1=utils.ec.g.mul((r2.multiply(r1)).toString(utils.HEX));
    const gr0tor3=utils.ec.g.mul((r0.multiply(r3).toString(utils.HEX)))
    const sum_gr2tor1=gr2tor1.add(gr0tor3);
    const neg_sum_gr2tor1=sum_gr2tor1.neg(sum_gr2tor1)
    const finalpedCom=pedCom1.add(negGstarA).add(gr0tor1).add(neg_sum_gr2tor1)
    
    const result10 = bullet.rangeBpVerifier(r1_diff,finalpedCom,A,S,T1,T2,tauX,miu,tX,L,R,aTag,bTag, bound);

    return result10;
  }

  module.exports = {
    controller,
  };
