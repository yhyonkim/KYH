const util = require('util');
const utils = require('./lib/utils');
const {Prover} = require('./lib/bullet_proof_range_prov');
const {Verifier} = require('./lib/bullet_proof_range_verif');

function controller(x, a, bound){

    const numOfBits = Math.log2(bound);
    const ceilBits = Math.ceil(numOfBits);
    const padSize = Math.pow(2,ceilBits) - bound;
  
    if(bound>256){console.log("error: upper bound should be <256bits");return;}
    if(padSize>0){console.log("error: range works only for powers of 2 for now");return;}


    const x1 = utils.turnToBig(x)
    const start= utils.turnToBig(a)
    
    const r0 = utils.pickRandom(utils.q)
    const r1 = utils.pickRandom(utils.q)
    const r2 = utils.pickRandom(utils.q,r0)
    const r3 = utils.pickRandom(utils.q,r1)
        // prover proves that they have x1
    const pedCom1 =utils.ec.g.mul(x1.toString(utils.HEX)).add(utils.ec.g.mul((r2.multiply(r3)).toString(utils.HEX)));
    //verifier would take the original commitment and calulate random diiference and new commitment based on above formula
    const r1_diff=r2.subtract(r0); //3
    const r2_diff=r3.subtract(r1); //1

    //2
    const gstarA=utils.ec.g.mul(start.toString(utils.HEX));
    const negGstarA=gstarA.neg(gstarA);
    const gr0tor1=utils.ec.g.mul((r0.multiply(r1)).toString(utils.HEX));
    const gr2tor1=utils.ec.g.mul((r2.multiply(r1)).toString(utils.HEX));
    const gr0tor3=utils.ec.g.mul((r0.multiply(r3).toString(utils.HEX)))
    const sum_gr2tor1=gr2tor1.add(gr0tor3);
    const neg_sum_gr2tor1=sum_gr2tor1.neg(sum_gr2tor1)
    const finalpedCom=pedCom1.add(negGstarA).add(gr0tor1).add(neg_sum_gr2tor1)

    const prover = new Prover(x,a, r1_diff, r2_diff, bound);
    const verifier = new Verifier(r1_diff, bound);

    var {A,S} = prover.rangeBpProver1();
    //console.log("\nP -> V : A, S")
    //console.log(A)
    //console.log(S)
    var {y,z} = verifier.rangeBpVerifier2(A,S);
    // console.log("\nV -> P : y, z")
    // console.log(y) // value
    // console.log(z) // value
    var {T1, T2} = prover.rangeBpProver3(y,z);
    // console.log("\nP -> V : T1, T2")
    // console.log(T1)
    // console.log(T2)
    var xtest = verifier.rangeBpVerifier4(T1, T2);
    // console.log("\nV -> P : xtest")
    // console.log(xtest) // value
    var {tauX,miu,tX,L,R,aTag,bTag} = prover.rangeBpProver5(xtest);
    // console.log("\nP -> V : tauX, miu, tX, L, R")
    // console.log(tauX) // value
    // console.log(miu) // value
    // console.log(tX)
    // console.log(L)
    // console.log(R)
    const result = verifier.rangeBpVerifier6(finalpedCom,A,S,T1,T2,tauX,miu,tX,L,R,aTag,bTag);
    // console.log("\nV -> P : result")

    //first proof to prove that a<=x
    //var {A,S,T1,T2,tauX,miu,tX,L,R,aTag,bTag} = bullet.rangeBpProver(difference,r1_diff,r2_diff, bound);
    //const result = bullet.rangeBpVerifier(r1_diff,finalpedCom,A,S,T1,T2,tauX,miu,tX,L,R,aTag,bTag, bound);
    //console.log(a+" <= "+x+" < "+a+"+2^"+bound+" : "+result);

    return result;
  }

  module.exports = {
    controller,
  };
