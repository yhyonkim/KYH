const should = require('should');

const controller1 = require('../largerthan-aio').controller;
const controller2 = require('../largerthan-sep').controller;
const controllers = {
    "allInOne": controller1, 
    "actorSeperated": controller2
};

describe('bulletproof', function(){
    for (key in controllers) {
        let controller = controllers[key];
        describe(`controller ${key}`,function(){

            const boundNumBit = 8; // 2^8=256 이되어 256살까지를 검사하게 됨.

            it('will return false when input is under 0',function(){
                controller(-1, 19,boundNumBit)
                    .should.be.false();
            });

            it('will return false when input is 0',function(){
                controller(0, 19,boundNumBit)
                    .should.be.false();
            });

            it('will return false when input is under 19',function(){
                controller(18, 19,boundNumBit)
                    .should.be.false();
            });

            it('will return true when input is 19',function(){
                controller(19, 19,boundNumBit)
                    .should.be.true();
            });

            it('will return true when input is over 19',function(){
                controller(20, 19,boundNumBit)
                    .should.be.true();
            });

            it('will return true over 256 (2^8)',function(){
                controller(256, 19,boundNumBit)
                    .should.be.true();
            });

            it('will return true over 257 > (2^8)',function(){
                controller(257, 19,boundNumBit)
                    .should.be.true();
            });
        });
    };
});