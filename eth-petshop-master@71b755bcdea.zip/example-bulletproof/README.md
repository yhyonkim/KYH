# 테스트 방법
```
$ npm install
$ npm test
> bp1@0.0.0 test /Users/soominlee/D/ssi/uport/eth-petshop-diane/lib-bulletproof
> mocha

  largerthan
    ✓ will return false when input is under 0 (409ms)
    ✓ will return false when input is 0 (289ms)
    ✓ will return false when input is under 19 (286ms)
    ✓ will return true when input is 19 (284ms)
    ✓ will return true when input is over 19 (294ms)
    ✓ will return true over 256 (2^8) (283ms)
    ✓ will return true over 257 > (2^8) (312ms)

  largerthan_sep
...
```
