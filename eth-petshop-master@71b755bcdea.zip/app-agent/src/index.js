import React from 'react';
import { Drizzle } from 'drizzle';
import ReactDOM from 'react-dom';
import './index.css';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import App from './App';
import * as serviceWorker from './serviceWorker';
import options from './drizzleOptions';

const key = {
    keypair: {
      did: process.env.REACT_APP_DID,
      privateKey: process.env.REACT_APP_PRIVATE_KEY
    }
  }
localStorage.setItem('connectState', JSON.stringify(JSON.stringify(key)));

const drizzle = new Drizzle(options);

ReactDOM.render(
    <BrowserRouter>
        <Provider store={drizzle.store}>
            <App drizzle={drizzle}/>
        </Provider>
    </BrowserRouter>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
