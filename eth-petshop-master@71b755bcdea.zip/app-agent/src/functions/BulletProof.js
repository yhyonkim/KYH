import Prover from '../libs/bullet_proof_range_prov';
import { select } from 'redux-saga/effects';

const EC = require('elliptic').ec;
const ec = new EC('secp256k1');
const utils = require('../libs/utils');
const BigInt = require("big-integer");

var prover = null;

export function* startBulletProofProcess(myAge, revokeInfo, req, socket) {
    console.log("startBulletProofProcess args: ", myAge, req, socket);
    const x = Number(myAge);
    const a = req.token.startAge;
    const bound = req.token.bound;
    const numOfBits = Math.log2(bound);
    const ceilBits = Math.ceil(numOfBits);
    const padSize = Math.pow(2,ceilBits) - bound;
  
    if (bound > 256) {
        console.log("error: upper bound should be <256bits");
        return;
    }
    if (padSize > 0) {
        console.log("error: range works only for powers of 2 for now");
        return;
    }

    const x1 = utils.turnToBig(x);
    
    const r0 = utils.pickRandom(utils.q);
    const r1 = utils.pickRandom(utils.q);
    const r2 = utils.pickRandom(utils.q,r0);
    const r3 = utils.pickRandom(utils.q,r1);

    //verifier would take the original commitment and calulate random diiference and new commitment based on above formula
    const r1_diff=r2.subtract(r0); //3
    const r2_diff=r3.subtract(r1); //1

    prover = new Prover(x,a, r1_diff, r2_diff, bound);
    var {A,S} = prover.rangeBpProver1();

    // 원격 전송을 위해 Point 객체를 serialize 하는 법.
    // ex)
    // const serializedA = JSON.stringify(A.toJSON());
    // const decodedA = ec.curve.pointFromJSON(serializedA, false);
    const serializedA = JSON.stringify(A.toJSON());
    const serializedS = JSON.stringify(S.toJSON());
    const state = yield select();
    state.appReducer.socket.emit('bulletProof', { 
        from: req.aud,
        to: req.iss, 
        type: 'proof1', 
        payload: {
            revokeInfo: revokeInfo,
            A: serializedA,
            S: serializedS,
            r1_diff: r1_diff,
            x1: x1,
            r0: r0,
            r1: r1,
            r2: r2,
            r3: r3
        }
    });
}

export function* bulletProof(data, socket) {
    if (data.type === 'proof1') {
        console.log("bulletProof proof1 data: ", data);

        const y = new BigInt(data.payload.y.replace(/"/g,""));
        const z = new BigInt(data.payload.z.replace(/"/g,""));
        
        var {T1, T2} = prover.rangeBpProver3(y,z);
        
        const serializedT1 = JSON.stringify(T1.toJSON());
        const serializedT2 = JSON.stringify(T2.toJSON());
    
        socket.emit('bulletProof', { 
            from: data.to,
            to: data.from, 
            type: 'proof2', 
            payload: {
                T1: serializedT1,
                T2: serializedT2
            }
        });
    } else if (data.type === 'proof2') {
        console.log("bulletProof proof2 data: ", data);

        const xtest = new BigInt(data.payload.xtest.replace(/"/g,""));

        var {tauX,miu,tX,L,R,aTag,bTag} = prover.rangeBpProver5(xtest);

        const serializedL = [];
        for (let i = 0; i < L.length; i++) {
            serializedL.push(JSON.stringify(L[i]));
        }

        const serializedR = [];
        for (let i = 0; i < R.length; i++) {
            serializedR.push(JSON.stringify(R[i]));
        }
        socket.emit('bulletProof', { 
            from: data.to,
            to: data.from, 
            type: 'proof3', 
            payload: {
                tauX: tauX,
                miu: miu,
                tX: tX,
                L: serializedL,
                R: serializedR,
                aTag: aTag,
                bTag: bTag,
            }
        });
    }
}