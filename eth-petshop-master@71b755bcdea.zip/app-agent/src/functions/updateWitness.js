// import { Credentials } from 'uport-credentials'

// const Time30Days = () => Math.floor(new Date().getTime()) + 30 * 24 * 60 * 60 * 1000;

export function updateWitness(revinfo, contract) {
    return new Promise((resolve, reject) => {
        contract.methods.getNonrevidx(revinfo.accId).call({from:''})
            .then(r => {
                let result = calculateWitness(r, revinfo, contract);
                resolve(result)
            }).catch(e => console.log(e));
    });
}

async function calculateWitness(r, revinfo, contract) {
    let idxDiv = revinfo.accV;
    let idxMul = [revinfo.accIndex];
    let myId = revinfo.accIndex;
    let store = [];
    idxDiv.forEach(idx => store.push(idx))
    
    r.forEach(idx => {
        if(idx==="0") return;
        if(idx==myId) return;
        let exist = idxDiv.indexOf(idx);
        if(exist<0) idxMul.push(idx);
        else {
            idxDiv.splice(exist, 1);
        }
    })

    let mul = await updateIdx(idxMul, contract, revinfo.accId);
    let div = await updateIdx(idxDiv, contract, revinfo.accId);

    let witness = revinfo.accWit;
    witness = witness*mul/div;

    revinfo.accV = store;

    return witness

    // const verf = {
    //     sub: process.env.REACT_APP_AGENT_DID,
    //     exp: Time30Days(),
    //     claim: {witness:witness},
    //     vc: []
    // };

    // const credential = new Credentials({
    //     privateKey: process.env.REACT_APP_AGENT_PRIVATE_KEY,
    // });

    // return new Promise((resolve, reject) => {
    //     credential.createVerification(verf).then(jwt => {
    //         resolve(jwt)
    //     })
    // });
}

async function updateIdx(indexes, contract, id) {
    let result = 1;
    await asyncForEach(indexes, async (idx) => {
        if(idx==="0") return;
        let r = await contract.methods.getTails(id, idx).call({from:''})
        result = r*result;
    })
    return result;
}

async function asyncForEach(array, callback) {
    for (let index = 0; index < array.length; index++) {
      await callback(array[index], index, array);
    }
}
