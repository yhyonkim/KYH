
import Schema from './contracts/Schema.json';
import Revocation from './contracts/Revocation.json';
import DIDRegister from "./contracts/EthereumDIDRegistry.json";
import appReducer from './actions/AppReducer.js';
import appSaga from './actions/AppSaga';

const options = {
	contracts: [Schema, Revocation, DIDRegister],
	web3: {
		fallback: {
			type: "ws",
			url: process.env.REACT_APP_QUORUM_WS_URL
		}
	},
	appReducers: { appReducer },
	appSagas: [ appSaga ],
	disableReduxDevTools: false
};

export default options;