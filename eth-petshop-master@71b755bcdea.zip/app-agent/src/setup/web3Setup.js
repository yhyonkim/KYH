import Web3 from 'web3';

const web3 = new Web3();
web3.setProvider(new Web3.providers.WebsocketProvider(process.env.REACT_APP_QUORUM_WS_URL));

export default web3
