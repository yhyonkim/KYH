import { notification } from 'antd';

export function hasValue(v) {
    return !isEmpty(v);
}

export function isEmpty(v) {
    return typeof v === "undefined" || v === null;
}

export function isTrue(v) {
    return hasValue(v) && v === true;
}

export function isFalse(v) {
    return !isTrue(v);
}

export function isNonZero(v) {
    return hasValue(v) && (typeof v == 'number') && v !== 0;
}

export function hexStringToBytes(str) {
    let bytes = str.replace(/^0x/gi, '');
    return Buffer.from(bytes, 'hex');
} 

export function stringToBytes32(str) {
const buffstr =
    '0x' +
    Buffer.from(str)
    .slice(0, 32)
    .toString('hex')
    return buffstr + '0'.repeat(66 - buffstr.length)
}

export function notify(type, message, description) {
    // type = success, info, warning, error
    notification[type]({
        message: message,
        description: description
    });
};