import { Connect } from 'uport-connect';
import DIDRegistryContract from "../contracts/EthereumDIDRegistry.json";
import Web3 from 'web3'

const networkAddress = Object.keys(DIDRegistryContract.networks)[0];
if (!networkAddress) console.error("Network not configured in JSON", DIDRegistryContract.networks);
const didRegistryContractAddress = DIDRegistryContract.networks[networkAddress].address;

// Key를 .env 파일에서 읽어올수있음
const key = {
  keypair: {
    did: process.env.REACT_APP_DID,
    privateKey: process.env.REACT_APP_PRIVATE_KEY
  }
}
localStorage.setItem('connectState', JSON.stringify(JSON.stringify(key)));
console.log("REACT_APP_QUORUM_RPC_URL: ", process.env.REACT_APP_QUORUM_RPC_URL);
const uportConnect = new Connect('uPort Government', {
  //  network: 'rinkeby',
  network: {
    id: process.env.REACT_APP_QUORUM_NET_ID,
    registry: didRegistryContractAddress,
    rpcUrl: process.env.REACT_APP_QUORUM_RPC_URL
  },
  accountType: 'keypair',
  profileImage: { "/": "/ipfs/Qmez4bdFmxPknbAoGzHmpjpLjQFChq39h5UMPGiwUHgt8f" },
  bannerImage: { "/": "/ipfs/QmUA7P9tTx3eQQi7k6VfGMADmDDyvG6xdn5P4yXxcMJs7a" },
  description: "uPort Government description",
  vc: [],
  ethrConfig: {
    rpcUrl: process.env.REACT_APP_QUORUM_RPC_URL,
    registry: didRegistryContractAddress,
  },
})

const web3 = new Web3(uportConnect.getProvider());
console.log("web3: ", web3);
const didRegistryContractAbi = DIDRegistryContract.abi;
const didRegistryContract = new web3.eth.Contract(didRegistryContractAbi, didRegistryContractAddress);

export { uportConnect, web3, didRegistryContract, didRegistryContractAddress }
