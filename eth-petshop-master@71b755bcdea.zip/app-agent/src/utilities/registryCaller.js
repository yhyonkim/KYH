import { didRegistryContract, didRegistryContractAddress, web3 } from "./uportSetup";
import registerResolver, {stringToBytes32} from 'ethr-did-resolver';
import didResolver from 'did-resolver';

export async function getEthAddress (did) {
    return new Promise(async resolve => {
        const sendingData = didRegistryContract.methods.getEthAddress(
            stringToBytes32(did)
        ).encodeABI();
    
        const tx = {
            to: didRegistryContractAddress,
            data: sendingData,
            gas: 100000000,
            gasLimit: 100000000,
        }
    
        const ethAddress = await web3.eth.call(tx);
        resolve('0x' + ethAddress.substring(26));
    });
}

export async function setEthAddress (did, address, privateKey) {
    return new Promise(async (resolve, reject) => {
        const sendingData = didRegistryContract.methods.setEthAddress(
            stringToBytes32(did), // did
            address  // address
        ).encodeABI();

        // define tx information
        const tx = {
            to: didRegistryContractAddress,
            data: sendingData,
            gas: 100000000,
            gasLimit: 100000000,
        }
    
        try {
            // sign transaction
            web3.eth.accounts.signTransaction(tx, privateKey, (err, signed) => {
                if (err) console.log("RegisterDID signTransaction err: ", err);
                else {
                    // send signed transaction
                    web3.eth.sendSignedTransaction(signed.rawTransaction, (err, res) => {
                        if (err) console.log("RegisterDID sendSignedTransaction err: ", err);
                    }).on('receipt', receipt => { // listening 'receipt' message
                        resolve(receipt);
                    });
                }
            });
        } catch (error) {
            console.error("RegisterDID setAttribute error: ", error);
            reject(error);
        }
    });
}

export async function registerDID (identity, publicKey, privateKey) {
    return new Promise(async (resolve, reject) => {
        var sendingData = didRegistryContract.methods.setAttribute(
            identity, // identity
            stringToBytes32('did/pub/Secp256k1/veriKey123'),    // name
            publicKey, // value
            1000000 // validity
        ).encodeABI();
    
        try {
            // define tx information
            var tx = {
                to: didRegistryContractAddress,
                data: sendingData,
                gas: 100000000,
                gasLimit: 100000000,
            }
    
            // sign transaction
            web3.eth.accounts.signTransaction(tx, privateKey, (err, signed) => {
                if (err) console.log("RegisterDID signTransaction err: ", err);
                else {
                    // send signed transaction
                    web3.eth.sendSignedTransaction(signed.rawTransaction, (err, res) => {
                        if (err) console.log("RegisterDID sendSignedTransaction err: ", err);
                    }).on('receipt', receipt => { // listening 'receipt' message
                        resolve(receipt);
                    });
                }
            });
        } catch (error) {
            console.error("RegisterDID setAttribute error: ", error);
            reject(error);
        }
    })
}

export function resolveDID (identity) {
    registerResolver({ provider: web3.currentProvider, registry: didRegistryContractAddress});
    return new Promise(resolve => {
        didResolver("did:ethr:" + identity).then((doc) => {
            resolve(doc);
        })
    })
}

export function getPublicKey(did) {
    registerResolver({ provider: web3.currentProvider, registry: didRegistryContractAddress});
    return new Promise(resolve => {
        getEthAddress(did).then(addr => {
            didResolver("did:ethr:" + addr).then((doc) => {
                if (doc.publicKey[1] && doc.publicKey[1].publicKeyHex)
                    resolve(doc.publicKey[1].publicKeyHex);
                else 
                    resolve(null);
            })
        });
    })
}