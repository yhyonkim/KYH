import { takeLatest, select, call, put } from "redux-saga/effects";
import { decodeJWT, createJWT } from 'did-jwt';
import { Credentials } from 'uport-credentials';
import web3 from "../setup/web3Setup";
import { isMNID, decode } from 'mnid';
import { startBulletProofProcess, bulletProof } from '../functions/BulletProof';
import { updateWitness } from '../functions/updateWitness'
import { setEthAddress, getEthAddress, registerDID } from "../utilities/registryCaller";
import { message } from 'antd';
const bls = require('@chainsafe/bls');
const sha256 = require('js-sha256');

export default function* appSaga() {
    yield takeLatest('ACCEPT_REQUEST', acceptRequestSaga);
    yield takeLatest('DECLINE_REQUEST', declineRequestSaga);
    yield takeLatest('SEND_RESPONSE', sendResponseSaga);
    yield takeLatest('BULLETPROOF', bulletProofSaga);
    yield takeLatest('REGISTER_DID', registerDIDSaga);
}

function* registerDIDSaga(action) {
    yield call(setEthAddress, action.didAddrPair[0], action.didAddrPair[1], action.privateKey);
    const ethAddr = yield call(getEthAddress, action.didAddrPair[0]);
    yield call(registerDID, ethAddr, action.publicKey, action.privateKey);
}

function* bulletProofSaga(action) {
    const data = action.data;
    const socket = action.socket;
    yield call(bulletProof, data, socket);
}

function* sendResponseSaga(){
    const state = yield select();
    const socket = state.appReducer.socket;
    const response = state.appReducer.response;
    const type = state.appReducer.responseType? state.appReducer.responseType : 'response';
    console.log(response, type);
    socket.emit(type, response);
    yield put({type: 'SET_RESPONSE', response: null, responseType: null})
}

function* declineRequestSaga(action) {
    try {
        if (action.req.type === 'schemaID') {
            yield put({ type: 'ADD_HISTORY', obj: {iss: process.env.REACT_APP_AGENT_DID, aud: action.req.iss, type:'OFFER_SCHEMA', result:'DECLINED'}})
        } else if (action.req.type === 'saveReq') {
            yield put({ type: 'ADD_HISTORY', obj: {iss: action.req.iss, aud: process.env.REACT_APP_AGENT_DID, type:'ISSUE_CREDENTIAL', result:'DECLINED'}})
        } else if (action.req.type === "ethtx") {
            yield put({ type: 'ADD_HISTORY', obj: {iss: action.req.iss, aud: process.env.REACT_APP_AGENT_DID, type:'SIGN_TRANSACTION', result:'DECLINED'}})
        } else if (action.req.type === 'schemaID') {
            yield put({ type: 'ADD_HISTORY', obj: {iss: action.req.iss, aud: process.env.REACT_APP_AGENT_DID, type:'SEND_SCHEMAID', result:'DECLINED'}})
        } else {
            yield put({ type: 'ADD_HISTORY', obj: {iss: action.req.iss, aud: process.env.REACT_APP_AGENT_DID, type:'DISCLOSURE_REQ', result:'DECLINED'}})
        }
        yield put({ type: 'DEL_REQUEST', 'key': action.req.key })
    } catch (error) {
        console.error("declineRequestSaga error: ", error);
    }
}


function* acceptRequestSaga(action) {
    try {
        if (action.req.type === 'saveReq') {
            const obj = yield call(saveVerification, action.req);
            yield put({ type: 'ADD_HISTORY', obj: {iss: obj.iss, aud: process.env.REACT_APP_AGENT_DID, type:'ISSUE_CREDENTIAL', result:'APPROVED'}})
            yield put({ type: 'ADD_VC', obj })
        } else if (action.req.type === "ethtx") {
            yield call(signAndSendTransaction, action.req);
        } else if (action.req.type === 'schemaID') {
            yield call(sendSchemaID, action.req, action.socket);
        } else if (action.req.type === 'checkAge') {   
            const state = yield select();
            var age = -1, revokeInfo = null;
            for (var i = 0; i < state.appReducer.vcs.length; i++) {
                if (state.appReducer.vcs[i].claim.hasOwnProperty('Birthdate Credential')) {
                    age = new Date().getFullYear() - state.appReducer.vcs[i].claim['Birthdate Credential'].year;
                    age++;
                    // presentation 기능 부재로 인해 vc안의 내용물을 보냄
                    revokeInfo = state.appReducer.vcs[i].claim['Birthdate Credential'].Revocation;
                    break;
                }
            }
            console.log("state.appReducer: ", state.appReducer);
            yield call(startBulletProofProcess, age, revokeInfo, action.req, action.socket);
        } else {
            // DID Auth
            yield call(handle, action);
        }
        if (action.sendDirect) {
            yield call(sendResponseSaga)
        }
        // yield put({ type: 'DEL_REQUEST', key: action.req.key })
    } catch (error) {
        console.error("acceptRequestSaga error: ", error);
    }
}


function* sendSchemaID(req) {

    try {
        const state = yield select();
        const userInfo = state.appReducer.value;
        const validity = state.appReducer.validity;
        const keyPair = state.appReducer.keyPair;

        const domain = Buffer.alloc(8,0);

        // const userInfo = {year: "1111", month: "05", date: "03"};
        const msghash = Buffer.from(sha256.arrayBuffer(JSON.stringify(userInfo)));

        // To: 이수민 책임님
        // 요청하신 app-agent의 private key 입니다.
        // state는 64번 라인에서 select 한 것으로, 현재 App에 저장되어있는 모든 데이터를 받아옵니다.
        // 그 중 appReducer에 할당된 privateKey 속성값을 가져와 사용 할 수 있습니다.
        // const AppAgentPrivateKey = state.appReducer.privateKey;

        // 사용자가 사용자 정보에 대해 signature 생성
        const signature = bls.default.sign(keyPair.privateKey, msghash, domain);

        // send to petshop
        yield put({ type: 'SET_RESPONSE', response: {iss: req.aud, aud: req.iss, type: 'userInfo', userInfo: userInfo, validity: validity, signature: signature}})
        // socket.emit('response', {iss: req.aud, aud: req.iss, type: 'userInfo', userInfo: userInfo, validity: validity, signature: signature});

        yield put({ type: 'ADD_HISTORY', obj: {iss: process.env.REACT_APP_AGENT_DID, aud: req.iss, type:'SEND_SCHEMAID', result:'APPROVED'}})
    } catch (error) {
        yield put({ type: 'ADD_HISTORY', obj: {iss: process.env.REACT_APP_AGENT_DID, aud: req.iss, type:'SEND_SCHEMAID', result:'ERROR'}})
        console.error("sendSchemaID error: ", error);
    }
}

function* signAndSendTransaction(req) {
    const token = decodeJWT(req.token);
    const payload = token.payload;
    const state = yield select();

    const privateKey = process.env.REACT_APP_AGENT_PRIVATE_KEY;
    try {
        const decoded = isMNID(payload.to) ? decode(payload.to) : undefined
        var tx = {
            to: decoded.address,
            data: payload.data,
            gas: 1000000,
            gasLimit: 1000000,
        }

        if (token.payload.value) {
            tx.value = token.payload.value;
        }
        
        const signed = yield web3.eth.accounts.signTransaction(tx, privateKey)
        yield web3.eth.sendSignedTransaction(signed.rawTransaction)
        .on('receipt', receipt => {
            put({ type: 'SET_RESPONSE', response: { aud: payload.iss, type: 'signTx', tx: receipt }});
            state.appReducer.socket.emit('response', { aud: payload.iss, type: 'signTx', tx: receipt });
        })
        yield put({ type: 'ADD_HISTORY', obj: {iss: payload.iss, aud: process.env.REACT_APP_AGENT_DID, type:'SIGN_TRANSACTION', result:'APPROVED'}})
        message.success('Successfully Adopted');
    } catch (error) {
        yield put({ type: 'ADD_HISTORY', obj: {iss: payload.iss, aud: process.env.REACT_APP_AGENT_DID, type:'SIGN_TRANSACTION', result:'ERROR'}})
        message.error('Insufficient funds');
        console.error("signTransaction error: ", error);
    }
}

function saveVerification(req) {
    const jwt = req.token
    const token = decodeJWT(jwt);
    var payload = token.payload;
    payload.jwt = jwt;
    
    message.success('Credential was saved successfully!');
    return payload;
}

function* handle(action) {
    const req = action.req;
    const jwt = req.token;
    const token = decodeJWT(jwt);
    const payload = token.payload;
    const contract = action.contracts.Revocation;
    console.log("handle action:", action);

    // logic from uport-mobile/saga/discloseRequest
    const request = yield call(handleRequest, payload, jwt);
    const response = yield call(createResponse, request, contract);

    let verified = [];
    response.verified && response.verified.forEach(v => {
        Object.keys(decodeJWT(v).payload.claim).forEach(k => verified.push(k));
    })

    const credential = new Credentials({
        privateKey: process.env.REACT_APP_AGENT_PRIVATE_KEY,
    })
    const expiresIn = 600;
    let tmp;
    yield createJWT(response, {
        issuer: credential.did,
        signer: credential.signer,
        //alg: credential.did.match('^did:uport:') || this.isMNID(credential.did) ? 'ES256K' : 'ES256K-R',
        alg: 'ES256K-R', // 이 데모 프로그램에서는 리거시 uport did 나 MNID 주소를 사용하지 않아 알고리즘을 고정함.
        expiresIn,
    }).then(jwt => {
        tmp = jwt;
        // action.socket.emit('response', { iss: req.aud, aud: req.iss, payload: jwt, walletPublickKey: req.walletPublickKey });
    })
    yield put({ type: 'SET_RESPONSE', response: { iss: req.aud, aud: req.iss, payload: tmp, walletPublickKey: req.walletPublickKey }});
        
    
    if (request.requested.includes('disconnect')) {
        yield put({ type: 'ADD_HISTORY', obj: {iss: req.iss, aud: process.env.REACT_APP_AGENT_DID, type:'DISCONNECT_REQ', result:'APPROVED'}})
        yield put({ type: 'END_SESSION', iss: req.iss})

        message.info(`${req.iss} disconnected`);
        return;
    }

    if (response.verified && response.verified.length > 0){
        yield put({ type: 'ADD_HISTORY', obj: {iss: req.iss, aud: process.env.REACT_APP_AGENT_DID, type:'SHARE_REQ', result:'APPROVED'}})
        yield put({ type: 'ADD_SESSION', obj: {iss: req.iss, type:'SHARE_REQ', verified: verified, requested: request.requested, sharing: Object.keys(response.own), status:'Live'}})
    }
    yield put({ type: 'ADD_HISTORY', obj: {iss: req.iss, aud: process.env.REACT_APP_AGENT_DID, type:'DISCLOSURE_REQ', result:'APPROVED'}})
    yield put({ type: 'ADD_SESSION', obj: {iss: req.iss, type:'DISCLOSURE_REQ', requested: request.requested, sharing: Object.keys(response.own), status:'Live'}})

    message.success(`${req.iss} connected`);
}

function* createResponse(request, contract) {
    const state = yield select();
    try {
        const payload = { aud: request.client_id || request.callback_url, type: 'shareResp' }
        if (request.nad) payload.nad = request.nad
        if (request.dad) payload.dad = request.dad

        if (request.requested) {
            // The self signed claims requested from a user.
            // eg. {"name":"Carol Crypteau", "email":"carol@sample.com"}
            // const own = yield select(requestedClaims, request.requested)
            const own = { "name": state.appReducer.name, "address": state.accounts }
            payload.own = own
            if (request.req) payload.req = request.req
            if (request.verified) {
                if (request.verified.length > 0) {
                    let requestverified = request.verified;
                    payload.verified = [];
                    for(let idx = 0; idx<requestverified.length; idx++) {
                        let verified = requestverified[idx]
                        const { vcs } = state.appReducer;
                        var result = null;
                        if (vcs != null && vcs.length > 0) {
                            vcs.forEach((vc) => {
                                const key = Object.keys(vc.claim)[0].trim();
                                if (key === verified) {
                                    result = vc;
                                }
                            })
                        }
                        if (result != null) {
                            // payload.verified.push(result.jwt);
                            if(result.claim[verified].Revocation != null && contract != null) {
                                const jwt = yield call (createVerified, result, verified, state.appReducer.keyPair, contract);
                                payload.verified.push(jwt);
                            } else {
                                payload.verified.push(result.jwt);
                            }
                        }
                    }
                }
            }
            if (request.challenge) payload.challenge = request.challenge
        }
        return payload;
    } catch (error) {
        console.error("createResponse error: ", error);
        console.log(error);
    }
}

async function createVerified(cred, verified, keypair, contract) {
    const revInfo = cred.claim[verified].Revocation
    let witness = await updateWitness(revInfo, contract)

    let claim = {}
    claim[verified] = {}
    claim[verified][verified] = cred
    claim[verified]['NonRevocationInfo'] = {
        accId : revInfo.accId,
        accIndex : revInfo.accIndex,
        witness : witness
    }
    claim[verified]["aggregatedSignature"] = createAggSig(claim[verified], cred.claim[verified].aggregatedSig, keypair)

    const Time30Days = () => Math.floor(new Date().getTime()) + 30 * 24 * 60 * 60 * 1000;
    const verf = {
        sub: process.env.REACT_APP_AGENT_DID,
        exp: Time30Days(),
        claim: claim,
        vc: []
    };

    const credential = new Credentials({
        privateKey: process.env.REACT_APP_AGENT_PRIVATE_KEY,
    });

    let result = await credential.createVerification(verf)

    return result
}

function createAggSig(message, sig, keypair) {
    const domain = Buffer.alloc(8, 0)
    const msghash = Buffer.from(sha256.arrayBuffer(JSON.stringify(message)))
    const issuersig = Buffer.from(sig, 'hex');

    const holdersig = bls.default.sign(keypair.privateKey, msghash, domain)
    const aggsig = bls.default.aggregateSignatures([issuersig, holdersig]).toString('hex')

    return aggsig
}


function* handleRequest(payload, jwt) {
    const request = {
        validatedSignature: true,
        client_id: payload.iss,
        callback_url: payload.callback,
        verified: payload.verified,
        requested: payload.requested,
        req: jwt,
        actType: payload.act ? payload.act : 'none'
    }
    if (payload.net && payload.rpc) {
        request.rpc = payload.rpc
    }
    return yield request
}
