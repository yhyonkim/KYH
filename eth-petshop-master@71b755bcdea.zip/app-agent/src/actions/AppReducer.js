let initialState = {
    token: null,
    name: "ACE",
    endpoint: process.env.REACT_APP_PROXY_ADDR? process.env.REACT_APP_PROXY_ADDR :"http://127.0.0.1:3030/",
    did: process.env.REACT_APP_DID,
    privateKey: process.env.REACT_APP_PRIVATE_KEY,
    keyPair: localStorage.getItem('keyPair') ? JSON.parse(localStorage.getItem('keyPair')) : null,
    req: localStorage.getItem('req') ? JSON.parse(localStorage.getItem('req')) : null,
    vcs: localStorage.getItem('vcs') ? JSON.parse(localStorage.getItem('vcs')) : null,
    hist: sessionStorage.getItem('hist') ? JSON.parse(sessionStorage.getItem('hist')) : null,
    session: sessionStorage.getItem('session') ? JSON.parse(sessionStorage.getItem('session')) : null,
    value: {},
    validity: {},
}

function union_arrays (x, y) {
    var obj = {};
    for (var i = x.length-1; i >= 0; --i) obj[x[i]] = x[i];
    for (i = y.length-1; i >= 0; --i) obj[y[i]] = y[i];
    var res = [];
    for (var k in obj) {
        if (obj.hasOwnProperty(k)) res.push(obj[k]);
    }
    return res
}

export default (state = initialState, action) => {
    switch (action.type) {
        case 'SET_RESPONSE':
            return { ...state, response: action.response, responseType: action.responseType }
        case 'SET_SOCKET':
            return { ...state, socket: action.socket }
        case 'SOCKET_SEND':
            const socket = state.socket;
            socket.emit('response', action.obj);
            return state;
        case 'ADD_REQUEST':
            var req = state.req ? state.req : [];
            action.obj.key = state.req ? 'key_' + (state.req.length + 1) : 'key_1';
            req.unshift(action.obj);
            localStorage.setItem('req', JSON.stringify(req));
            return { ...state, req }
        case 'DEL_REQUEST':
            req = [];
            state.req.forEach((e, i) => { if (e.key !== action.key) req.push(state.req[i]); })
            if (req.length === 0) {
                localStorage.removeItem('req');
                return { ...state, req: null, }
            } else {
                localStorage.setItem('req', JSON.stringify(req));
                return { ...state, req }
            }
        case 'ADD_VC':
            var vcs = [];
            if (state.vcs) {
                state.vcs.forEach(vc => {
                    // if (Object.keys(vc.claim)[0] !== Object.keys(action.obj.claim)[0]) 
                    vcs.push({...vc, key: 'key_' + (vcs.length+1)});
                })
            }
            action.obj.key = vcs ? 'key_' + (vcs.length + 1) : 'key_1';
            vcs.unshift(action.obj);
            localStorage.setItem('vcs', JSON.stringify(vcs));
            return { ...state, vcs }
        case 'DEL_VC':
            vcs = [];
            console.log(state.vcs);
            state.vcs.forEach((e, i) => { if (e.key !== action.key) vcs.push(state.vcs[i]); })
            if (vcs.length === 0) {
                localStorage.removeItem('vcs');
                return { ...state, vcs: null }
            } else {
                localStorage.setItem('vcs', JSON.stringify(vcs));
                return { ...state, vcs }
            }
        case 'ADD_HISTORY':
            var hist = state.hist ? state.hist : [];
            action.obj.key = state.hist ? 'key_' + (state.hist.length + 1) : 'key_1';
            hist.unshift(action.obj);
            sessionStorage.setItem('hist', JSON.stringify(hist));
            return { ...state, hist }

        case 'DEL_HISTORY':
            hist = [];
            state.hist.forEach((e, i) => { if (e.key !== action.key) hist.push(state.hist[i]); })
            if (hist.length === 0) {
                sessionStorage.removeItem('hist');
                return { ...state, hist: null, }
            } else {
                sessionStorage.setItem('hist', JSON.stringify(hist));
                return { ...state, hist }
            }
        case 'ADD_SESSION':
            var session = state.session ? state.session : [];
            let hasDID = false;
            session.forEach((e, i) => { 
                if (e.iss === action.obj.iss) {
                    hasDID=true
                    if ( session[i].status === 'Live' ) {
                        session[i].requested = union_arrays(session[i].requested, action.obj.requested);
                        session[i].sharing = union_arrays(session[i].sharing, action.obj.sharing);
                        let verified = []
                        action.obj.verified && action.obj.verified.map(v => verified.push('vc_' + v));
                        session[i].sharing = union_arrays(session[i].sharing, verified);
                    } else {
                        session[i].requested = action.obj.requested;
                        session[i].sharing = action.obj.sharing;
                        action.obj.verified && action.obj.verified.map(v => session[i].sharing.push('vc_' + v));
                        console.log(action.obj.verified);
                        session[i].status = 'Live'
                    }
                }
            })
            if (!hasDID) {
                action.obj.key = state.session ? 'key_' + (state.session.length + 1) : 'key_1';
                session.unshift(action.obj);
            }
            sessionStorage.setItem('session', JSON.stringify(session));
            return { ...state, session }
        case 'END_SESSION':
            session = state.session;
            if (!state.session) return { ...state, };
            session.forEach((e, i) => { 
                if (e.iss === action.iss) {
                    session[i].status='Ended'
                }
            })
            sessionStorage.setItem('session', JSON.stringify(session));
            return { ...state, session };
        case 'DEL_SESSION':
            session = [];
            state.session.forEach((e, i) => { if (e.key !== action.key) session.push(state.session[i]); })
            if (session.length === 0) {
                sessionStorage.removeItem('session');
                return { ...state, session: null, }
            } else {
                sessionStorage.setItem('session', JSON.stringify(session));
                return { ...state, session }
            }
        case 'SET_INPUT_VALUE':
            const value = action.value;
            const validity = action.validity;
            return {
                ...state,
                value,
                validity
            }
        case 'SET_KEY_PAIR':
            return {
                ...state,
                keyPair: action.keyPair
            }
        default:
            return state
    }
}