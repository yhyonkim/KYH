import React from 'react';
import { Tree, Transfer } from 'antd';
import { connect } from "react-redux";


const { TreeNode } = Tree;

// Customize Table Transfer
const isChecked = (selectedKeys, eventKey) => {
  return selectedKeys.indexOf(eventKey) !== -1;
};

const generateTree = (treeNodes = [], checkedKeys = []) => {
  return treeNodes.map(({ children, ...props }) => (
    <TreeNode {...props} disabled={checkedKeys.includes(props.key)}>
      {generateTree(children, checkedKeys)}
    </TreeNode>
  ));
};

const TreeTransfer = ({ dataSource, targetKeys, ...restProps }) => {
  const transferDataSource = [];
  function flatten(list = []) {
    list.forEach(item => {
      transferDataSource.push(item);
      flatten(item.children);
    });
  }
  flatten(dataSource);

  return (
    <Transfer
      {...restProps}
      targetKeys={targetKeys}
      dataSource={transferDataSource}
      className="tree-transfer"
      render={item => item.title}
      showSelectAll={false}
    >
      {({ direction, onItemSelect, selectedKeys }) => {
        if (direction === 'left') {
          const checkedKeys = [...selectedKeys, ...targetKeys];
          return (
            <Tree
              blockNode
              checkable
              checkStrictly
              defaultExpandAll
              checkedKeys={checkedKeys}
              onCheck={(
                _,
                {
                  node: {
                    props: { eventKey },
                  },
                },
              ) => {
                onItemSelect(eventKey, !isChecked(checkedKeys, eventKey));
              }}
              onSelect={(
                _,
                {
                  node: {
                    props: { eventKey },
                  },
                },
              ) => {
                onItemSelect(eventKey, !isChecked(checkedKeys, eventKey));
              }}
            >
              {generateTree(dataSource, targetKeys)}
            </Tree>
          );
        }
      }}
    </Transfer>
  );
};

const validAttrSet = ['memberLevel', 'year', 'month', 'day'];

class Treee extends React.Component {
  state = {
    targetKeys: [],
  };

  onChange = targetKeys => {
    console.log('Target Keys:', targetKeys);
    this.setState({ targetKeys });
  };

  renderSource = () => {
    const vcs = this.props.vcs;
    let data = [];
    vcs.forEach(v => {
      console.log(v);
      const title = Object.keys(v.claim)[0];
      let children = [];
      const keys = Object.keys(v.claim[title]);
      keys.forEach(key => {
        if (validAttrSet.includes(key)) children.push({key: key, title: key + ': '+ v.claim[title][key]})
      })
      data.push({
        key: v.key,
        title: title,
        children: children,
      })
    })
    return data;
  }

  render() {
    const { targetKeys } = this.state;
    return (
      <div>
        <TreeTransfer dataSource={this.renderSource()} targetKeys={targetKeys} onChange={this.onChange} />
      </div>
    );
  }
}

export default connect(
  (state) => ({
    req: state.appReducer.req,
    vcs: state.appReducer.vcs,
    socket: state.appReducer.socket,
    state
  }),
  (dispatch) => ({
    initSocket: (socket) => dispatch({ type: 'SET_SOCKET', socket }),
    addRequest: (obj) => dispatch({ type: 'ADD_REQUEST', obj }),
    deleteRequest: (key) => dispatch({ type: 'DEL_REQUEST', key }),
    addVC: (obj) => dispatch({ type: 'ADD_VC', obj }),
    deleteVC: (key) => dispatch({ type: 'DEL_VC', key }),
    acceptRequest: (req, socket) => dispatch({ type: 'ACCEPT_REQUEST', req, socket }),
  })
)(Treee);