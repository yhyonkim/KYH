import React from "react";
import { Layout, Icon, Input } from 'antd';
import { Button, Row, Col, Typography, Form, Empty, Modal, notification, Drawer, Badge, message } from 'antd';
import io from 'socket.io-client';
import History from './History';
import Session from './Session';
import CredentialCard from './CredentialCard';
import RequestCard from './RequestCard';
import { connect } from "react-redux";

const { Header, Content, } = Layout;
const { Title } = Typography;


class MainPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "Kali",
      publicKey: process.env.REACT_APP_AGENT_ADDR,
      did: process.env.REACT_APP_AGENT_DID
    }
  }

  componentDidMount() {
    const { endpoint, did } = this.props.state.appReducer;
    const socket = io(endpoint);

    socket.emit('register', did);

    socket.on('request', (obj) => {
      this.props.addRequest(obj);
      message.info('A new request has arrived!');
    });

    socket.on('bulletProof', (data) => {
      console.log('resonse', data);
      this.props.bulletProof(data, socket);
    });

    this.props.initSocket(socket);
  }

  handleSubmit = e => {
    e.preventDefault();
  };

  showDrawer = () => {
    this.setState({
      visible: true,
    })
  }

  onClose = () => {
    this.setState({
      visible: false,
    });
  };

  handleChange = e => {
    e.preventDefault();
    const key = e.target.getAttribute('id');
    const val = e.target.value;
    const state = this.state;
    state[key] = val;
    this.setState(state);
  }

  render() {
    const { req, vcs } = this.props;
    if (!this.props.state.drizzleStatus.initialized) return "Loading Drizzle...";
    return (
      <Layout>
        <Header className="header">
          <span style={{ color: 'white', fontSize: '1.5em', }}>
            <Icon type="wallet" />&nbsp;
            Mona Wallet
          </span>
          <span style={{ float: 'right', color: 'white', minWith: '1px', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>
            {process.env.REACT_APP_DID}
          </span>
        </Header>
        <Layout>
          <Drawer
            title="Notification"
            placement="left"
            closable={true}
            onClose={this.onClose}
            visible={this.state.visible}
            width={400}
          >
            {req ? req.map((req, index) => <RequestCard key={index} req={req} drizzle={this.props.drizzle} />) : this.renderRequestEmptyMessage()}
          </Drawer>
          <Layout style={{ padding: '24px' }}>
            <Content>
              <Row>
                <h3 style={{ display: 'inline-block' }}>Credentials</h3>
                <span style={{ float: 'right' }}>
                  <Badge count={req ? req.length : 0}>
                    <Button onClick={this.showDrawer}>Notification</Button>
                  </Badge>
                </span>
                <Layout style={{
                  background: '#fff',
                  padding: 10,
                  flexDirection: 'column',
                }}>
                  <Row gutter={16}>
                    {vcs ? vcs.map((vc, index) => <Col key={index} span={12} style={{ maxWidth: '300px' }}><CredentialCard vc={vc} index={index} drizzle={this.props.drizzle} /></Col>) : this.renderVCEmptyMessage()}
                  </Row>
                </Layout>
              </Row>
              <Row>
                <Title level={3}>Session</Title>
                <Layout style={{
                  background: '#fff',
                  padding: 20,
                  minHeight: 280,
                }}>
                  <Session />
                </Layout>
              </Row>
              <Row>
                <Title level={3}>History</Title>
                <Layout style={{
                  background: '#fff',
                  padding: 20,
                  minHeight: 280,
                }}>
                  <History />
                </Layout>
              </Row>
              {/* {this.renderSettings()} */}
            </Content>
          </Layout>
        </Layout>
      </Layout>
    );
  }

  renderSettings = () => {
    return <Row>
      <Col span={6}>
        <Layout style={{
          background: '#fff',
          padding: 20,
          minHeight: 280,
        }}>
          <Title level={3}>Settings</Title>
          <Form onSubmit={this.handleSubmit} onChange={this.handleChange} className="login-form">
            <Form.Item>
              Name
            <Input id="name"
                prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
                placeholder="Name" value={this.state.name}
              />
            </Form.Item>
            <Form.Item>
              Public Key
            <Input id="publicKey"
                prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
                placeholder="Public Key" value={this.state.publicKey}
              />
            </Form.Item>
            <Form.Item>
              DID
            <Input id="did"
                prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
                placeholder="DID" value={this.state.did}
              />
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit" className="login-form-button">
                Save
          </Button>
            </Form.Item>
          </Form>
        </Layout>
      </Col>
    </Row>
  }

  requestConfirm = (counterparty) => {
    Modal.confirm({
      title: 'Request Confirm',
      content: 'Do you confirm to share this with ' + counterparty + '?',
      okText: 'Approve',
      cancelText: 'Cancel',
    })
  }

  openNotificationWithIcon = type => {
    notification[type]({
      message: 'Response sent',
      duration: 2,
      description:
        <div>
          <p>To: 0x049f28f402jf8024f</p>
          <p>To: 내용 1</p>
        </div>,
    });
  };

  renderVCEmptyMessage = () => {
    return <Empty />
  }

  renderRequestEmptyMessage = () => {
    return <Empty />
  }
}


// export default MainPage;
export default connect(
  (state) => ({
    req: state.appReducer.req,
    vcs: state.appReducer.vcs,
    socket: state.appReducer.socket,
    state
  }),
  (dispatch) => ({
    initSocket: (socket) => dispatch({ type: 'SET_SOCKET', socket }),
    addRequest: (obj) => dispatch({ type: 'ADD_REQUEST', obj }),
    deleteRequest: (key) => dispatch({ type: 'DEL_REQUEST', key }),
    addVC: (obj) => dispatch({ type: 'ADD_VC', obj }),
    deleteVC: (key) => dispatch({ type: 'DEL_VC', key }),
    acceptRequest: (req, socket) => dispatch({ type: 'ACCEPT_REQUEST', req, socket }),
    bulletProof: (data, socket) => dispatch({ type: 'BULLETPROOF', data, socket })
  })
)(MainPage);