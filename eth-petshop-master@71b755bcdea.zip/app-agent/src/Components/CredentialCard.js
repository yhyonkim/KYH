import React from 'react';
import { Card, Icon, Tag, Modal } from 'antd';
import { connect } from "react-redux";
// import { updateWitness } from "../functions/updateWitness"

const { Meta } = Card;

class CredentialCard extends React.Component {
    state = {
        visible: false,
        accId: null,
        accIndex: null,
    }

    componentDidMount() {
        const { drizzle, vc } = this.props;
        if (vc.claim['Birthdate Credential']) {
            const revocation = vc.claim['Birthdate Credential'].Revocation;
            const contract = drizzle.contracts.Revocation;
            const acc = contract.methods["getAcc"].cacheCall(revocation.accId);
            const value = contract.methods["getTails"].cacheCall(revocation.accId, revocation.accIndex)
            const witness = contract.methods["getWitness"].cacheCall(revocation.accId, revocation.accIndex)
            this.setState({ acc, value, witness })
        }
    }

    showModal = () => {
        this.setState({
            visible: true,
        });
    };

    handleOk = e => {
        this.setState({
            visible: false,
        });
    };

    handleCancel = e => {
        this.setState({
            visible: false,
        });
    };

    revokedStatus = vc => {
        const { Revocation } = this.props.state.contracts;
        const acc = Revocation.getAcc[this.state.acc] && Revocation.getAcc[this.state.acc].value;
        const value = Revocation.getTails[this.state.value] && Revocation.getTails[this.state.value].value;
        const witness = Revocation.getWitness[this.state.witness] && Revocation.getWitness[this.state.witness].value;
        if (vc && vc.claim && vc.claim['Birthdate Credential'] && vc.claim['Birthdate Credential'].Revocation) {
            // const witness = await updateWitness(vc.claim['Birthdate Credential'].Revocation, this.props.drizzle.contracts.Revocation);
            if (acc && value) {
                // console.log(value+" * "+witness+" = "+acc)
                if (value * witness === acc * 1) {
                    return 'Verified';
                } else return 'Revoked';
            }
            return 'Error';
        }
        return 'Active';
    }

    renderTag = vc => {
        const revokedStatus = this.revokedStatus(vc);
        if (revokedStatus === "Verified") {
            return <Tag style={{ marginLeft: '4px' }} color="green">Verified</Tag>
        } else if (revokedStatus === "Revoked") {
            return <Tag style={{ marginLeft: '4px' }} color="volcano">Revoked</Tag>
        } else if (revokedStatus === "Error") {
            return <Tag style={{ marginLeft: '4px' }} >Loading...</Tag>
        } else {
            return <Tag style={{ marginLeft: '4px' }} > Default </Tag>
        }
    }


    render() {
        const { vc } = this.props;
        const key = vc.key;
        const title = Object.keys(vc.claim)[0];
        let image;
        if (vc.iss === process.env.REACT_APP_GOV_DID) {
            image = require('../images/government.jpg')
        } else if (vc.iss === process.env.REACT_APP_PETSHOP_DID) {
            image = require('../images/petshop.png')
        } else if (vc.iss === process.env.REACT_APP_DELEGATED_DID) {
            image = require('../images/delegate.jpg')
        }

        return (
            <Card
                style={{ margin: 10 }}
                cover={
                    <img
                        alt="example"
                        src={image}
                        style={{ height: '140px', objectFit: 'contain' }}
                    />
                }
                actions={[
                    <Icon type="setting" theme="twoTone" twoToneColor="#52c41a" style={{ fontSize: '20px' }} onClick={() => this.showModal()} />,
                    <Icon type="close-circle" theme="twoTone" twoToneColor="#eb2f96" style={{ fontSize: '20px' }} onClick={() => this.props.deleteVC(key)} />,
                    <Icon type="ellipsis" style={{ fontSize: '20px' }} onClick={() => this.showModal()} />]}
            >
                <Meta
                    title={<span>{title} {this.renderTag(vc)}</span>}
                    description={'Expires at: ' + new Date(vc.exp).toLocaleString()}
                />
                {this.renderDetail(vc)}
            </Card>
        )
    }
    renderDetail = vc => {
        const title = Object.keys(vc.claim)[0];
        return (
            <Modal
                title={title + ' Detail'}
                visible={this.state.visible}
                onOk={this.handleOk}
                onCancel={this.handleCancel}>
                <pre>{JSON.stringify(vc, null, 2)}</pre>
            </Modal>
        )
    }
}

export default connect(
    (state) => ({
        state
    }),
    (dispatch) => ({
        addVC: (obj) => dispatch({ type: 'ADD_VC', obj }),
        deleteVC: (key) => dispatch({ type: 'DEL_VC', key }),
    })
)(CredentialCard);