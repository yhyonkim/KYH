const { Modal, Button } = antd;

class ConfirmModal extends React.Component {
    state = {
        ModalText: 'Default',
        visible: false,
        confirmLoading: false,
    };

    componentDidMount() {
        this.setState({ModalText: this.renderText()})
    }

    renderText = () => {
        const { type, counterparty } = this.props;
        switch (type) {
            case 'DISCLOSURE_REQ':
                const { name } = this.props;
                return `Do you want to share ${name} with ${counterparty}?`;
            case 'SHARE_REQ':
                const { verified } = this.props;
                return `Do you want to share ${verified} with ${counterparty}?`;
            case 'SIGN_TRANSACTION':
                return `Do you authorize ${counterparty} to make a transaction?`;
            default:
                return 'NOTHING HAPPEND';
        }
    }

    showModal = () => {
        this.setState({
            visible: true,
        });
    };

    handleOk = () => {
        this.setState({
            ModalText: 'Authorizing the request...',
            confirmLoading: true,
        });
        setTimeout(() => {
            this.setState({
                visible: false,
                confirmLoading: false,
            });
        }, 2000);
    };

    handleCancel = () => {
        this.setState({
            visible: false,
        });
    };

    render() {
        const { visible, confirmLoading, ModalText } = this.state;
        return (
            <div>
                <Button type="primary" onClick={this.showModal}>
                    Open Modal with async logic
                </Button>
                <Modal
                    title="Title"
                    visible={visible}
                    onOk={this.handleOk}
                    confirmLoading={confirmLoading}
                    onCancel={this.handleCancel}
                >
                    <p>{ModalText}</p>
                </Modal>
            </div>
        );
    }
}

export default ConfirmModal;