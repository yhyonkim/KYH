import React from "react";
import { Table, Tag } from 'antd';
import { connect } from "react-redux";

const columns = [
  {
    title: 'From',
    dataIndex: 'from_name',
    key: 'from_name',
  },
  {
    title: 'From_DID',
    dataIndex: 'from_did',
    key: 'from_did',
    render: did => {
      return <span>{`${did.substr(0, 20)}...`}</span>
    }
  },
  {
    title: 'To',
    dataIndex: 'to_name',
    key: 'to_name',
  },
  {
    title: 'To_DID',
    dataIndex: 'to_did',
    key: 'to_did',
    render: did => {
      return <span>{`${did.substr(0, 20)}...`}</span>
    }
  },
  {
    title: 'Type',
    key: 'tags',
    dataIndex: 'tags',
    render: tags => (
      <span>
        {tags.map(tag => {
          let color;
          switch (tag) {
            case 'DISCLOSURE_REQ':
              color = 'geekblue'; break;
            case 'SHARE_REQ':
              color = 'green'; break;
            case 'SIGN_TRANSACTION':
              color = 'volcano'; break;
            case 'ISSUE_CREDENTIAL':
              color = 'cyan'; break;
            default:
              color = 'purple'; break;
          }
          return (
            <Tag color={color} key={tag}>
              {tag.toUpperCase()}
            </Tag>
          );
        })}
      </span>
    ),
  },
  {
    title: 'Result',
    key: 'result',
    dataIndex: 'result',
    render: result => (
      <span>
        <Tag color={result.toUpperCase() === 'APPROVED' ? 'green' : 'red'}>
          {result.toUpperCase()}
        </Tag>
      </span>
    ),
  },
];

const getName = did => {
  switch (did) {
    case process.env.REACT_APP_AGENT_DID:
      return 'AGENT';
    case process.env.REACT_APP_PETSHOP_DID:
      return 'PETSHOP';
    case process.env.REACT_APP_GOV_DID:
      return 'GOVERNMENT';
    case process.env.REACT_APP_DELEGATED_DID:
      return 'DELEGATED ISSUER';
    default:
      console.error('Unknown DID', did);
      return 'UNKNOWN';
  }
}

const renderHist = hist => {
  return {
    key: hist.key,
    from_name: getName(hist.iss),
    from_did: hist.iss,
    to_name: getName(hist.aud),
    to_did: hist.aud,
    tags: [hist.type],
    result: hist.result,
    description: null,
  }
}

class History extends React.Component {
  render() {
    const data = [];
    this.props.hist && this.props.hist.map(h => {
      data.push(renderHist(h));
      return null;
    })
    return (
      <Table
        columns={columns}
        dataSource={data}
        expandedRowRender={record => <span style={{ margin: 0 }}>{record.description}</span>}
      />
    )
  }
}

export default connect(
  (state) => ({
    hist: state.appReducer.hist,
    state
  }),
  (dispatch) => ({

  })
)(History);