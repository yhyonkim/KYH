import React from "react";
import { Table, Tag } from 'antd';
import Card from './Card';
import { connect } from "react-redux";

const columns = [
  {
    title: 'From',
    dataIndex: 'from_name',
    key: 'from_name',
  },
  {
    title: 'From_DID',
    dataIndex: 'from_did',
    key: 'from_did',
    render: did => {
      return <span>{`${did.substr(0, 20)}...`}</span>
    }
  },
  {
    title: 'Requested',
    key: 'tags',
    dataIndex: 'tags',
    render: tags => (
      <span>
        {tags.map(tag => {
          let color;
          if (tag.includes('vc_')) color = 'geekblue';
          return (
            <Tag color={color} key={tag}>
              {tag.toUpperCase()}
            </Tag>
          );
        })}
      </span>
    ),
  },
  {
    title: 'Sharing',
    key: 'sharing',
    dataIndex: 'sharing',
    render: sharings => (
      <span>
        {sharings && sharings.map(sharing => {
          let color, text;
          if (sharing.includes('vc_')) {
            color = 'geekblue';
            text = sharing.split('vc_')[1];
          } else {
            text = sharing;
          }
          return <Tag color={color} key={sharing}>
            {text && text.toUpperCase()}
          </Tag>
        })}
      </span>
    ),
  },
  {
    title: 'Status',
    key: 'status',
    dataIndex: 'status',
    render: status => (
      <span>
        <Tag color={status && status.toUpperCase() === 'LIVE' ? 'green' : 'red'}>
          {status && status.toUpperCase()}
        </Tag>
      </span>
    ),
  },
];

const getName = did => {
  switch (did) {
    case process.env.REACT_APP_AGENT_DID:
      return 'AGENT';
    case process.env.REACT_APP_PETSHOP_DID:
      return 'PETSHOP';
    case process.env.REACT_APP_GOV_DID:
      return 'GOVERNMENT';
    case process.env.REACT_APP_DELEGATED_DID:
      return 'DELEGATED';
    default:
      console.error('Unknown DID', did);
      return 'UNKNOWN';
  }
}

const renderSession = session => {
  return {
    key: session.key,
    from_name: getName(session.iss),
    from_did: session.iss,
    tags: session.requested,
    status: session.status,
    sharing: session.sharing,
    requested: session.requested,
    description: <Card token={session.token} />
  }
}

class Session extends React.Component {
  render() {
    const data = [];
    this.props.session && this.props.session.map(session => {
      data.push(renderSession(session));
      return null;
    })
    return (
      <Table
        columns={columns}
        dataSource={data}
        // expandedRowRender={record => <span style={{ margin: 0 }}>{record.description}</span>}
      />
    )
  }
}

export default connect(
  (state) => ({
    session: state.appReducer.session,
    state
  }),
  (dispatch) => ({

  })
)(Session);