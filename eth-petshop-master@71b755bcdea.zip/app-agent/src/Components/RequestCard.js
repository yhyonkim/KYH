import React from 'react';
import { connect } from "react-redux";
import { Card, Icon, Avatar, Modal, Button, Collapse } from 'antd';
import { decodeJWT } from 'did-jwt';
import CredentialForm from './CredentialForm';
import Treee from './Treee';
const { Meta } = Card;
const { Panel } = Collapse;

const renderDescription = payload => {
    if (payload.type === "shareReq") {
        return `Requested: ${payload && payload.requested}, ${payload && payload.verified}`
    } else if (payload.type === 'schemaID') {
        return 'SchemaID: ' + payload.token;
    } else if (payload.type === 'checkAge') {
        return 'Required age: ' + payload.token.startAge;
    } else if (payload.type === 'ethtx' && payload.value) {
        var requiredTokens = parseInt(payload.value, 16) / 1000000000000000000; // 1ETH = 1000000000000000000
        return 'Required tokens: ' + requiredTokens + ' ETH';
    } else {
        if (payload.claim) return 'Claim: ' + JSON.stringify(payload.claim, ',', 2);
        else return '';
    }
}

class RequestCard extends React.Component {
    state = { visible: false }

    showModal = () => {
        this.setState({
            visible: true,
        });
    };
    handleSave = (req) => {
        this.props.acceptRequest(req, false);
        this.props.deleteRequest(req.key);
        this.setState({
            visible: false,
        });
    }
    handleSign = (req) => {
        this.props.acceptRequest(req, true);
        this.props.deleteRequest(req.key);
        this.setState({
            visible: false,
        });
    }
    handleConfirm = (req) => {
        this.props.sendResponse();
        this.props.deleteRequest(req.key);
        this.setState({
            visible: false,
        });
    }
    handleOk = (req, contracts) => {
        this.props.acceptRequest(req, true, contracts);
        this.props.deleteRequest(req.key);
        this.setState({
            visible: false,
        });
    }

    getResponse = (req, contracts) => {
        this.props.acceptRequest(req, false, contracts);
    };

    handleCancel = e => {
        this.setState({
            visible: false,
        });
    };

    renderJWT = (obj) => {
        let result = {};
        let keys = Object.keys(obj);
        keys.map(k => {
            try {
                let tmp = decodeJWT(obj[k]);
                result[k] = tmp;
            } catch (error) {
                result[k] = obj[k];
            };
        })
        return result;
    }

    showSelect = () => {
        this.setState({ select: true });
    }

    hideSelect = () => {
        this.setState({ select: false });
    }

    renderDetail = (req, drizzle, payload) => {
        return (
            <Modal
                title={payload && payload.type ? payload.type + ' Detail' : 'New Credential Detail'}
                visible={this.state.visible} j
                width={'80%'}
                onCancel={this.handleCancel}
                footer={[
                    <Button key="back" onClick={this.handleCancel}>Return</Button>,
                    // this.state.select ?
                    //     <Button key="hide" disabled={this.props.response} onClick={this.hideSelect}>Hide Select</Button>
                    //     : <Button key="select" disabled={this.props.response} onClick={this.showSelect}>Select (개발중)</Button>,
                    <Button key="create"  onClick={() => this.getResponse(req, drizzle.contracts)}>Create Response</Button>,
                    <Button key="send"  onClick={() => this.handleOk(req, drizzle.contracts)} type="primary">Send</Button>,
                ]}
            >
                {
                    <Collapse expandIconPosition={'right'} bordered={false}>
                        <Panel header={<h4>Request</h4>}>
                            {this.renderRequest(req)}
                        </Panel>
                    </Collapse>
                }
                {
                    req.schemaID &&
                    <Collapse expandIconPosition={'right'} bordered={false} defaultActiveKey={"1"}>
                        <Panel header={<h4>Create Response</h4>} key="1">
                            <CredentialForm drizzle={drizzle} schemaID={req.schemaID} />
                        </Panel>
                    </Collapse>
                }
                {
                    this.state.select &&
                    <Collapse expandIconPosition={'right'} bordered={false} defaultActiveKey={"1"}>
                        <Panel header={<h4>Select Response</h4>} key="1">
                            <Treee />
                        </Panel>
                    </Collapse>
                }
                {
                    this.props.response &&
                    <Collapse expandIconPosition={'right'} bordered={false} defaultActiveKey={"1"}>
                        <Panel header={<h4>Response</h4>} key="1">
                            {this.renderResponse()}
                        </Panel>
                    </Collapse>
                }
            </Modal>
        )
    }
    renderSaveRequest = (req) => {
        return (
            <Modal
                title={'Credential Detail'}
                visible={this.state.visible}
                onOk={() => this.handleSave(req)}
                onCancel={this.handleCancel}
            >
                <h4>Credential Detail</h4>
                {this.renderRequest(req)}
            </Modal>
        )
    }
    renderSignTxRequest = (req) => {
        return (
            <Modal
                title={'Sign Transaction Detail'}
                visible={this.state.visible}
                onOk={() => this.handleSave(req)}
                onCancel={this.handleCancel}
                footer={[
                    <Button key="back" onClick={this.handleCancel}>Return</Button>,
                    <Button key="send" onClick={() => this.handleSign(req)} type="primary">Send</Button>,
                ]}
            >
                <h4>Sign Transaction Detail</h4>
                {this.renderRequest(req)}
            </Modal>
        )
    }
    renderRequest = (req) => {
        return <pre>{JSON.stringify(this.renderJWT(req), null, 2)}</pre>
    }

    renderResponse = () => {
        return <pre>{JSON.stringify(this.renderJWT(this.props.response), null, 2)}</pre>
    }
    renderModal = (req, drizzle, payload) => {
        if (req.type === 'saveReq') return this.renderSaveRequest(req);
        else if (req.type === 'ethtx') return this.renderSignTxRequest(req);
        else return this.renderDetail(req, drizzle, payload);

    }

    render() {
        const { req, drizzle, keyPair } = this.props;
        const key = req.key;
        if (req.token && typeof req.token === 'string' && req.token.includes('id.uport')) {
            req.token = req.token.split('/')[4].split('?')[0];
            req.type = 'saveReq';
        }
        let token = null, payload = null;
        if (req.type && req.type === 'schemaID') {
            payload = req;
            req.schemaID = req.token;
        } else if (req.type && req.type === 'checkAge') {
            payload = req;
        } else {
            token = decodeJWT(req.token);
            if (token.payload.type === 'ethtx') req.type = 'ethtx';
            payload = token.payload;
            if (payload.verified && payload.verified[0] === 'Birthdate Credential') req.walletPublickKey = keyPair.publicKey.toString('hex');
        }
        return (
            <Card key={key}
                style={{ margin: 10 }}
                actions={[
                    // <Icon type="check-circle" theme="twoTone" twoToneColor="#52c41a" style={{ fontSize: '20px' }} onClick={() => this.handleOk(req, drizzle.contracts)} />,
                    <Icon type="check-circle" theme="twoTone" twoToneColor="#52c41a" style={{ fontSize: '20px' }} onClick={() => this.showModal()} />,
                    <Icon type="close-circle" theme="twoTone" twoToneColor="#eb2f96" style={{ fontSize: '20px' }} onClick={() => this.props.declineRequest(req)} />,
                    // <Icon type="ellipsis" style={{ fontSize: '20px' }} onClick={() => this.showModal()} />
                ]}
            >
                <Meta
                    avatar={<Avatar src={require('../images/ethereum.svg')} />}
                    title={payload && payload.type ? payload.type : 'New Credential'}
                    description={renderDescription(payload)}
                />
                {this.renderModal(req, drizzle, payload)}
            </Card>
        )
    }
}

export default connect(
    (state) => ({
        socket: state.appReducer.socket,
        keyPair: state.appReducer.keyPair,
        response: state.appReducer.response,
        responseType: state.appReducer.responseType,
        state
    }),
    (dispatch) => ({
        addRequest: (obj) => dispatch({ type: 'ADD_REQUEST', obj }),
        deleteRequest: (key) => dispatch({ type: 'DEL_REQUEST', key }),
        addVC: (obj) => dispatch({ type: 'ADD_VC', obj }),
        deleteVC: (key) => dispatch({ type: 'DEL_VC', key }),
        acceptRequest: (req, sendDirect, contracts) => dispatch({ type: 'ACCEPT_REQUEST', sendDirect, req, contracts }),
        declineRequest: (req) => dispatch({ type: 'DECLINE_REQUEST', req }),
        setResponse: (res) => dispatch({ type: 'SET_RESPONSE', response: res, responseType: res }),
        sendResponse: (res, type) => dispatch({ type: 'SEND_RESPONSE' }),
    })
)(RequestCard);