import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Icon } from 'antd';

class CredentialForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: this.props.value,
            validity: this.props.validity,
            dataKey: null,
        }
    }

    componentDidMount = () => {
        const { drizzle, schemaID } = this.props;
        const id = schemaID;
        const contract = drizzle.contracts.Schema;
        const dataKey = contract.methods["get"].cacheCall(id);
        this.setState({ dataKey });
    }

    handleChange = (e) => {
        const key = e.target.getAttribute('id');
        const val = e.target.value;
        const regex = e.target.getAttribute('placeholder');
        const validity = { ...this.state.validity };
        validity[key] = this.checkString(val, regex);
        const value = { ...this.state.value };
        value[key] = val;
        this.setState({ value, validity })
        this.props.setInputValue(value, validity);
    }

    checkString = (target, regex) => {
        const r = RegExp(regex);
        return r.test(target);
    }

    checkForm = (length) => {
        if (this.state.validity && Object.values(this.state.validity).length < length) return false;
        return this.props.selectedAcc && Object.values(this.state.validity).every(x => x);
    }

    renderInput = (properties, key) => {
        const regex = properties[key].pattern
        const validity = { ...this.state.validity }
        const valid = validity[key];
        return (
                <div className="input-group" key={key} style={{ margin: '15px' }}>
                    <span className="input-group-addon">{key}</span>
                    <input className="form-control" id={key} type="text" placeholder={regex} />
                    <span className="input-group-addon">
                        {valid ? <Icon type="check-circle" theme="twoTone" twoToneColor="#52c41a" /> : <Icon type="close-circle" theme="twoTone" twoToneColor="#eb2f96" />}
                    </span>
                </div>
        )
    }

    render() {
        const { schemaID, contracts } = this.props;
        const dataKey = this.state.dataKey;
        let title = null;
        let properties = null;
        let keys = [];
        const schema = contracts.Schema.get[dataKey] && JSON.parse(contracts.Schema.get[dataKey].value);
        if (!schemaID) return null;
        if (schema && schema.properties) {
            title = Object.keys(schema.properties)[0];
            properties = schema.properties[title].properties;
            keys = Object.keys(properties);
        }
        return (
            <div>
                <form onSubmit={this.handleSubmit} onChange={this.handleChange}>
                    <div className="wrap">
                        <b>Claims</b>
                        <div className="content padding">
                            <Row>
                                {keys.length > 0 && keys.map((key) => this.renderInput(properties, key))}
                                <div style={{float: 'right', marginRight: '15px'}}>
                                </div>
                            </Row>
                        </div>
                    </div>
                    <br />
                </form>
            </div>
        )
    }
}

export default connect(
    (state) => {
        const { user } = state.appReducer;
        return {
            user: user,
            contracts: state.contracts,
            schemaKeys: state.appReducer.schemaKeys,
            state
        }
    },
    (dispatch) => {
        return {
            addSchemaKey: (id, dataKey) => dispatch({ type: 'ADD_SCHEMA_KEY', key: { id: dataKey } }),
            selectSchema: (value) => dispatch({ type: 'SELECT_ACCUMULATOR', value }),
            setInputValue: (value, validity) => dispatch({ type: 'SET_INPUT_VALUE', value, validity })
        }
    }
)(CredentialForm)
