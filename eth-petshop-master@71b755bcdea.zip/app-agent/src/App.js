import React, { Component } from "react";
import { connect } from 'react-redux'
import "./App.css";
import MainPage from "./Components/MainPage";
import { hexStringToBytes } from './utilities/utils';
import RegisterDID from "./Components/RegisterDID";

const bls = require('@chainsafe/bls');

class App extends Component {

  componentDidMount() {
    const keyPair = {};
    keyPair.privateKey = hexStringToBytes(process.env.REACT_APP_AGENT_PRIVATE_KEY);
    keyPair.publicKey = bls.default.generatePublicKey(keyPair.privateKey);

    this.props.setKeyPair(keyPair);
  }

  render() {
    return (
      <div>
        <MainPage drizzle={this.props.drizzle}/>

        {this.props.keyPair !== null ? <RegisterDID drizzle={this.props.drizzle}/> : null}
      </div>
    );
  }
}

export default connect(
  (state) => ({
    keyPair: state.appReducer.keyPair,
  }),
  (dispatch) => ({
      setKeyPair: (keyPair) => dispatch({ type: 'SET_KEY_PAIR', keyPair}),
  })
)(App)
