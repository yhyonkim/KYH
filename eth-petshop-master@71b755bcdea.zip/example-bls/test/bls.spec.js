const should = require('should');
const bls = require('@chainsafe/bls-js');
const sha256 = require('js-sha256');

function hexStringToBytes(str) {
    let bytes = str.replace(/^0x/gi, '');
    return Buffer.from(bytes, 'hex');
}
function toHexString(bytes) {
    return '0x' + bytes.map(function(byte) {
      return ("00" + (byte & 0xFF).toString(16)).slice(-2)
    }).join('')
}

describe('bls-js',function(){
    describe('keypair',function() {
        it('generates publicKey from given privateKey.',function(){
            // privateKey should be type of: bytes32
            const privateKey = hexStringToBytes('0xa77637cbb4da8e6568878f1e3ee4aed4c7df4806471998a77c76afc7fd46fe96');
            privateKey.length.should.be.equals(32);

            debugger
            const publicKey = bls.default.generatePublicKey(privateKey);           
            toHexString(publicKey)
                .should.be.equal('0x860034047003136685302500019058000000505628626404372800083000015000');
        });
    });
    describe('simple signature vefification',function() {
        it('will pass when signature is valid.', function(){
            const keypair = bls.default.generateKeyPair();
            const message = "this is a message.";
            const messageHash = Buffer.from(sha256.arrayBuffer(message));
            const domain = Buffer.alloc(8,0);
            const signature = bls.default.sign(
                keypair.privateKey.toBytes(), 
                messageHash, 
                domain);
            const result = bls.default.verify(
                keypair.publicKey.toBytesCompressed(), 
                messageHash, 
                signature, 
                domain);
            result.should.be.true();
        });
        it('will fail when signature is invalid.', function(){
            const keypair1 = bls.default.generateKeyPair();
            const keypair2 = bls.default.generateKeyPair();
            const message = "this is a message.";
            const messageHash = Buffer.from(sha256.arrayBuffer(message));
            const domain = Buffer.alloc(8,0);
            const signature = bls.default.sign(
                keypair1.privateKey.toBytes(), 
                messageHash, 
                domain);
            // verify with diffrent key
            const result = bls.default.verify(
                keypair2.publicKey.toBytesCompressed(), 
                messageHash, 
                signature, 
                domain);
            result.should.not.be.true();
        });   
    });
    describe('aggregated signatures about a message.',function() {
        const holder = bls.default.generateKeyPair();
        const issuer = bls.default.generateKeyPair();
        /* Scenario
        * 1. Holder : make a message or random string for nonce, sign it with private key
        * 2. Holder : send the message and signature to Issuer
        * 3. Issuer : sign the message with private key, and aggregate the signiture with holder's signature
        * 4. Issuer : make a credential with the string and aggregated signature
        * 5. Verifier : get public key of holder and issuer, and aggregate them
        * 6. Verifier : verify aggregated signature with the string and aggregated public key
        */ 
        it('will pass when aggregated signatures are valid.', function(){ 
            const domain = Buffer.alloc(8,0);

            // const holder = bls.default.generateKeyPair();
            // const issuer = bls.default.generateKeyPair();
            
            const message = "this is a message from holder.";
            const messageHash = Buffer.from(sha256.arrayBuffer(message));
        
            const holderSignagure = bls.default.sign(holder.privateKey.toBytes(), messageHash, domain);
            const issuerSignature = bls.default.sign(issuer.privateKey.toBytes(), messageHash, domain);
            const signatures = bls.default.aggregateSignatures([
                holderSignagure, 
                issuerSignature,
            ]);

            // order of keys is not important.
            const publicKeys = bls.default.aggregatePubkeys([
                holder.publicKey.toBytesCompressed(), 
                issuer.publicKey.toBytesCompressed(),
            ]);
        
            const result = bls.default.verifyMultiple(
                [publicKeys],
                [messageHash],
                signatures,
                domain);
            result.should.be.true();
        });   
        it('will pass even if someone signs twice.', function(){ 
            const domain = Buffer.alloc(8,0);

            const holder = bls.default.generateKeyPair();
            const issuer = bls.default.generateKeyPair();
            
            const message = "this is a message from holder.";
            const messageHash = Buffer.from(sha256.arrayBuffer(message));
        
            const holderSignagure = bls.default.sign(holder.privateKey.toBytes(), messageHash, domain);
            const issuerSignature = bls.default.sign(issuer.privateKey.toBytes(), messageHash, domain);
            const signatures = bls.default.aggregateSignatures([
                holderSignagure, 
                issuerSignature, 
                holderSignagure,
            ]); // holder signs twice.
            // the order of the public keys is not important. 
            // but the number of keys is important.
            const publicKeys = bls.default.aggregatePubkeys([
                holder.publicKey.toBytesCompressed(), 
                holder.publicKey.toBytesCompressed(), 
                issuer.publicKey.toBytesCompressed(),
            ]);
        
            const result = bls.default.verifyMultiple(
                [publicKeys],
                [messageHash],
                signatures,
                domain);
            result.should.be.true();
        });   
        it('will fail when some public key is missing.', function(){ 
            const domain = Buffer.alloc(8,0);

            const holder = bls.default.generateKeyPair();
            const issuer = bls.default.generateKeyPair();
            
            const message = "this is a message from holder.";
            const messageHash = Buffer.from(sha256.arrayBuffer(message));
        
            const holderSignagure = bls.default.sign(holder.privateKey.toBytes(), messageHash, domain);
            const issuerSignature = bls.default.sign(issuer.privateKey.toBytes(), messageHash, domain);
            const signatures = bls.default.aggregateSignatures([
                holderSignagure, 
                issuerSignature, 
                holderSignagure,
            ]); // holder signs twice.
            // the order of the public keys is not important. 
            // but the number of keys is important.
            const publicKeys = bls.default.aggregatePubkeys([
                holder.publicKey.toBytesCompressed(), 
                holder.publicKey.toBytesCompressed(), 
                //issuer.publicKey.toBytesCompressed(), // suppose that this key was missing
            ]);
        
            result = bls.default.verifyMultiple(
                [publicKeys],
                [messageHash],
                signatures,
                domain);
            result.should.not.be.true();
        });   
    });
    describe('aggregated signatures about indivisual messages.',function() {
        it('will pass even if messages are indivisual.',function(){
            const domain = Buffer.alloc(8,0);

            const holder = bls.default.generateKeyPair();
            const issuer = bls.default.generateKeyPair();

            
            const holderMessage = Buffer.from(sha256.arrayBuffer(`message from holder`));
            const issuerMessage = Buffer.from(sha256.arrayBuffer(`message from issuer with ${holderMessage}`));
            const holderMessageAgain = Buffer.from(sha256.arrayBuffer(`message from holder with ${issuerMessage}`));

            const holderSignature = bls.default.sign(holder.privateKey.toBytes(), holderMessage, domain);
            const issuerSignature = bls.default.sign(issuer.privateKey.toBytes(), issuerMessage, domain);
            const holderSignatureAgain = bls.default.sign(holder.privateKey.toBytes(), holderMessageAgain, domain);

            const messages = [
                holderMessage, 
                issuerMessage, 
                holderMessageAgain,
            ];        
            const signatures1 = bls.default.aggregateSignatures([
                holderSignature, 
                issuerSignature,
            ]);
            const signatures2 = bls.default.aggregateSignatures([
                signatures1,
                holderSignatureAgain,
            ]);
            const result = bls.default.verifyMultiple(
                [
                    holder.publicKey.toBytesCompressed(),
                    issuer.publicKey.toBytesCompressed(),
                    holder.publicKey.toBytesCompressed(),
                ],
                messages,
                signatures2,
                domain);
            result.should.be.true();
        })
        it('will fail when messages was manipulated.',function(){
            const domain = Buffer.alloc(8,0);

            const holder = bls.default.generateKeyPair();
            const issuer = bls.default.generateKeyPair();

            const holderMessage = Buffer.from(sha256.arrayBuffer("message from holder"));
            const issuerMessage = Buffer.from(sha256.arrayBuffer("message from issuer"));
            const manipulatedMessage = Buffer.from(sha256.arrayBuffer("message from unknown"));
            const messages = [holderMessage, manipulatedMessage];
                // messages are manipulated from unknown
            const holderSignature = bls.default.sign(holder.privateKey.toBytes(), holderMessage, domain);
            const issuerSignature = bls.default.sign(issuer.privateKey.toBytes(), issuerMessage, domain);
            const signatures = bls.default.aggregateSignatures([
                holderSignature, 
                issuerSignature
            ]);        
            const result = bls.default.verifyMultiple(
                [
                    holder.publicKey.toBytesCompressed(), 
                    issuer.publicKey.toBytesCompressed(),
                ],
                messages,
                signatures,
                domain);
            result.should.not.be.true();
        })
    });
});
