# 요구 사항

* Ubuntu Linux 또는 Mac OS
    * awk
    * xargs
    * direnv
* NodeJS 10.x
    * yarn
* Chrome Web Browser

# 실행 절차

## quorum network 띄우기

먼저 quorum-maker 프로젝트를 내려 받고 setup.sh 를 실행한다.\

1. Create Network 메뉴인 1) 을 선택
1. Please enter node name: `uport` 로 한다.
1. Please enter IP Address of this node: 는 서버의 살제 IP 주소를 입력한다.
1. 이후 모든 질문에는 그냥 `Enter` 를 하여 기본값을 사용한다.

```
$ git clone https://github.com/synechron-finlabs/quorum-maker.git
quorum-maker $ cd quorum-maker
quorum-maker $ ./setup.sh
   ______   __      __
  / ____ \ |  \    /  |
 / /    \ \|   \  /   |
 | |     | |    \/    |
 | |     | | |\    /| |
 | |     |  \| \  / | |
 \ \____/ /\ \  \/  | |
  \______/  \_\     |_|  Version 2.6.2 Built on Quorum 2.2.1

Please select an option:
 1) Create Network
 2) Join Network
 3) Attach to an existing Node
 4) Setup Development/Test Network
 5) Exit
option: 1
Please enter node name: uport
Please enter IP Address of this node: 10.81.132.227
Please enter RPC Port of this node[Default:22000]:
Please enter Network Listening Port of this node[Default:22001]:
Please enter Constellation Port of this node[Default:22002]:
Please enter Raft Port of this node[Default:22003]:
Please enter Node Manager Port of this node[Default:22004]:
Please enter WS Port of this node[Default:22005]:
****************************************************************************************************************
Successfully created and started uport
You can send transactions to :22000
For private transactions, use mRfedm5lg/1GmXXAdmzdFcK8XD4vIbojYJ7UUDuvHT8=
For accessing Quorum Maker UI, please open the following from a web browser http://localhost:22004/
To join this node from a different host, please run Quorum Maker and choose option to run Join Network
When asked, enter  for Existing Node IP and 22004 for Node Manager Port
****************************************************************************************************************
```

서비스가 기동되었으면 웹 브라우저를 열어 http://localhost:22004/ 를 열어 대시보드가 잘 보이는지 확인한다.

다른 터미널을 하나 열어서 기동된 서비스를 다음 명령으로 내린다.
```
$ docker ps | grep start_uport.sh | awk '{print $1}' | xargs -t docker stop
docker stop d10bc7d8bb89
d10bc7d8bb89
$ 
```

uport/node/start_uport.sh 파일을 열어 맨 마지막 라인 (45라인)을 다음과 같이 바꾼다. `--unlock 0 --password <(echo -n "")` 를 geth 명령 뒤의 옵션에 추가하는 것임)
```
PRIVATE_CONFIG=qdata/$NODE_NAME.ipc geth --verbosity 6 --datadir qdata $GLOBAL_ARGS --rpccorsdomain "*" --raftport $RA_PORT --rpcport $R_PORT --port $W_PORT --ws --wsaddr 0.0.0.0 --wsport $WS_PORT --wsorigins '*' --wsapi $ENABLED_API     --nat extip:$CURRENT_NODE_IP 2>>qdata/gethLogs/${NODE_NAME}.log &

====>

PRIVATE_CONFIG=qdata/$NODE_NAME.ipc geth --unlock 0 --password <(echo -n "") --verbosity 6 --datadir qdata $GLOBAL_ARGS --rpccorsdomain "*" --raftport $RA_PORT --rpcport $R_PORT --port $W_PORT --ws --wsaddr 0.0.0.0 --wsport $WS_PORT --wsorigins '*' --wsapi $ENABLED_API     --nat extip:$CURRENT_NODE_IP 2>>qdata/gethLogs/${NODE_NAME}.log &
```

uport 디렉터리로 이동하여 quorum node 를 다시 기동한다.
```
quorum-maker$ cd uport
quorum-maker/uport$ ./start.sh
```

스마트 컨트랙트 배포
====

eth-petshop 프로젝트를 내려 받고 다음 명령들을 순서대로 실행한다.

```
$ git clone https://wire.lgcns.com/bitbucket/scm/blockchain/eth-petshop.git
$ cd eth-petshop
eth-petshop$ npm i
eth-petshop$ npm run link
eth-petshop$ npm run com
eth-petshop$ npm run mig
```

Quorum Maker Dashboard 를 통해 contract 가 배포되었음을 확인한다.

어플리케이션 기동
====

모두 4개의 터미널을 띄워두고 각 터미널당 하나씩 어플리케이션을 기동한다.
가장 먼저 app-wallet 을 띄워야 함에 주의할 것.

1. 크롬 브라우저를 띄운 다음 각 터미널 마다 다음 명령들을 실행시킨다.

```
eth-petshop$ cd app-wallet
eth-petshop/app-wallet$ yarn
eth-petshop/app-wallet$ yarn start
```

```
eth-petshop$ cd app-agent
eth-petshop/app-agent$ yarn
eth-petshop/app-agent$ yarn start
```

```
eth-petshop$ cd app-petshop
eth-petshop/app-petshop$ yarn
eth-petshop/app-petshop$ yarn start
```

```
eth-petshop$ cd app-gov
eth-petshop/app-gov$ yarn
eth-petshop/app-gov$ yarn start
```

크롬 브라우저에 `정부`, `에이전트`, `펫샵` 화면이 뜨는 것을 확인한다. 